import { Component, OnInit, OnDestroy } from '@angular/core';
import { AuthenticationService } from '../../services/authentication.service';
import { AccountService } from '../account-info/account.service';
import { Router } from '@angular/router';
import { Message, DialogModule } from 'primeng/primeng';
import { StorageService } from '../../services/storage.service';
import { LoginDTO } from '../../model/Login.model';
import { myGlobals } from '../../constants/globals';
declare var global: any;
declare var sessionStorage: any;
@Component({
  selector: 'login-page',
  templateUrl: 'login.component.html',
  styleUrls: ['login.component.css'],
  providers: [AuthenticationService, StorageService, AccountService]
})
export class LoginComponent implements OnInit {

  error: boolean = false;
  noNgpAccess: boolean = false;
  destination: string;
  vin: any;
  oem: any;
  loginDTO: any;
  errormsgs: Message[] = [];  
  forgotUsernamePasswordUrl: string;
  loading: boolean = false;
  growlLife: Number = myGlobals.disAppearTimeMessage;
  constructor(public router: Router,
    private authenticationService: AuthenticationService,
    private storage: StorageService,
    private accountService: AccountService) {
    this.loginDTO = new LoginDTO(null, '', '', '');
  }

  login() {

    this.errormsgs = [];
    this.loading = true;

    this.accountService.getAccountInfo(this.loginDTO.accountNumber).subscribe(
      info => {
        if (info['responseStatus'] !== 'failure') {
          this.oem = info['make'];
          this.vin = info['vin'];
          sessionStorage["accountInfo"] = JSON.stringify(info);
          sessionStorage["params"] = '&accountNumber=' + info['accountNumber'] + '&tcuId=' + info['tcuId'] + '&vin=' + info['vin'] + '&userTimeZoneStr=est';
          this.loginDTO.oem = this.oem;
          this.loginDTO.vin = this.vin;
          this.authenticationService.authenticate(this.loginDTO).subscribe(
            auth => {
              this.loading = false;
              if (auth['responseStatus'] === 'success') {
                sessionStorage.setItem('id_token', "_" + Math.floor(Math.random() * myGlobals.randomNumdigts));                
                this.loginSuccess();
              } else {
                this.authenticationService.clearSession();
                this.errormsgs.push({ severity: 'error', summary: '', detail: auth['responseDescription'] });
              }
            },
            error => {
              this.loading = false;
              error = (error.status === "undefined" || !error.status) ? global.badGateWay : error.err;
              this.authenticationService.clearSession();
              this.errormsgs.push({ severity: 'error', summary: '', detail: error });
            }

          );

        } else {
          this.loading = false;
          this.errormsgs.push({ severity: 'error', summary: '', detail: info['responseDescription'] });
        }
      },
      error => {
        this.loading = false;
        if (!error.status) {
          error.err = myGlobals.badGateWay;
        }
        this.errormsgs.push({ severity: 'error', summary: '', detail: error.err });
      }
    );
  }

  public loginSuccess() {
    this.error = false;
    let _dest: string = this.destination || '/landing';
    this.router.navigate([_dest]);
  }

logOut() {
    this.loading = true;
    this.authenticationService.requestToLogout().subscribe(
      info => {
        this.loading = false;
        if(info['responseDescription']){
          window.location.href = info['responseDescription'];
        }        
      },
      error => {
        this.loading = false;
        this.errormsgs.push({ severity: 'error', summary: '', detail: error });
      });
  }

  ngOnInit() {
    this.destination = this.router['intendedRoute'];
  }

  ngAfterViewInit() {
    
  }

  ngOnDestroy() {
    // do something
  }
}
