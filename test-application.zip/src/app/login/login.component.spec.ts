// import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
// import { FormsModule } from '@angular/forms';
// import { AuthenticationService } from '../../services/authentication.service';
// import { LoginComponent } from './login.component';
// import { StorageService } from '../../services/storage.service';
// import { AccountService } from '../account-info/account.service';
// import { Router } from '@angular/router';
// import { HttpModule, Http } from '@angular/http';
// import { MessagesModule, DialogModule, GrowlModule } from 'primeng/primeng';
// import { LoginDTO } from '../../model/Login.model';
// import { myGlobals } from '../../constants/globals';
// import { By } from '@angular/platform-browser';
// import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
// declare var sessionStorage: any;
// describe('LoginComponent', () => {
//   let comp: LoginComponent;
//   let fixture: ComponentFixture<LoginComponent>;
//   let de: DebugElement;


//   beforeEach(async(() => {

//     TestBed.configureTestingModule({
//       imports: [HttpModule, DialogModule, MessagesModule, FormsModule, GrowlModule],
//       declarations: [LoginComponent],
//       providers: [{ provide: Router, useClass: RouterStub }, AccountService, AuthenticationService, StorageService]
//     })
//       .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(LoginComponent);
//     comp = fixture.componentInstance;
//     fixture.detectChanges();

//     de = fixture.debugElement.query(By.css('h1'));

//   });

//   // it('loginSuccess Redirect to landing', () => {
//   //    comp.loginSuccess();
//   //    fixture.detectChanges();
//   //    expect(false).toBe(comp.error);
//   //    // let _dest: string = comp.destination || '/landing';          
//   //  });

//   it('login request to service', () => {
//     comp.login();
//     fixture.detectChanges();
//     expect(true).toBe(comp.loading);
//   });

//   it('error should be false', () => {
//     fixture.detectChanges();
//     expect(comp.error).toBe(false);
//   });

//   it('destination should be intendedRoute', () => {
//     comp.ngOnInit();
//     expect(comp.destination).toEqual(undefined);
//   });
// });

// class RouterStub {
//   url: String = '/landing';
// };

// class FakeAccountService {

// };

// class FakeAuthenticationService {

// };
// class FakeStorageService {

// };
