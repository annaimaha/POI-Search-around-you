// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { ScheduleAlertComponent } from './schedule-alert.component';

// describe('ScheduleAlertComponent', () => {
//   let component: ScheduleAlertComponent;
//   let fixture: ComponentFixture<ScheduleAlertComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ ScheduleAlertComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(ScheduleAlertComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
