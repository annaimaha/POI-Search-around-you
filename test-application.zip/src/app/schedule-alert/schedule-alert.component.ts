import { Component, OnDestroy, Input, style, state, animate, transition, trigger, SimpleChange, OnChanges, EventEmitter, Output } from '@angular/core';
import { SelectItem, CalendarModule } from 'primeng/primeng';
@Component({
  selector: 'schedule-alert',
  templateUrl: './schedule-alert.component.html',
  animations: [
    trigger('flyInOut', [
      state('in', style({ transform: 'translateX(0)' })),
      transition('void => *', [
        style({ transform: 'translateX(-100%)' }),//
        animate(100)
      ]),
      transition('* => void', [
        animate(50, style({ transform: 'translateX(-100%)' }))
      ])
    ])
  ]
})
export class ScheduleAlertComponent  implements OnChanges {
 @Input() schedule: any;
  @Input() scheduleAlert: any;

  @Output() changeEndTimeSpeed = new EventEmitter();
  weekDays: SelectItem[];
  currentDate: any;
  days: any;
  daysFlag: any;
  selectedDay: any;
  invalidDates: any;
  minDate: Date;
  timeArray = ["", "00:00 AM", "00:30 AM", "01:00 AM",
    "01:30 AM", "02:00 AM", "02:30 AM", "03:00 AM", "03:30 AM",
    "04:00 AM", "04:30 AM", "05:00 AM", "05:30 AM", "06:00 AM",
    "06:30 AM", "07:00 AM", "07:30 AM", "08:00 AM", "08:30 AM",
    "09:00 AM", "09:30 AM", "10:00 AM", "10:30 AM", "11:00 AM",
    "11:30 AM", "12:00 PM", "12:30 PM", "01:00 PM", "01:30 PM",
    "02:00 PM", "02:30 PM", "03:00 PM", "03:30 PM", "04:00 PM",
    "04:30 PM", "05:00 PM", "05:30 PM", "06:00 PM", "06:30 PM",
    "07:00 PM", "07:30 PM", "08:00 PM", "08:30 PM", "09:00 PM",
    "09:30 PM", "10:00 PM", "10:30 PM", "11:00 PM", "11:30 PM"];

  constructor() {
    this.minDate = new Date();
    this.days = { 0: "sun", 1: "mon", 2: "tue", 3: "wed", 4: "thur", 5: "fri", 6: "sat" };
    this.daysFlag = { "sun": true, "mon": true, "tue": true, "wed": true, "thur": true, "fri": true, "sat": true };
    this.currentDate = new Date();

    this.selectedDay = [this.days[this.currentDate.getDay()]];

    this.weekDays = [];
    this.weekDays.push({ label: 'S', value: 'sun' });
    this.weekDays.push({ label: 'M', value: 'mon' });
    this.weekDays.push({ label: 'T', value: 'tue' });
    this.weekDays.push({ label: 'W', value: 'wed' });
    this.weekDays.push({ label: 'T', value: 'thur' });
    this.weekDays.push({ label: 'F', value: 'fri' });
    this.weekDays.push({ label: 'S', value: 'sat' });
  }
  ngOnInit() {    
    if (this.schedule !== null && this.schedule !== '') {
      this.selectedDay = [];
      if (this.schedule.sun) this.selectedDay.push("sun");      
      if (this.schedule.mon) this.selectedDay.push("mon");    
      if (this.schedule.tue) this.selectedDay.push("tue");
      if (this.schedule.wed) this.selectedDay.push("wed");
      if (this.schedule.thur) this.selectedDay.push("thur");
      if (this.schedule.fri) this.selectedDay.push("fri");
      if (this.schedule.sat) this.selectedDay.push("sat");      
    }
  }
  dailyChecked($event) {
    if ($event) {
      this.schedule.weeklyFlag = false;
      this.schedule.everyDay = "true";
      this.schedule.recurringDays = 1;
      this.schedule.everyWeek = false;
      this.schedule.recurringWeeks = "";
      this.schedule.everyWeekDayOnly = "";
    }
  }
  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
    if (changes['scheduleAlert'] && (changes['scheduleAlert'].previousValue != changes['scheduleAlert'].currentValue) && changes['scheduleAlert'].currentValue) {
      this.getScheduleAlert();
    }
  }
  getScheduleAlert() {
    this.populateDays();
    this.schedule.everyDay = (this.schedule.everyDay === true) ? true : false;
    this.schedule.everyWeekDayOnly = (this.schedule.everyWeekDayOnly === "everyWeekDayOnly") ? true : false;
  }
  populateDays() {
    var days = ['sun', 'mon', 'tue', 'wed', 'thur', 'fri', 'sat'];
    for (var ctr = 0; ctr < days.length; ctr++) {
      this.schedule[days[ctr]] = false;
    }
    for (var i = 0; i < this.selectedDay.length; i++) {
      this.schedule[this.selectedDay[i]] = true;
    }
  }

  weeklyChecked($event) {
    if ($event) {
      this.schedule.dailyFlag = false;
      this.schedule.everyDay = "";
      this.schedule.recurringDays = "";
      this.schedule.everyWeek = "true";
      this.schedule.recurringWeeks = 1;
    }
  }

  dailyChange() {
    this.schedule.everyWeekDayOnly = "";
    this.schedule.recurringDays = "1";
  }
  workingDayChange() {
    this.schedule.everyDay = "";
    this.schedule.recurringDays = "";
  }
  updateGeofenceData() {
    let geofence = {
      everyDay: this.schedule.everyDay,
      recurringDays: this.schedule.recurringDays,
      recurringWeeks: this.schedule.recurringWeeks,

    }
  }


  /**
   * Methods to emit the event of time change 
   */
  endTimeChange(value) {
    this.changeEndTimeSpeed.emit(value);
  }


}
