import { Component, OnDestroy, Input, style, state, animate, transition, trigger } from '@angular/core';
import { VhrService } from '../vhr.service';
import { Message, DialogModule } from 'primeng/primeng';
import {myGlobals} from '../../../constants/globals';
import { HelperService } from '../../../services/helper.service';
@Component({
  selector: 'vhrHistory',
  providers: [VhrService, HelperService],
  templateUrl: './vhr-history.component.html',  
  animations: [
        trigger('flyInOut', [
            state('in', style({ transform: 'translateX(0)' })),
            transition('void => *', [
                style({ transform: 'translateX(-100%)' }),//
                animate(200)
            ]),
            transition('* => void', [
                animate(0, style({ transform: 'translateX(100%)' }))
            ])
        ])
    ]
})
export class VhrHistoryComponent {

    public data:any;
    public filterQuery = "";
    public rowsOnPage = myGlobals.rowsOnPage;
    public sortBy = "reasonGenerated";
    public sortOrder = myGlobals.sortOrder;
    deleteAll: any;
    msgs: Message[] = [];
    errormsgs: any;
    errorMsg: any;
    loading: any;
    loadingData: any;
    geofence: any;
    showVHRview: any;
    showTable: any;
    ids = {};
    growlLife: Number = myGlobals.disAppearTimeMessage;
    multiDelete = {
        checked: false
    };

    viewHrObj: any;

    constructor(private vhrService: VhrService, public helper: HelperService) {
        this.deleteAll = false;
        this.showTable = true;
    }

    ngOnInit() {
        this.Vhrhistory();
    }

    // Method to view the history OF VHR
    Vhrhistory() {
        this.vhrService.getViewHrHistory().subscribe(
            info => {
                if (!(JSON.stringify(info) === JSON.stringify([]))) {
                    this.data = info;

                } else {
                    this.errormsgs = myGlobals.noData;
                }
            },
            error => {
                this.errormsgs = error;
            }
        );
    }

    viewtheVHR(value: any) {
        this.loading = true;
        this.vhrService.detailsviewVhrHistory(value).subscribe(
            info => {
                this.viewHrObj = info;
                this.loading = false;
                this.showVHRview = true;
            }
        );
    }


    selectAllDeselect(result:any) {
        this.multiDelete.checked = result;
    }

    /**
     * Methods  to removeAll
     */
    removeAll(items:any) {
       let ids = this.helper.removeAll(items);
       this.remove(ids);
    }


    /*
    Methods to delete the ids records
    @param value object : specific records details
    */
    remove(ids: any) {
        this.loading = true;
        
        if (ids !== "") {
            let id = "&vhrList=" + ids;
            this.vhrService.deleteVhrHistory(id).subscribe(
                info => {
                    this.manageResponse(info)
                }, error => {
                    this.errors(error);
                }
            );

        } else {
            this.loading = false;
            this.msgs.push({ severity: 'error', summary: '', detail: myGlobals.nomultidelete });
        }
    }


    manageResponse(info) {
        this.loading = false;
        if (info['responseStatus'] == 'success') {
            this.Vhrhistory();
            this.msgs.push({ severity: 'success', summary: '', detail: myGlobals.deleteRecord });            
        } else {
            this.msgs.push({ severity: 'error', summary: '', detail: info['responseDescription'] });            
        }

    }

    /*
     Methods to Manage error Response
    @param info object response  details
    */
    errors(error) {
        this.loading = false;
        this.msgs.push({ severity: 'error', summary: '', detail: error });
    }

}
