// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { VhrHistoryComponent } from './vhr-history.component';

// describe('VhrHistoryComponent', () => {
//   let component: VhrHistoryComponent;
//   let fixture: ComponentFixture<VhrHistoryComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ VhrHistoryComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(VhrHistoryComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
