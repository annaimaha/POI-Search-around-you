// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { VehicleHealthReportComponent } from './vehicle-health-report.component';

// describe('VehicleHealthReportComponent', () => {
//   let component: VehicleHealthReportComponent;
//   let fixture: ComponentFixture<VehicleHealthReportComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ VehicleHealthReportComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(VehicleHealthReportComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
