import {Component, OnDestroy, Input, style, state, animate, transition, trigger } from '@angular/core';
@Component({
  selector: 'vehicleHealthReport',
  templateUrl: './vehicle-health-report.component.html',
  styleUrls: ['./vehicle-health-report.component.css']
})
export class VehicleHealthReportComponent  {
 
  tabName:any;
  constructor() {
		 this.tabName="Alert";
  }

  vtpTabs(vtpTabs:any){
	  this.tabName	= "";
	  this.tabName	= vtpTabs;
  }
}
