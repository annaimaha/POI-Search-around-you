import { Component, OnDestroy, Input, style, state, animate, transition, trigger } from '@angular/core';
import { VHRIndermediate } from '../../../model/VHRIndermediate.model';
import { PeriodicVHRDTO } from '../../../model/PeriodicVHR.model';
import { VhrService } from '../vhr.service';
import { myGlobals } from '../../../constants/globals';
import { Message, DialogModule, DropdownModule } from 'primeng/primeng';
@Component({
  selector: 'vhrRequestOrConfig',
  templateUrl: './vhr-requst-or-config.component.html',
  providers: [VhrService],
  animations: [
    trigger('flyInOut', [
      state('in', style({ transform: 'translateX(0)' })),
      transition('void => *', [
        style({ transform: 'translateX(-100%)' }),//
        animate(500)
      ]),
      transition('* => void', [
        animate(500, style({ transform: 'translateX(-100%)' }))
      ])
    ]), trigger('flyUpDown', [
      state('in', style({ transform: 'translateY(0)' })),
      transition('void => *', [
        style({ transform: 'translateY(-100%)' }),//
        animate(500)
      ]),
      transition('* => void', [
        animate(500, style({ transform: 'translateY(-100%)' }))
      ])
    ])
  ]
})
export class VhrRequstOrConfigComponent {

  information: any;
  submitted: any;

  months = [];
  days = [];
  //days = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30];
  vhrindermediate = new VHRIndermediate(true, "", true, "", false);
  periodicVhr = new PeriodicVHRDTO(true, null, true, "", false, false, '', '', false, this.months[0], this.days[0]);
  msgs: Message[] = [];
  loading: any;
  growlLife: Number = myGlobals.disAppearTimeMessage;
  showVhrConfig: any;
  constructor(private vhrService: VhrService) {
    // this.periodicVhr.phoneNumber = 8123767745
    // this.vhrindermediate.phoneNumber = '8123767745';
    this.months = [];
    this.months.push({ label: '1', value: '1' });
    this.months.push({ label: '3', value: '3' });
    this.months.push({ label: '6', value: '6' });
    this.months.push({ label: '12', value: '12' });
    this.days = [];
    for (var i = 1; i <= 30; i++) {
      this.days.push({ label: i, value: i });
    }

    if (sessionStorage["accountInfo"]) {
      this.information = JSON.parse(sessionStorage["accountInfo"]);
      // VHR vhrindermediate

      this.vhrindermediate.phoneNumber = this.information.userDTO.phoneNumber;
      this.vhrindermediate.emailId = this.information.userDTO.email;
      this.vhrindermediate.webOnly = false;

      // VHR PeriodicVHRDTO

      this.periodicVhr.phoneNumber = this.information.userDTO.phoneNumber;
      this.periodicVhr.emailId = this.information.userDTO.email;
      this.periodicVhr.numberOfMonthsTimeVhr = this.months[0];
      this.periodicVhr.dayOfMonthGenerateReport = this.days[0];
    }


  }

  requestIntermediateVhr() {
    this.loading = true;
    this.vhrService.indermediateVhr(this.vhrindermediate, { vin: this.information['vin'], tcuId: this.information['tcuId'], accountId: this.information['accountNumber'] }).subscribe(
      info => {
        this.loading = false;
        this.msgs.push({ severity: 'success', summary: '', detail: myGlobals.requestSent });
        this.information = info;
        this.showVhrConfig = true;
      },
      error => {
        this.msgs.push({ severity: 'error', summary: '', detail: error });
      }
    );


  }

  periodicVhrforms() {
    this.loading = true;
    this.submitted = true;
    this.vhrService.periodicVhr(this.periodicVhr, '').subscribe(
      info => {
        this.loading = false;
        this.msgs.push({ severity: 'success', summary: '', detail: myGlobals.requestSent });
      },
      error => {
        this.msgs.push({ severity: 'error', summary: '', detail: error });
      }
    );
  }

}
