import { ComponentFixture, inject, TestBed, async, fakeAsync, tick } from '@angular/core/testing';

import { VhrRequstOrConfigComponent } from './vhr-requst-or-config.component';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateService, TranslationChangeEvent } from '@ngx-translate/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {TooltipModule} from 'primeng/primeng';
import { VhrService } from '../vhr.service';
import {Http, HttpModule,  ResponseOptions, XHRBackend} from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { Observable } from 'rxjs/Observable';
import { MockBackend } from '@angular/http/testing';
import { Component, OnInit, Input, style, state, animate, transition, trigger, EventEmitter, Output } from '@angular/core';
 import {CheckboxModule} from 'primeng/primeng';
import {GrowlModule} from 'primeng/primeng';
import {DialogModule} from 'primeng/primeng';
import {InputSwitchModule} from 'primeng/primeng';
import {DropdownModule} from 'primeng/primeng';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {NoopAnimationsModule} from '@angular/platform-browser/animations';

@Component({
    selector: 'viewVhr',
    template: ''
})
export class FakeViewVhrComponent {
    @Input() data;
}

@Component({
    selector: 'loading-gif-data',
    template: ''
})
export class FakeLoadingGifDataComponent {
}

@Component({
    selector: 'perfect-scrollbar',
    template: ''
})
export class FakePerfectScrollbarComponent {
    @Input() runInsideAngular;
}


  describe('VhrRequstOrConfigComponent', () => {
  function findElement(fixture: ComponentFixture<VhrRequstOrConfigComponent>, selector: string): any {
    return fixture.debugElement.query(By.css(selector)).nativeElement;
  }

    let comp: VhrRequstOrConfigComponent;
  let fixture: ComponentFixture<VhrRequstOrConfigComponent>;
  let de: DebugElement;
  let el: HTMLElement;
  let viewVhrObj:any;
  let accountInfo:string;
  let accountInfoObj:any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), FormsModule, TooltipModule, HttpModule, BrowserModule,
      CheckboxModule, GrowlModule, DialogModule, InputSwitchModule,DropdownModule, NoopAnimationsModule],
      declarations: [ VhrRequstOrConfigComponent,
      FakeLoadingGifDataComponent, FakePerfectScrollbarComponent, FakeViewVhrComponent],
      providers: [TranslateService, VhrService,{ provide: XHRBackend, useClass: MockBackend }]
    })
    .compileComponents();

    accountInfo = '{"userDTO":{"firstName":"FRANK","lastName":"TESTER1","city":"ATLANTA","address1":"2001 SUMMIT BLVD","address2":"STE500","state":"GA","zip":"30318","email":"gjyothi@prokarma.com","phoneNumber":"1234567891","pin":"8989","vin":null,"emergency_firstName":null,"emergency_lastName":null,"emergency_phone":null,"accountId":null,"accountCRMId":"10550563","transaction":null,"customerId":null,"tcuId":null,"userTimeZoneString":null,"primaryNumber":"Mobile","userId":"haritha.kulakarni@hughestelematics.com,jeff.nibler@verizon.com,pmanzi_itest1@vw.com,elena.register@verizon.com,cgaleas-itest1@volkswagen.com,Bhanoday.Saranam@hughestelematics.com,verizontest234@gmail.com,nathaniel.curtis@hughestelematics.com,test@volkswagen.com,hello@dustin-stone.com,rmukkavilli@abc.com,mohithuslocal@vw.com"}}';
    sessionStorage.setItem('accountInfo',accountInfo);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VhrRequstOrConfigComponent);
    comp = fixture.componentInstance;
    accountInfoObj = {userDTO: {
    firstName: "FRANK",
    lastName: "TESTER1",
    city: "ATLANTA",
    address1: "2001 SUMMIT BLVD",
    address2: "STE500",
    state: "GA",
    zip: "30318",
    email: "gjyothi@prokarma.com",
    phoneNumber: "1234567891",
    pin: "8989",
    vin: null,
    emergency_firstName: null,
    emergency_lastName: null,
    emergency_phone: null,
    accountId: null,
    accountCRMId: "10550563",
    transaction: null,
    customerId: null,
    tcuId: null,
    userTimeZoneString: null,
    primaryNumber: "Mobile",
    userId: "haritha.kulakarni@hughestelematics.com,jeff.nibler@verizon.com,pmanzi_itest1@vw.com,elena.register@verizon.com,cgaleas-itest1@volkswagen.com,Bhanoday.Saranam@hughestelematics.com,verizontest234@gmail.com,nathaniel.curtis@hughestelematics.com,test@volkswagen.com,hello@dustin-stone.com,rmukkavilli@abc.com,mohithuslocal@vw.com"
  }}
    });

    it('true is true', () => {
    expect(true).toEqual(true);
  });

  it('can instantiate it', () => {
    expect(comp).not.toBeNull();
  });

    it('Vhr config should be empty initially until manually call `detectChanges', () => {
    de = fixture.debugElement.query(By.css('.vhr-config-title'));
    el = de.nativeElement;

    expect(el.textContent).toBe('');
  });

  it('Vhr config after initialization', () => {

    de = fixture.debugElement.query(By.css('.vhr-config-title'));
    el = de.nativeElement;

    fixture.detectChanges();
    expect(el.textContent).toContain('VHR_CONFIG.VHR_CONFIG_TITLE');
  });

  
 it('should call requestIntermediateVhr subscribe success', async(() => {

     let vhrService = fixture.debugElement.injector.get(VhrService);
     let body = accountInfoObj
    spyOn(vhrService, 'indermediateVhr').and.returnValue(Observable.of(body));
    fixture.detectChanges();
    expect(comp.requestIntermediateVhr()).toBeDefined;
    expect(vhrService.indermediateVhr).toHaveBeenCalled();
    expect(comp.loading).toBeFalsy();
    expect(comp.information).toEqual(body);
    expect(comp.showVhrConfig).toBeTruthy();
  }));

it('should call requestIntermediateVhr subscribe fail', async(() => {

     let vhrService = fixture.debugElement.injector.get(VhrService);
     let event = {obj:'value'};
    spyOn(vhrService, 'indermediateVhr').and.returnValue(Observable.throw('error thrown'));
    fixture.detectChanges();
    expect(comp.requestIntermediateVhr()).toBeDefined;
    expect(vhrService.indermediateVhr).toHaveBeenCalled();
    expect(comp.msgs[0]).toEqual({ severity: 'error', summary: '', detail: 'error thrown' });
  }));


 it('should call periodicVhrforms subscribe success', async(() => {

     let vhrService = fixture.debugElement.injector.get(VhrService);
     let body = {statusCode:'200', status:'success'}
    spyOn(vhrService, 'periodicVhr').and.returnValue(Observable.of(body));
    fixture.detectChanges();
    expect(comp.periodicVhrforms()).toBeDefined;
    expect(vhrService.periodicVhr).toHaveBeenCalled();
    expect(comp.loading).toBeFalsy();
    expect(comp.msgs[0]).toEqual({ severity: 'success', summary: '', detail: 'Request has been sent successfully.' });
  }));

it('should call periodicVhrforms subscribe fail', async(() => {

     let vhrService = fixture.debugElement.injector.get(VhrService);
     let event = {obj:'value'};
    spyOn(vhrService, 'periodicVhr').and.returnValue(Observable.throw('error thrown'));
    fixture.detectChanges();
    expect(comp.periodicVhrforms()).toBeDefined;
    expect(vhrService.periodicVhr).toHaveBeenCalled();
    expect(comp.msgs[0]).toEqual({ severity: 'error', summary: '', detail: 'error thrown' });
  }));
});
