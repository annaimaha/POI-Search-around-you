import { ComponentFixture, inject, TestBed, async, fakeAsync, tick } from '@angular/core/testing';

import { ViewVhrComponent } from './view-vhr.component';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateService, TranslationChangeEvent } from '@ngx-translate/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {TooltipModule} from 'primeng/primeng';
import { VhrService } from '../vhr.service';
import {Http, HttpModule,  ResponseOptions, XHRBackend} from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { Observable } from 'rxjs/Observable';
import { MockBackend } from '@angular/http/testing';
import { Component, OnInit, Input, style, state, animate, transition, trigger, EventEmitter, Output } from '@angular/core';
 
@Component({
    selector: 'loading-gif-data',
    template: ''
})
export class FakeLoadingGifDataComponent {
}


 describe('ViewVhrComponent', () => {
  function findElement(fixture: ComponentFixture<ViewVhrComponent>, selector: string): any {
    return fixture.debugElement.query(By.css(selector)).nativeElement;
  }

    let comp: ViewVhrComponent;
  let fixture: ComponentFixture<ViewVhrComponent>;
  let de: DebugElement;
  let el: HTMLElement;
  let viewVhrObj:any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), FormsModule, TooltipModule, HttpModule, BrowserModule],
      declarations: [ ViewVhrComponent, FakeLoadingGifDataComponent],
      providers: [TranslateService, VhrService,{ provide: XHRBackend, useClass: MockBackend }]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewVhrComponent);
    comp = fixture.componentInstance;
    viewVhrObj = {
         accountId:'1234',
        vin:'12345',
        tcuid:'123456',
        vehicleReportCommand:'abc',
        collectionMethod:'yes',
         startMileage:'150',
         distance:'250',
        emailId:'abc@gmail.com',
        phoneNumber:'81237677298',
        noneFlag:true,
        smsFlag:true,
        emailFlag:true,
        serviceKeyState:'stable',
        serviceKeyData:'data',
        timestamp:'12:15',
        timestampDate:Date,
        schedule:'xyz',
        dayInterval:'2',
        dayOfWeek:'5',
        weekInterval:'1',
        transactionId:'1234',
        dateDisplay:'12/15/2017',
        responseStatus:'success',
         refresh:true,
        timeBasedVhrFlag:true,
        numberOfMonthsTimeVhr:'abc',
        dayOfMonthGenerateReport:'sdfgr',
        distanceBasedVhrFlag:true,
        numberOfMilesBetweenReport:'20000',
        maintenanceDistanceBasedVhrFlag:true,
        distanceMaintenanceDistance:'250',
        reasonGenerated:'success',
        vhrServiceTime:'12:15',
        vehicleAlertId:'2345',
        reportReason:'reason',
        activeFlag:'yes',
        reasonCodeId:'5435',
        serviceKeyDataId:'123457',
        serviceKeyDataStateId:'4321',
        isPeriodic:true,
        isOneTime:true,
        numberOfMonthsTimeVhrList :'xyz',
         startMileageList:'xyz',
         dayOfMonthGenerateReportList:'xyz',
         numberOfMilesBetweenReportList:'xyz',
          distanceMaintenanceDistanceList:'xyz'
    }
  });

      it('true is true', () => {
    expect(true).toEqual(true);
  });

  it('can instantiate it', () => {
    expect(comp).not.toBeNull();
  });

    it('view vhr label should be empty initially until manually call `detectChanges', () => {
        comp.data = true;
        comp.active = true;
    de = fixture.debugElement.query(By.css('.timestamp-label'));
    expect(de).toBeNull();
  });

  it('view vhr label after initialization', () => {
        comp.data = true;
        comp.active = true;
    fixture.detectChanges();

    de = fixture.debugElement.query(By.css('.timestamp-label'));
    el = de.nativeElement;

    fixture.detectChanges();
    expect(el.textContent).toContain('Service Key Data Timestamp');
  });

    it('should call getViewHr subscribe success IF', async(() => {

     let vhrService = fixture.debugElement.injector.get(VhrService);
     
     let body = [viewVhrObj]
    spyOn(vhrService, 'getViewHr').and.returnValue(Observable.of(body));
    fixture.detectChanges();
    expect(comp.ngOnInit()).toBeDefined;
    expect(vhrService.getViewHr).toHaveBeenCalled();
    expect(comp.data).toEqual(body[0]);
  }));

    it('should call getViewHr subscribe success IF', async(() => {

     let vhrService = fixture.debugElement.injector.get(VhrService);
     
     let body = []
    spyOn(vhrService, 'getViewHr').and.returnValue(Observable.of(body));
    fixture.detectChanges();
    expect(comp.ngOnInit()).toBeDefined;
    expect(vhrService.getViewHr).toHaveBeenCalled();
    expect(comp.errormsgs).toEqual('No Records Found.');
    expect(comp.loadingdata).toBeFalsy();
  }));

    it('should call getViewHr subscribe fail', async(() => {

     let vhrService = fixture.debugElement.injector.get(VhrService);
    spyOn(vhrService, 'getViewHr').and.returnValue(Observable.throw('error in fetching'));
    fixture.detectChanges();
    expect(comp.ngOnInit()).toBeDefined;
    expect(vhrService.getViewHr).toHaveBeenCalled();
    expect(comp.errormsgs).toBe('error in fetching');
    expect(comp.loadingdata).toBeFalsy();
  }));



 });