import { Component, OnDestroy, Input, style, state, animate, transition, trigger } from '@angular/core';
import { Viewvhr } from '../../../model/Viewvhr.DTO';
import { VhrService } from '../vhr.service';
import {myGlobals} from '../../../constants/globals';
@Component({
  selector: 'viewVhr',
  templateUrl: './view-vhr.component.html',
  providers: [VhrService]
})
export class ViewVhrComponent  {
	
  information: any;
  @Input() data: any;
  active: any;
  errormsgs: any;
  loadingdata: any;
  viewvhr = new Viewvhr('', '', '', '', '', '', '', '', '', false, false, false, '', '', '', null, '', '', '', '', '', '', '', false, false, '', '', false, '', false, '', '', '', '', '', '', '', '', '', false, false, null, null, null, null, null);
  constructor(private vhrService: VhrService) {
  }

  ngOnInit() {
    this.loadingdata = true;
    this.vhrService.getViewHr().subscribe(
      info => {
        if (!(JSON.stringify(info) === JSON.stringify([]))) {
          this.active = true;
          this.data = info[0];
          this.loadingdata = false;
        } else {
          this.errormsgs = myGlobals.noData;
          this.loadingdata = false;
        }
      },
      error => {
        this.loadingdata = false;
        this.errormsgs = error;
      }
    );
  }
}
