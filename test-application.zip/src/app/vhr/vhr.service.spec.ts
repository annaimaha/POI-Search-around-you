import { TestBed, async, inject, tick } from '@angular/core/testing'; //, addProviders 
import {
  HttpModule,
  Http,
  Response,
  ResponseOptions,
  XHRBackend,
  ResponseType
} from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { VhrService } from './vhr.service';
//import { serviceUrls } from '../../../environments/environment'
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';
import { myGlobals } from '../../constants/globals';
import 'rxjs/add/observable/throw';

describe('VhrService', () => {
  let accountNumber: any;
  let postData: any;
  let queryParam:any;
  let vhrDataObj:any
  let idstoDelete:any
  let vehicleAlertIdDetails:any;
  // let ownerTransferObj:OwnerTransfer;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpModule],
      providers: [
        VhrService,
        { provide: XHRBackend, useClass: MockBackend },
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    accountNumber = '123456';
    postData = 'acountinfo:123456';
    vhrDataObj = {
         accountId:'1234',
        vin:'12345',
        tcuid:'123456',
        vehicleReportCommand:'abc',
        collectionMethod:'yes',
         startMileage:'150',
         distance:'250',
        emailId:'abc@gmail.com',
        phoneNumber:'81237677298',
        noneFlag:true,
        smsFlag:true,
        emailFlag:true,
        serviceKeyState:'stable',
        serviceKeyData:'data',
        timestamp:'12:15',
        timestampDate:Date,
        schedule:'xyz',
        dayInterval:'2',
        dayOfWeek:'5',
        weekInterval:'1',
        transactionId:'1234',
        dateDisplay:'12/15/2017',
        responseStatus:'success',
         refresh:true,
        timeBasedVhrFlag:true,
        numberOfMonthsTimeVhr:'abc',
        dayOfMonthGenerateReport:'sdfgr',
        distanceBasedVhrFlag:true,
        numberOfMilesBetweenReport:'20000',
        maintenanceDistanceBasedVhrFlag:true,
        distanceMaintenanceDistance:'250',
        reasonGenerated:'success',
        vhrServiceTime:'12:15',
        vehicleAlertId:'2345',
        reportReason:'reason',
        activeFlag:'yes',
        reasonCodeId:'5435',
        serviceKeyDataId:'123457',
        serviceKeyDataStateId:'4321',
        isPeriodic:true,
        isOneTime:true,
        numberOfMonthsTimeVhrList :'xyz',
         startMileageList:'xyz',
         dayOfMonthGenerateReportList:'xyz',
         numberOfMilesBetweenReportList:'xyz',
          distanceMaintenanceDistanceList:'xyz'
    }

    postData = vhrDataObj;
    queryParam = 'index=200&isOneTime=true';    
    idstoDelete = ['1234','12345'];
    vehicleAlertIdDetails = {vehicleAlertId:'12345'};
  });

    function cast<T>(obj, cl): T {
        obj.__proto__ = cl.prototype;
        return obj;
    }

      describe('getViewHr()', () => {

    it('should return an Observable<any>',
      inject([VhrService, XHRBackend], (VhrService, mockBackend) => {

        const mockResponse = {
          Status: '200',
          StatusDesc: 'success',
          vhrData:vhrDataObj
        } //"Status:'200', StatusDesc:'success'";

        mockBackend.connections.subscribe((connection) => {
          connection.mockRespond(new Response(new ResponseOptions({
            body: JSON.stringify(mockResponse)
          })));
        });

        VhrService.getViewHr().subscribe((response) => {
          expect(Object.keys(response).length).toBe(3);
          expect(response.Status).toEqual('200');
          expect(response.StatusDesc).toEqual('success');
          expect(response.vhrData.accountId).toEqual('1234');
          expect(response.vhrData.vin).toEqual('12345');
        });

      }));

  });

  it('getViewHr should log an error to the console on error', inject([VhrService, XHRBackend], (VhrService, mockBackend) => {

    mockBackend.connections.subscribe(
      (connection) => {
        connection.mockError(new Error('error thrown'));
      });

    VhrService.getViewHr().subscribe((error) => { },
      error => {
        spyOn(console, 'error');
        console.error(error);
        expect(console.error).toHaveBeenCalled();
        expect(console.error).toHaveBeenCalledWith(error);
      });
  }));


      describe('periodicVhr()', () => {

    it('should return an Observable<any>',
      inject([VhrService, XHRBackend], (VhrService, mockBackend) => {

        const mockResponse = {
          Status: '200',
          StatusDesc: 'success',
        } //"Status:'200', StatusDesc:'success'";

        mockBackend.connections.subscribe((connection) => {
          connection.mockRespond(new Response(new ResponseOptions({
            body: JSON.stringify(mockResponse)
          })));
        });

        VhrService.periodicVhr(postData,queryParam).subscribe((response) => {
          expect(Object.keys(response).length).toBe(2);
          expect(response.Status).toEqual('200');
          expect(response.StatusDesc).toEqual('success');
        });

      }));

  });

  it('getViewHr should log an error to the console on error', inject([VhrService, XHRBackend], (VhrService, mockBackend) => {

    mockBackend.connections.subscribe(
      (connection) => {
        connection.mockError(new Error('error thrown'));
      });

    VhrService.periodicVhr(postData,queryParam).subscribe((error) => { },
      error => {
        spyOn(console, 'error');
        console.error(error);
        expect(console.error).toHaveBeenCalled();
        expect(console.error).toHaveBeenCalledWith(error);
      });
  }));


      describe('indermediateVhr()', () => {

    it('should return an Observable<any>',
      inject([VhrService, XHRBackend], (VhrService, mockBackend) => {

        const mockResponse = {
          Status: '200',
          StatusDesc: 'success',
        } //"Status:'200', StatusDesc:'success'";

        mockBackend.connections.subscribe((connection) => {
          connection.mockRespond(new Response(new ResponseOptions({
            body: JSON.stringify(mockResponse)
          })));
        });

        VhrService.indermediateVhr(postData,queryParam).subscribe((response) => {
          expect(Object.keys(response).length).toBe(2);
          expect(response.Status).toEqual('200');
          expect(response.StatusDesc).toEqual('success');
        });

      }));

  });

  it('indermediateVhr should log an error to the console on error', inject([VhrService, XHRBackend], (VhrService, mockBackend) => {

    mockBackend.connections.subscribe(
      (connection) => {
        connection.mockError(new Error('error thrown'));
      });

    VhrService.indermediateVhr(postData,queryParam).subscribe((error) => { },
      error => {
        spyOn(console, 'error');
        console.error(error);
        expect(console.error).toHaveBeenCalled();
        expect(console.error).toHaveBeenCalledWith(error);
      });
  }));

      describe('getViewHrHistory()', () => {

    it('should return an Observable<any>',
      inject([VhrService, XHRBackend], (VhrService, mockBackend) => {

        const mockResponse = {
          Status: '200',
          StatusDesc: 'success',
          vhrData:vhrDataObj
        } //"Status:'200', StatusDesc:'success'";

        mockBackend.connections.subscribe((connection) => {
          connection.mockRespond(new Response(new ResponseOptions({
            body: JSON.stringify(mockResponse)
          })));
        });

        VhrService.getViewHrHistory().subscribe((response) => {
          expect(Object.keys(response).length).toBe(3);
          expect(response.Status).toEqual('200');
          expect(response.StatusDesc).toEqual('success');
          expect(response.vhrData.accountId).toEqual('1234');
          expect(response.vhrData.vin).toEqual('12345');
        });

      }));

  });

  it('getViewHrHistory should log an error to the console on error', inject([VhrService, XHRBackend], (VhrService, mockBackend) => {

    mockBackend.connections.subscribe(
      (connection) => {
        connection.mockError(new Error('error thrown'));
      });

    VhrService.getViewHrHistory().subscribe((error) => { },
      error => {
        spyOn(console, 'error');
        console.error(error);
        expect(console.error).toHaveBeenCalled();
        expect(console.error).toHaveBeenCalledWith(error);
      });
  }));

      describe('deleteVhrHistory()', () => {

    it('should return an Observable<any>',
      inject([VhrService, XHRBackend], (VhrService, mockBackend) => {

        const mockResponse = {
          Status: '200',
          StatusDesc: 'success',
        } //"Status:'200', StatusDesc:'success'";

        mockBackend.connections.subscribe((connection) => {
          connection.mockRespond(new Response(new ResponseOptions({
            body: JSON.stringify(mockResponse)
          })));
        });

        VhrService.deleteVhrHistory(idstoDelete).subscribe((response) => {
          expect(Object.keys(response).length).toBe(2);
          expect(response.Status).toEqual('200');
          expect(response.StatusDesc).toEqual('success');
        });

      }));

  });

  it('deleteVhrHistory should log an error to the console on error', inject([VhrService, XHRBackend], (VhrService, mockBackend) => {

    mockBackend.connections.subscribe(
      (connection) => {
        connection.mockError(new Error('error thrown'));
      });

    VhrService.deleteVhrHistory(idstoDelete).subscribe((error) => { },
      error => {
        spyOn(console, 'error');
        console.error(error);
        expect(console.error).toHaveBeenCalled();
        expect(console.error).toHaveBeenCalledWith(error);
      });
  }));

      describe('detailsviewVhrHistory()', () => {

    it('should return an Observable<any>',
      inject([VhrService, XHRBackend], (VhrService, mockBackend) => {

        const mockResponse = {
          Status: '200',
          StatusDesc: 'success',
          vhrData:vhrDataObj
        } //"Status:'200', StatusDesc:'success'";

        mockBackend.connections.subscribe((connection) => {
          connection.mockRespond(new Response(new ResponseOptions({
            body: JSON.stringify(mockResponse)
          })));
        });

        VhrService.detailsviewVhrHistory(vehicleAlertIdDetails).subscribe((response) => {
          expect(Object.keys(response).length).toBe(3);
          expect(response.Status).toEqual('200');
          expect(response.StatusDesc).toEqual('success');
          expect(response.vhrData.accountId).toEqual('1234');
          expect(response.vhrData.vin).toEqual('12345');
        });

      }));

  });

  it('detailsviewVhrHistory should log an error to the console on error', inject([VhrService, XHRBackend], (VhrService, mockBackend) => {

    mockBackend.connections.subscribe(
      (connection) => {
        connection.mockError(new Error('error thrown'));
      });

    VhrService.detailsviewVhrHistory(vehicleAlertIdDetails).subscribe((error) => { },
      error => {
        spyOn(console, 'error');
        console.error(error);
        expect(console.error).toHaveBeenCalled();
        expect(console.error).toHaveBeenCalledWith(error);
      });
  }));

  it('should call handleError', inject([VhrService, XHRBackend], (VhrService, mockBackend) => {
    let error: Response = <Response>{
      type: ResponseType.Error, status: 404, statusText: 'some error', ok: true, url: 'http://abc.com',
      bytesLoaded: 123456, totalBytes: 12345678}
    let responseOpts = new ResponseOptions(error)
    cast<Response>(responseOpts, Response);       
      expect(VhrService.handleError(responseOpts)).toBeDefined();
  }));



});