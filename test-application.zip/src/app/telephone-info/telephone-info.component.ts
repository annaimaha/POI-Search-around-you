import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'telephoneInfo',
  templateUrl: 'telephone-info.component.html',
  styleUrls: ['telephone-info.component.css']
})
export class TelephoneInfoComponent implements OnInit {
 @Input() telephoneInfo:any;
    disabled: boolean = true;
    constructor() {
      this.telephoneInfo = {}
     }

    ngOnInit() {

    }

}
