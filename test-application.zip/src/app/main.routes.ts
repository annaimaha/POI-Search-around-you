import { Routes, RouterModule } from '@angular/router';
import { AccountCombinationComponent } from './account-combination/account-combination.component';
import { LandingComponent } from './landing/landing.component';
import { VehicleHealthReportComponent } from './vhr/vehicle-health-report/vehicle-health-report.component';
import { TripStatisticsComponent } from './trip-statistics/trip-statistics/trip-statistics.component';
import { InformationCallComponent } from './calls/icall/information-call/information-call.component';
import { EmergencyCallComponent } from './calls/ecall/emergency-call/emergency-call.component';
import { RoadAssistanceCallComponent } from './calls/rcall/road-assistance-call/road-assistance-call.component';
import { PoiComponent } from './location-services/poi/poi/poi.component';
import { GeofenceComponent } from './location-services/geofence/geofence/geofence.component';
import { SpeedAlertComponent } from './location-services/speed-alerts/speed-alert/speed-alert.component';
import { SvtComponent } from './location-services/svt/svt/svt.component';
import { DisablingAndHistoryComponent } from './location-services/vehicle-disabling/disabling-and-history/disabling-and-history.component';
import { VehicleStatusComponent } from './remote-access/vehicle-status/vehicle-status.component';
import { DoorlockunlockComponent } from './remote-access/rdlu/doorlockunlock/doorlockunlock.component';
import { HonkingandflashingComponent } from './remote-access/honk-flash/honkingandflashing/honkingandflashing.component';
import { BatteryChargingComponent } from './electric-vehicle/battery-charging/battery-charging/battery-charging.component';
import { RemoteClimatizationComponent } from './electric-vehicle/remote-climatization/remote-climatization/remote-climatization.component';
import { HonkflashhistoryComponent } from './remote-access/honk-flash/honkflashhistory/honkflashhistory.component';
import { RemoteDepatureTimeComponent } from './electric-vehicle/remote-departure-time/remote-depature-time/remote-depature-time.component';
import { NotFoundComponent } from './not-found/not-found.component';
export const mainroutes: Routes = [
  {
    path: '',
    component: LandingComponent,
    children: [
		{
			path: '', redirectTo: 'landing', pathMatch: 'full'
      	}, {
        	path: 'landing', 
			component: AccountCombinationComponent
      	}, { 
			path: 'vehiclehealthreport', 
			component: VehicleHealthReportComponent 
		}, {
        	path: 'tripStatistics',
        	component: TripStatisticsComponent
      	}, {
        	path: 'informationCall',
        	component: InformationCallComponent
		}, {
        	path: 'emergencyCall',
        	component: EmergencyCallComponent
      	}, {
        	path: 'assistanceCall',
        	component: RoadAssistanceCallComponent
      	}, {
        	path: 'poi',
        	component: PoiComponent
      	}, { 
			path: 'geofence', 
			component: GeofenceComponent 
		}, {
        	path: 'speedAlert',
        	component: SpeedAlertComponent
      	}, {
        	path: 'svt',
        	component: SvtComponent
      	}, {
        	path: 'vehicledisabling',
        	component: DisablingAndHistoryComponent
      	}, {
        	path: 'vehiclestatus',
        	component: VehicleStatusComponent
      	}, {
        	path: 'doorlockunlock',
        	component: DoorlockunlockComponent
      	}, {
        	path: 'honkFlash',
        	component: HonkingandflashingComponent
      	}, {
        	path: 'batterycharging',
        	component: BatteryChargingComponent
      	}, {
        	path: 'climatization',
        	component: RemoteClimatizationComponent
      	}, {
        	path: 'honkflashhistory',
        	component: HonkflashhistoryComponent
      	}, {
        	path: 'depaturetime',
        	component: RemoteDepatureTimeComponent
      	}
    ]
  }
];
