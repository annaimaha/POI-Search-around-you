import { Pipe, PipeTransform } from '@angular/core';
declare var sessionStorage: any;
/*
 * Raise the value On or Off
 * Takes an value is true
 * Usage:
 *   value | onoroff
 * Example:
 *   {{ true |  onoroff}}
 *   formats to: On
*/

@Pipe({name: 'onoroff'})
export class OnoroffPipe implements PipeTransform {
  transform(value: any): any {
    //let exp = parseFloat(exponent);
    //return Math.pow(value, isNaN(exp) ? 1 : exp);
   return (value === true) ? "On" : "Off" ;
  }
}

@Pipe({name: 'isDeletedNeed'})
export class IsDeletedNeedPipe implements PipeTransform {
  transform(value: any): any {
    let isDeletedNeed = false;
    if(value !=="undefined"){
       for (let prop in value) {
         if(value[prop].deleteFlag === true && isDeletedNeed == false){
           isDeletedNeed = true;
         }
       }
    }       
    return isDeletedNeed;
  }
}