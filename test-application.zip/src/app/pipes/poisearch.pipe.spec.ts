import { PoisearchPipe } from './poisearch.pipe';

describe('PoisearchPipe', () => {
  it('create an instance', () => {
    const pipe = new PoisearchPipe();
    expect(pipe).toBeTruthy();
  });
});
