import { Pipe, PipeTransform } from '@angular/core';
/*
 * Raise the value On or Off
 * Takes an value is true
 * Usage:
 *   value | onoroff
 * Example:
 *   {{ true |  onoroff}}
 *   formats to: On
*/
@Pipe({ name: 'addingkm' })
export class addingkmPipe implements PipeTransform {

  transform(value: any): any {    
    return (value !== "" && value !== null ) ? value + " km" : "NA";
  }
}


@Pipe({ name: 'precentage' })
export class precentagePipe implements PipeTransform {

  transform(value: any): any {    
    return (value !== "" && value !== null) ? value + " %" : "NA";
  }
}


@Pipe({ name: 'amps' })
export class ampsPipe implements PipeTransform {

  transform(value: any): any {     
    return (value !==null && value !== "") ? value + " AMPS" : '';
  }
}


@Pipe({ name: 'hoursminutes' })
export class hoursminutesPipe implements PipeTransform {
  m:any;
  h:any;
  transform(value: any): any {
    if(value !=="" && value !== null){    
      this.h = Math.floor(value / 60);
      this.m = value % 60;
      this.h =this.h < 10 ? '0' + this.h : this.h;
      this.m = this.m < 10 ? '0' + this.m : this.m;
      return this.h+ ' Hr ' + ':' + this.m+' min ';
    }else{
      return "NA";
    }
  }
}