// import { BatterysettingsPipe } from './batterysettings.pipe';

// describe('BatterysettingsPipe', () => {
//   it('create an instance', () => {
//     const pipe = new BatterysettingsPipe();
//     expect(pipe).toBeTruthy();
//   });
// });
