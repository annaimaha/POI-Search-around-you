// import { RemotedeparturePipe } from './remotedeparture.pipe';

// describe('RemotedeparturePipe', () => {
//   it('create an instance', () => {
//     const pipe = new RemotedeparturePipe();
//     expect(pipe).toBeTruthy();
//   });
// });
