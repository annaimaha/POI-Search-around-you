import { Component, OnInit, Input} from '@angular/core';

@Component({
  selector: 'assetInfo',
  templateUrl: 'asset-info.component.html',
  styleUrls: ['asset-info.component.css']
})
export class AssetInfoComponent implements OnInit {
	@Input() assetInfo:any;
    disabled: boolean = true;
    constructor() { 
      this.assetInfo={}
    }

    ngOnInit() {
      
    }

}
