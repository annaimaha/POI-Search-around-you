import { ComponentFixture, inject, TestBed, async, fakeAsync, tick } from '@angular/core/testing';

import { AssetInfoComponent } from './asset-info.component';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateService, TranslationChangeEvent } from '@ngx-translate/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

describe('AssetInfoComponent', () => {

  function findElement(fixture: ComponentFixture<AssetInfoComponent>, selector: string): any {
    return fixture.debugElement.query(By.css(selector)).nativeElement;
  }

    let comp: AssetInfoComponent;
  let fixture: ComponentFixture<AssetInfoComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), FormsModule],
      declarations: [ AssetInfoComponent ],
      providers: [TranslateService],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetInfoComponent);
    comp = fixture.componentInstance;
  });

    it('true is true', () => {
    expect(true).toEqual(true);
  });

  it('can instantiate it', () => {
    expect(comp).not.toBeNull();
  });

  it('Telephone Info title should be empty initially until manually call `detectChanges', () => {
    de = fixture.debugElement.query(By.css('.assetInfo-title'));
    el = de.nativeElement;

    expect(el.textContent).toBe('');
  });

  it('Telephone Info title after initialization', () => {

    de = fixture.debugElement.query(By.css('.assetInfo-title'));
    el = de.nativeElement;

    fixture.detectChanges();
    expect(el.textContent).toContain('ASSETINFO.ASSETHEADER');
  });


});