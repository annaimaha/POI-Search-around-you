// import { TestBed, inject } from '@angular/core/testing';

// import { EnabledisableactivitylogService } from './enabledisableactivitylog.service';

// describe('EnabledisableactivitylogService', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       providers: [EnabledisableactivitylogService]
//     });
//   });

//   it('should ...', inject([EnabledisableactivitylogService], (service: EnabledisableactivitylogService) => {
//     expect(service).toBeTruthy();
//   }));
// });
