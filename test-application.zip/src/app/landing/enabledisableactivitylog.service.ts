import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { Http, Response, Headers, RequestOptions, URLSearchParams } from '@angular/http';
import { informationCallDTO } from '../../model/informationCallDTO';
import {myGlobals} from '../../constants/globals';

@Injectable()
export class EnabledisableactivitylogService {

    private headers:any;
    options:any;
    constructor(private http: Http) {
        this.headers = new Headers();
        this.headers.append('Content-Type', 'application/json');
        this.headers.append('api-key', 'vzt-vtp-locationsvc');
        this.options = {headers :this.headers,withCredentials: true};
    }

    // Methods to get the enable and disable services
    getEnableDisable() {
        return this.http.get(myGlobals.enableDisableServices + sessionStorage["params"], this.options)
            .map(this.extractData)
            .catch(this.handleError);
    }

    // Method to post the enable disable services

    enableDisablePost(postdata: any) {
        return this.http.post(myGlobals.enableDisableServicesRequest + sessionStorage["params"], postdata, this.options)
            .map(this.extractData)
            .catch(this.handleError);
    }


    // Activity Logs
    getlogs(postdata: any,page:any,size:any) {
        return this.http.get(myGlobals.log + sessionStorage["params"] + "&page="+page+"&size="+size, this.options)
            .map(this.extractData)
            .catch(this.handleError);
    }


    getlogsdays(postdata: any) {
        return this.http.get(myGlobals.dayWiseLog + sessionStorage["params"] +postdata+"&page=0&size=25", this.options)
            .map(this.extractData)
            .catch(this.handleError);
    }

    // Methods to get the Icall Details View data

    private extractData(res: Response) {
        let body = res.json();
        return body.data ? body.data : (body || {});
    }
    
    private handleError(error: Response | any) {
        // In a real world app, we might use a remote logging infrastructure
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} `;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        
        errMsg = (error.status == '0') ? myGlobals.badGateWay : errMsg;

        return Observable.throw(errMsg);
    }
}
