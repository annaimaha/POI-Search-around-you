import { Component, OnInit, EventEmitter, Output, style, state, animate, transition, trigger, ElementRef, ViewChild } from '@angular/core';
import { TranslateService } from 'ng2-translate';
import { Message, CalendarModule, DialogModule } from 'primeng/primeng';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { AccountService } from '../account-info/account.service';
import { MapResizeService} from '../../services/map-resize.service';
import { PagerService } from '../../services/pager.service';
import { AuthenticationService } from '../../services/authentication.service';
import { EnabledisableactivitylogService } from './enabledisableactivitylog.service';
import { enabledisableservicesDTO } from '../../model/enabledisableservicesDTO';
import { useractivelogDTO } from '../../model/useractivelogDTO';
import { TimeDto } from '../../model/timeDto';
import {myGlobals} from '../../constants/globals';
declare var sessionStorage : any;
declare var window : any;
@Component({
  selector: 'vtp',
  templateUrl: './landing.component.html',
  providers: [AccountService, AuthenticationService, EnabledisableactivitylogService, PagerService,MapResizeService],
  animations: [
    trigger('swipeUpDown', [
      state('in', style({ transform: 'translateY(0)' })),
      transition('void=> *', [
        style({ transform: 'translateX(-100%)' }),
        animate(300)
      ]),
      transition('* => void', [
        animate(0, style({ transform: 'translateX(100%)' }))
      ])
    ])
  ]
})
export class LandingComponent implements OnInit {

  @Output() notify: EventEmitter<number> = new EventEmitter<number>();
  notifyToTimeOutWarning: EventEmitter<any> = new EventEmitter();
  @ViewChild('panelMenu') panelMenu: ElementRef;
  isMenu: any;
  opts: any;
  information: any;
  isAccountCollapsed: any;
  showColapseIcon: any;
  previousState: any;
  routeName: any;
  navHeader: any;
  informationLoaded = false;
  timeoutWarningDialog: any;
  userMessageLogDialog :any;
  activityLogtimes = ["UTC", "Local"];
  currentActmsg = '';  
  msgs: Message[] = [];
  warningTimer: any;
  timeoutTimer: any;
  growlLife: Number = myGlobals.disAppearTimeMessage;
  enabledisableDialog: any;
  userActivityLogDialog: any;
  errormsgs: any;
  loading: any;
  dataLoad : any[];
  public activityLogData:any;
  public filterQuery = "";
  public rowsOnPage = myGlobals.pageSizes;
  public sortBy = "commandName";
  public sortOrder = "desc";
  maxDate: Date;
  // pager object
  pager: any = {};
  // paged items
  pagedItems: any[];
  pagination: any;
  totalRecords: any;
  timeDto = new TimeDto(this.activityLogtimes[0]);
  enabledisableDTO = new enabledisableservicesDTO('', '', null, '', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '', '', '', '');
  useractivelogDto = new useractivelogDTO('', '', '', null, null, '', '', '', '');
  constructor(translate: TranslateService, private route: ActivatedRoute, private router: Router, private elementRef: ElementRef, private accountService: AccountService,private authenticationService: AuthenticationService, private enabledisableactivityservice: EnabledisableactivitylogService, private pagerService: PagerService,private mapResize: MapResizeService) {
    this.authenticationService.canActivate();    
    this.maxDate = new Date();
    if (sessionStorage.getItem('accountInfo')) {
      this.information = JSON.parse(sessionStorage["accountInfo"]);
      this.informationLoaded = true;
    }
    else {
      this.information = { "accountNumber": "103011633", "tcuIds": "355414050002595", "make": "VW", "model": "Passat", "vin": "BVWL07AJ2FM263381", "year": "2012", "engine": "8 Cylinder", "transmission": "Automatic", "fuelType": "Regular Gas", "exteriorColor": "Red", "assetNumber": "004402000028567", "imei": "004402000028567", "imsi": "310410495648316", "msisdn": "5447159960", "deviceId": "355414050002595", "wirelessCarrier": "12343", "mdnDisplay": null, "userDTO": { "firstName": "FRANK", "lastName": "TESTER1", "city": "ATLANTA", "address1": "2001 SUMMIT BLVD", "address2": "STE500", "state": "GA", "zip": "30318", "email": "gjyothi@prokarma.com", "phoneNumber": "1234567891", "pin": "8989", "vin": null, "emergency_firstName": null, "emergency_lastName": null, "emergency_phone": null, "accountId": null, "accountCRMId": "10550563", "transaction": null, "customerId": null, "tcuId": null, "userTimeZoneString": null, "primaryNumber": "Mobile", "userId": "haritha.kulakarni@hughestelematics.com,jeff.nibler@verizon.com,pmanzi_itest1@vw.com,elena.register@verizon.com,cgaleas-itest1@volkswagen.com,Bhanoday.Saranam@hughestelematics.com,verizontest234@gmail.com,nathaniel.curtis@hughestelematics.com,test@volkswagen.com,hello@dustin-stone.com,rmukkavilli@abc.com,mohithuslocal@vw.com" }, "status": "Active", "deviceType": "OCU", "otarDate": null, "remoteStartCapable": null, "headUnitType": "NTG45 V2" }
      sessionStorage["accountInfo"] = JSON.stringify(this.information);
      sessionStorage["params"] = 'accountNumber=' + this.information['accountNumber'] + '&tcuId=' + this.information['tcuIds'] + '&vin=' + this.information['vin'] + '&userTimeZoneStr=est';
      this.informationLoaded = true;
    }

    // this language will be used as a fallback when a translation isn't found in the current language
    translate.setDefaultLang('en');
    // the lang to use, if the lang isn't available, it will use the current loader to get them
    translate.use('en');
    this.isMenu = true;
    this.isAccountCollapsed = false;
    this.showColapseIcon = true;
    this.previousState = false;

    this.routeName = {
      "landing": "My Car",
      "vehiclehealthreport": "Vehicle Health Report",
      "tripStatistics": "Trip Statistics",
      "emergencyCall": "Emergency Call",
      "informationCall": "Information Call",
      "assistanceCall": "Road Assistance Call",
      "poi": "POI / Address Import",
      "geofence": "Geofencing",
      "speedAlert": "Speed Alerts",
      "svt": "Stolen Vehicle Tracking",
      "vehicledisabling": "Vehicle Disabling",
      "doorlockunlock": "Door Lock & Door Unlock",
      "vehiclestatus": "Vehicle Status",
      "honkFlash": "Honking & Flashing",
      "batterycharging": "Battery Charging",
      "climatization": "Remote Climatization",
      "depaturetime": "Remote Departure Time"
    }
    this.router.events.subscribe(path => {
      if (path instanceof NavigationEnd) {
        if (path.url && path.url.indexOf('landing') != -1) {
          this.showColapseIcon = false;
          this.isAccountCollapsed = false;
        } else {
          this.isAccountCollapsed = this.previousState;
          this.showColapseIcon = true;
        }

        var key = path.url.replace('/', '');
        this.navHeader = this.routeName[key];
      }
    });
  }
  ngOnInit() {
    this.opts = {
      position: 'right',
      barBackground: '#000000',
    }
    this.StartTimers();
  }

  ngAfterViewInit() {
    
  }

  switchMenu() {
    var panelMenu = this.elementRef.nativeElement.querySelectorAll('.ui-panelmenu-panel');
    panelMenu.forEach(variable => {
      let activeElement = variable.querySelector('div.ui-state-active');
      if (activeElement) {
        variable.querySelector('a.ui-panelmenu-headerlink-hasicon').click()
      }
    });
    this.isMenu = !this.isMenu;
  }
  updateMenu(isMenu:any) {
    this.isMenu = isMenu;
  }
  expand() {
    this.isAccountCollapsed = !this.isAccountCollapsed;
    this.previousState = this.isAccountCollapsed;
    this.mapResize.sendCollapse(this.isAccountCollapsed);     
  }

  // Method to trigger or reset the timmer
  mousemoveEvents() {
    this.resetTimer();
  }

  // Method to Start timmer
  StartTimers() {
    this.warningTimer = setTimeout(() => this.idleWarning(), myGlobals.timoutWarningMilliseconds);
    this.timeoutTimer = setTimeout(() => this.logOut(), myGlobals.actualtimeoutMilliseconds);
  }

  // Method to Reset the timmer
  resetTimer() {
    clearTimeout(this.warningTimer);
    clearTimeout(this.timeoutTimer);
    this.StartTimers();
    this.timeoutWarningDialog = false;
  }

  // Method to give a idle warning
  idleWarning() {
    this.timeoutWarningDialog = true;
  }

  manageAccount(){
    this.router.navigate(['login']);
  }

  //Method to logOut the session
  logOut() {
    clearTimeout(this.warningTimer);
    clearTimeout(this.timeoutTimer);
    this.authenticationService.requestToLogout().subscribe(
      info => {
        if(info['responseDescription']){
          window.location.href = info['responseDescription'];
        }        
      },
      error => {
        this.msgs.push({ severity: 'error', summary: '', detail: error });
      });
  }

  //Methods to show hide the enable disale services
  enableDisableServices() {
    this.enabledisableDialog = true;
    this.getenableDisableServices();
  }

  // Methods to cancelEnableDisable
  cancelEnableDisable() {
    this.enabledisableDialog = false;
  }
  // Methods to get enable disale services

  getenableDisableServices() {
    this.loading = true;
    this.enabledisableactivityservice.getEnableDisable().subscribe(
      info => {
        this.loading = false;
        this.dataLoad[0] = info;
        this.enabledisableDTO = this.dataLoad[0];
      },
      error => {
        this.loading = false;
        this.msgs.push({ severity: 'error', summary: '', detail: error });
      }
    );
  }

  enableDisablePost() {
    this.loading = true;
    this.enabledisableDTO['accountNumber'] = this.information['accountNumber'];
    this.enabledisableDTO['tcuid'] = this.information['tcuId'];
    this.enabledisableDTO['vin'] = this.information['vin'];
    this.enabledisableactivityservice.enableDisablePost(this.enabledisableDTO).subscribe(
      info => {
        this.loading = false;
        if (info['responseStatus'] === "success") {
          this.msgs.push({ severity: 'success', summary: '', detail: info['responseDescription'] });
        } else {
          this.msgs.push({ severity: 'error', summary: '', detail: info['responseDescription'] });
        }
      },
      error => {
        this.loading = false;
        this.msgs.push({ severity: 'error', summary: '', detail: error });
      }
    );
  }

  // Methods to show and hide the active log  
  activityLog() {
    this.userActivityLogDialog = true;
    this.errormsgs = '';
    //this.userActivityLogSearch(0,myGlobals.pageSizes);
    this.setPage(1);
  }

  // Methods to cancel the user active log
  cancelUserActivity() {
    this.userActivityLogDialog = false;
  }

  userActivityLogSearch(startIndex:any, pageSizes:any) {
    this.enabledisableactivityservice.getlogs(this.useractivelogDto, startIndex, pageSizes).subscribe(
      info => {
        this.activityLogData = info['logList'];
        if (this.activityLogData !== null && this.activityLogData !== "" && this.activityLogData !== "undefined") {
          this.activityLogData = info['logList'];
          this.totalRecords = info['resultSize'];
          this.pager.totalPages = this.totalRecords;
          if (info['resultSize'] > 0 && info['resultSize'] > myGlobals.pageSizes) {
            this.pagination = true;
          }

        } else {
          this.errormsgs = myGlobals.noData;
        }
      },
      error => {
        this.errormsgs = error;
      }
    );
  }

  userActivityLogSearchDay() {
    this.loading = true;
    let creatTimes = this.useractivelogDto.createTime.toString();
    let resStart = creatTimes.split(":");
    let startHour = resStart[0];
    let startMin = resStart[1];
    let startSec = resStart[2];

    let endTimes = this.useractivelogDto.endTime.toString();
    let res = endTimes.split(":");
    let endHour = res[0];
    let endMin = res[1];
    let endSec = res[2];

    let params = "&dateTimeUOM&=UTC&startDate=" + this.useractivelogDto.commandFrom + "&stopDate=" + this.useractivelogDto.commandTo + "&startHour=" + startHour + "&startMin=" + startMin + "&startSec=" + startSec + "&endHour=" + endHour + "&endMin=" + endMin + "&endSec=" + endSec;
    this.enabledisableactivityservice.getlogsdays(params).subscribe(
      info => {
        this.loading = false;
        this.activityLogData = info['logList'];
        if (this.activityLogData !== null && this.activityLogData !== "" && this.activityLogData !== "undefined") {
          this.activityLogData = info['logList'];
        } else {
          this.errormsgs = myGlobals.noData;
        }
      },
      error => {
        this.loading = false;
        this.msgs.push({ severity: 'error', summary: '', detail: error });
      }
    );
  }

  viewActivityLogMsg(mes:any){
    this.userMessageLogDialog = true;
    this.currentActmsg = mes;     
  }


  setPage(page: number) {
    this.errormsgs = '';
    this.activityLogData = '';
    this.pagedItems = [];
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }

    if (this.totalRecords !== null && this.totalRecords !== "undefined") {
      // get pager object from service
      
      this.pager = this.pagerService.getPager(this.totalRecords, page);
            
      // get current page of items
      //this.userActivityLogSearch(this.pager.startIndex, this.pager.endIndex + 1);
      this.userActivityLogSearch(page - 1, myGlobals.pageSizes);
    }
  }
}
