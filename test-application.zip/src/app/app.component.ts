import { Component, OnInit, EventEmitter, Output, style, state, animate, transition, trigger, ElementRef, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
@Component({
 selector: 'app',
  template: `<router-outlet></router-outlet>`,
  animations: [
    trigger('swipeUpDown', [
      state('in', style({ transform: 'translateY(0)' })),
      transition('void=> *', [
        style({ transform: 'translateY(-100%)' }),
        animate(300)
      ]),
      transition('* => void', [
        animate(0, style({ transform: 'translateX(100%)' }))
      ])
    ])
  ]
})
export class AppComponent {
  title = 'Vehicle Testing Portal';
}
