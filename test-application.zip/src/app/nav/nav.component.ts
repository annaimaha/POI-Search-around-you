import { Component, OnInit, Input, style, state, animate, transition, trigger,EventEmitter,Output } from '@angular/core';
import {myGlobals} from '../../constants/globals';
@Component({
  selector: 'navbar',
  templateUrl: './nav.component.html',
  animations: [
        trigger('flyInOut', [
            state('in', style({ transform: 'translateX(0)' })),
            transition('void => *', [
                style({ transform: 'translateX(-100%)' }),//
                animate(500)
            ]),
            transition('* => void', [
                animate(500, style({ transform: 'translateX(100%)' }))
            ])
        ])
    ]
})
export class NavComponent {

 @Input() isMenu;
    @Output() menuUpdate = new EventEmitter();
    menus: any;
    constructor() {
        this.menus = [
            {"label":"My Car","href":"myCar","icon":"fa-car","items":[
            {"label":"Vehicle Information","routerLink":[myGlobals.routerlanding],"href":"myCar","icon":"fa fa-file-text-o"},
            {"label":"Vehicle Health Report","href":"vehicleHealthReport","icon":"fa-heartbeat","routerLink":[myGlobals.routervehiclehealthreport]},
            {"label":"Trip Statistics","href":"tripStatistics","icon":"fa-suitcase","routerLink":[myGlobals.routerTripStatistics]}]},
            {"label":"Calls","href":"Calls","icon":"fa fa-phone","items":
            [{"label":"Emergency","href":"emergency","icon":"fa fa-plus-square","routerLink":[myGlobals.routerEmergencyCall]},
            {"label":"Information","href":"information","icon":"fa fa-info-circle","routerLink":[myGlobals.routerInformationCall]},
            {"label":"Assistance","href":"assitance","icon":"fa fa-question-circle","routerLink":[myGlobals.routerAssistanceCall]}
            ]},
            {"label":"Location Services","href":"myCar","icon":"fa fa-map-marker","items":[
              {"label":"POI | Address Import","routerLink":[myGlobals.routerPoi],"href":"poiImport","icon":"fa fa-map-pin"},
              {"label":"Geofencing","href":"geofence","routerLink":[myGlobals.routerGeofence],"icon":"fa fa-street-view"},
              {"label":"Speed Alerts","href":"speedAlert","icon":"fa fa-bell","routerLink": [myGlobals.routerSpeedAlert]},
              {"label":"Stolen Vehicle Tracking","href":"stolenVehicleTracking","icon":"fa fa-crosshairs","routerLink": [myGlobals.routerSvt]},
              {"label":"Vehicle Disabling","href":"vehicleDisabling","icon":"fa fa-exclamation-triangle","routerLink": [myGlobals.routerVehicledisabling]}
            ]},
            {"label":"Remote Access","href":"remoteAccess","icon":"fa fa-lock","items":[
              {"label":"Vehicle Status","href":"vehicleStatus","icon":"fa fa-gear","routerLink":[myGlobals.routerVehiclestatus]},
              {"label":"Door Lock & Door Unlock","routerLink":[myGlobals.routerDoorlockunlock],"href":"rdlu","icon":"fa fa-lock,fa fa-unlock"},
              {"label":"Honking & Flashing","href":"honkFlash","icon":"fa fa-bullhorn","routerLink":[myGlobals.routerHonkFlash]}
            ]},{"label":"Electric Vehicles","href":"electricVehicles","icon":"fa fa-plug","items":[
              {"label":"Battery Charging","href":"batteryCharging","icon":"fa fa-battery-half","routerLink":[myGlobals.routerBatterycharging]},
              {"label":"Remote Climatization","href":"remoteClimatization","icon":"fa fa-cloud","routerLink":[myGlobals.routerClimatization]},
              {"label":"Remote Departure Time","href":"remoteDepartureTime","icon":"fa fa-plane","routerLink":[myGlobals.routerDepaturetime]}
            ]}];
    }
    panelClicked($event) {
        if(!this.isMenu){
            this.isMenu = true;
            this.menuUpdate.emit(this.isMenu);
        }
    }

}
