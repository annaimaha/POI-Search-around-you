import {Component, OnDestroy, Input,style, state, animate, transition, trigger } from '@angular/core';
import {SelectItem} from 'primeng/primeng';
@Component({
  selector: 'notification',
  templateUrl: './notification.component.html',
  styles: ['.notification-icon{position: absolute;top: 0em;padding: 0.5em;border: 1px solid #2cc185;background: #2cc185;color: #fff;border-radius: 3px;} .preferences{width:90%;margin-left:2em;}'],
  animations: [
    trigger('flyInOut', [
      state('in', style({ transform: 'translateX(0)' })),
      transition('void => *', [
        style({ transform: 'translateX(-100%)' }),//
        animate(100)
      ]),
      transition('* => void', [
        animate(50, style({ transform: 'translateX(-100%)' }))
      ])
    ])
  ]
})
export class NotificationComponent {

  @Input() notification: any;
  constructor() {

  }

}
