// import { PhonenumberDirective } from './phonenumber.directive';

// describe('PhonenumberDirective', () => {
//   it('should create an instance', () => {
//     const directive = new PhonenumberDirective();
//     expect(directive).toBeTruthy();
//   });
// });
