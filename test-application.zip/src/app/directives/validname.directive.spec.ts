// import { ValidnameDirective } from './validname.directive';

// describe('ValidnameDirective', () => {
//   it('should create an instance', () => {
//     const directive = new ValidnameDirective();
//     expect(directive).toBeTruthy();
//   });
// });
