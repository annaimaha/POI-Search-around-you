// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { DepatureTimerComponent } from './depature-timer.component';

// describe('DepatureTimerComponent', () => {
//   let component: DepatureTimerComponent;
//   let fixture: ComponentFixture<DepatureTimerComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ DepatureTimerComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(DepatureTimerComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
