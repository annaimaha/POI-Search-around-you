import { Component,Input} from '@angular/core';

@Component({
  selector: 'timer',
  templateUrl: './depature-timer.component.html'
})
export class DepatureTimerComponent  {

  
  public filterQuery = "";
  public rowsOnPage = 10;
  public sortBy = "alertname";
  public sortOrder = "asc";
  @Input() data;
  @Input() timmerErrorMsgs;

  constructor() {
    
  }

}
