import { Component, OnInit } from '@angular/core';
import { SelectItem,Message, DialogModule} from 'primeng/primeng';
import { Remotedempprofile } from '../../../../model/RemotedempprofileDTO';
import { RemoteDepatureService } from '../remote-depature.service';
import { HelperService } from "../../../../services/helper.service";
import { myGlobals } from '../../../../constants/globals';
declare var sessionStorage: any;
@Component({
  selector: 'remotedepaturetime',
  templateUrl: './remote-depature-time.component.html',
  providers: [RemoteDepatureService, HelperService]
})
export class RemoteDepatureTimeComponent implements OnInit {

  information: any;
    tabName: any;
    timerequired: any;
    timevalidationmsg: any;
    public profileData:any;
    public filterQuery = "";
    chargeMinLimit:any;
    selectAll:any;
    public rowsOnPage = 5;
    public sortBy = "alertname";
    public sortOrder = "asc";
    addprofileDialog: any;
    addProfileOption: any;
    timmerErrorMsgs: any;
    loading: any;
    errormsgs: any;
    msgs: Message[] = [];
    growlLife: Number = myGlobals.disAppearTimeMessage;
    charging: SelectItem[];
    targetChargeLevels: any;
    chargeMaxCurrents: any;
    addOrUpdateProfile = "Add Profile";
    multiDelete = {
        checked: false
    };
    ids = {};

    timeArray = ["12:00AM", "12:30AM", "01:00AM",
        "01:30AM", "02:00AM", "02:30AM", "03:00AM", "03:30AM",
        "04:00AM", "04:30AM", "05:00AM", "05:30AM", "06:00AM",
        "06:30AM", "07:00AM", "07:30AM", "08:00AM", "08:30AM",
        "09:00AM", "09:30AM", "10:00AM", "10:30AM", "11:00AM",
        "11:30AM", "12:00PM", "12:30PM", "01:00PM", "01:30PM",
        "02:00PM", "02:30PM", "03:00PM", "03:30PM", "04:00PM",
        "04:30PM", "05:00PM", "05:30PM", "06:00PM", "06:30PM",
        "07:00PM", "07:30PM", "08:00PM", "08:30PM", "09:00PM",
        "09:30PM", "10:00PM", "10:30PM", "11:00PM", "11:30PM"];
        
    remotedempprofile = new Remotedempprofile('', '', false, false, false, '', '', false, this.timeArray[0], this.timeArray[0], null, null, this.timeArray[0], this.timeArray[0]);
    batterycharging: string;

    timerValues: any;
    constructor(private remoteDepatureService: RemoteDepatureService, public helper: HelperService) {
        this.tabName = "settings";        
        this.charging = [];        
        this.charging.push({ label: '10 %', value: '10' });
        this.charging.push({ label: '20 %', value: '20' });
        this.charging.push({ label: '30 %', value: '30' });
        this.charging.push({ label: '40 %', value: '40' });
        this.charging.push({ label: '50 %', value: '50' });
        this.charging.push({ label: '60 %', value: '60' });
        this.charging.push({ label: '70 %', value: '70' });
        this.charging.push({ label: '80 %', value: '80' });
        this.charging.push({ label: '90 %', value: '90' });
        this.charging.push({ label: '100 %', value: '100' });

        this.targetChargeLevels = [];
        this.targetChargeLevels.push({ label: '10 %', value: '10' });
        this.targetChargeLevels.push({ label: '20 %', value: '20' });
        this.targetChargeLevels.push({ label: '50 %', value: '50' });
        this.targetChargeLevels.push({ label: '80 %', value: '80' });
        this.targetChargeLevels.push({ label: '100 %', value: '100' });

        this.chargeMaxCurrents = [];

        this.chargeMaxCurrents.push({ label: '10 AMPS', value: '10' });
        this.chargeMaxCurrents.push({ label: '16 AMPS', value: '16' });
        this.chargeMaxCurrents.push({ label: '32 AMPS', value: '32' });
        this.chargeMaxCurrents.push({ label: '56 AMPS', value: '56' });
    }

    ngOnInit(): void {
        this.departureTime();
    }
    commonTabs(Tabs:any) {
        this.tabName = "";
        this.tabName = Tabs;
    }

    nightRate(e:any) {
        this.remotedempprofile.nightRate;
    }

    setbatteryCharge(e:any) {
        this.remotedempprofile.batteryCharging;
    }
    departureTime() {
        this.remoteDepatureService.departuretimer().subscribe(
            info => {
                this.timerValues = info['dTimerList'];
                this.profileData = info['dProfileList'];
            },
            error => {
                this.errormsgs = error;
                this.timmerErrorMsgs = error;
            }
        );
    }

    addProfilesDisplay(param:any) {
        if (param !== 'edit') {       
            this.addOrUpdateProfile = 'Add Profile';     
            this.remotedempprofile = new Remotedempprofile('', '', false, false, false, '', '', false, this.timeArray[0], this.timeArray[0], null, null, this.timeArray[0], this.timeArray[0]);
        }
        
        this.addProfileOption = true;
        this.addprofileDialog = true;
    }
    cancelAddProfile() {
        this.addprofileDialog = false;
        this.remotedempprofile = new Remotedempprofile('', '', false, false, false, '', '', false, this.timeArray[0], this.timeArray[0], null, null, this.timeArray[0], this.timeArray[0]);
        this.addProfileOption = false;
    }

    addProfile() {

        this.timerequired = false;
        this.timevalidationmsg = "";
        if (this.remotedempprofile.nightRate) {

            let sT = this.helper.convertTimeFrom12To24(this.remotedempprofile.startTime);
            let sE = this.helper.convertTimeFrom12To24(this.remotedempprofile.endTime);
            
            if ((sT !== null && sT !== "undefind") && (sE !== null && sE !== "undefind")) {

                if (sT === sE) {
                    this.timerequired = true;
                    this.timevalidationmsg = "Start time and End time should not be same";
                    return false;
                }
            } else {
                this.timerequired = true;
                this.timevalidationmsg = "Start time and End time are required";
                return false;
            }
        }

        this.loading = true;
        this.remoteDepatureService.addProfile(this.remotedempprofile).subscribe(
            info => {
                this.cancelAddProfile();
                this.manageResponse(info);
            },
            error => {
                this.errors(error);
            }
        );
    }

    /**
     * Methods to save min battery Level
     */
    saveminBatteryLevel(minBattery:any) {
        this.loading = true;
        let minBatteryLevel = "&minBatteryLevel=" + minBattery['minBatteryLevel'];

        this.remoteDepatureService.saveMinBatteryLevel(minBatteryLevel).subscribe(
            info => {
                this.manageResponse(info);
            },
            error => {
                this.errors(error);
            }
        );
    }


    /*
    Methods to get the datas of the selected record for edit
    @param items object : selected record data
    */

    editProfile(items:any) {
        this.loading = true;
        this.remoteDepatureService.editProfile(items.profileId).subscribe(
            info => {
                this.loading = false;
                this.remotedempprofile = info;
                this.addOrUpdateProfile = 'Update Profile';
                this.addProfilesDisplay("edit");
            },
            error => {
                this.errors(error);
            }
        );
    }

    updateProfile() {

        this.loading = true;
        this.remoteDepatureService.updateRemoteDepartureProfile(this.remotedempprofile).subscribe(
            info => {
                this.cancelAddProfile();
                this.manageResponse(info);
            },
            error => {
                this.errors(error);
            }
        );
    }


    // Methods to validate the timmer
    timmerValidation() {
        // Shouldbe Timeformat MM/dd/yyyy hh:mm a
    }

    // Methods to deselect all list of profiles

    selectAllDeselect(result:any) {
        this.multiDelete.checked = result;
    }

    /**
     * Methods  to removeAll
     */
    removeAll(items:any) {
        let profileId = '';
        for (let k in items) {
            if (items[k] && k !== "selectAll") {
                profileId += k + ",";
            }
        }
        profileId = profileId.replace(/,\s*$/, "");        
        this.remove(profileId);
    }

    /*
    Methods to delete the profile records
    @param value object : specific records details
    */
    remove(profileids: any) {
        this.loading = true;
        this.remoteDepatureService.deleteDepartureProfile(profileids).subscribe(
            info => {
                this.manageResponse(info);
            }, error => {
                this.errors(error);
            }
        );
    }


    /*
     Methods to Manage success response
     @param info object response  details
    */

    manageResponse(info:any) {
        if (info['responseStatus'] == 'success') {
            this.departureTime();
            this.loading = false;
            this.msgs.push({ severity: 'success', summary: '', detail: info['responseStatus'] });
        } else {
            this.msgs.push({ severity: 'error', summary: '', detail: info['responseDescription'] });
            this.loading = false;
        }
    }

    /*
     Methods to Manage error Response
     @param info object response  details
    */
    errors(error:any) {
        this.msgs.push({ severity: 'error', summary: '', detail: error });
        this.loading = false;
    }

}
