// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { RemoteDepatureTimeComponent } from './remote-depature-time.component';

// describe('RemoteDepatureTimeComponent', () => {
//   let component: RemoteDepatureTimeComponent;
//   let fixture: ComponentFixture<RemoteDepatureTimeComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ RemoteDepatureTimeComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(RemoteDepatureTimeComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
