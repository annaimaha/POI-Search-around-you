// import { TestBed, inject } from '@angular/core/testing';

// import { RemoteDepatureService } from './remote-depature.service';

// describe('RemoteDepatureService', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       providers: [RemoteDepatureService]
//     });
//   });

//   it('should ...', inject([RemoteDepatureService], (service: RemoteDepatureService) => {
//     expect(service).toBeTruthy();
//   }));
// });
