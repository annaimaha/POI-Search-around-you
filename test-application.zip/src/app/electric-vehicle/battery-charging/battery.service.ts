import { Injectable } from '@angular/core';
import { Observable }     from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { Http, Response,Headers,RequestOptions } from '@angular/http';
import {myGlobals} from '../../../constants/globals';
declare var sessionStorage : any;

@Injectable()
export class BatteryService {

  private headers:any;
  options:any;
  constructor(private http:Http){
    this.headers = new Headers();
    this.headers.append('Content-Type', 'application/json');
    this.headers.append('api-key', 'vzt-vtp-locationsvc');
    this.options = {headers :this.headers,withCredentials: true};
  }

   chargeSettings(postData: any): Observable<any> {
     let accInfo = JSON.parse(sessionStorage["accountInfo"]);
        return this.http.get(myGlobals.chargeSettings+sessionStorage["params"]+"&emailId="+accInfo['emailId']+"&phoneNumber="+accInfo['phoneNumber'], this.options)
            .map(this.extractData)
            .catch(this.handleError);
  }

  chargeSettingsDetail(): Observable<any>{
    let accInfo = JSON.parse(sessionStorage["accountInfo"]);

    return this.http.get(myGlobals.chargeSettingsDetail+sessionStorage["params"]+"&emailId="+accInfo['emailId']+"&phoneNumber="+accInfo['phoneNumber'],this.options)
           .map(this.extractData)
           .catch(this.handleError);
  }

  saveChargeSettings(postData: any): Observable<any> {
    let accInfo = JSON.parse(sessionStorage["accountInfo"]);      
       return this.http.post(myGlobals.saveChargeSettings+sessionStorage["params"]+"&emailId="+accInfo['emailId']+"&phoneNumber="+accInfo['phoneNumber'],postData,this.options)
           .map(this.extractData)
           .catch(this.handleError);
  }

  getBatteryState(postData: any): Observable<any> {
        let accInfo = JSON.parse(sessionStorage["accountInfo"]);
      postData['maxCurrent'] = 50;
       return this.http.get(myGlobals.getBatteryState+sessionStorage["params"]+"&emailId="+accInfo['emailId']+"&phoneNumber="+accInfo['phoneNumber']+"&maxCurrent="+50+"&requestType=rbcStatus",this.options)
           .map(this.extractData)
           .catch(this.handleError);
  }

    unlockChargingPlug(): Observable<any> {
            let accInfo = JSON.parse(sessionStorage["accountInfo"]);
        
        return this.http.get(myGlobals.unlockChargingPlug+sessionStorage["params"]+"&emailId="+accInfo['emailId']+"&phoneNumber="+accInfo['phoneNumber']+"&maxCurrent="+50+"&requestType=rbcUnlockPlug", this.options)
            .map(this.extractData)
            .catch(this.handleError);
    }
  
  startBatteryCharging(): Observable<any> {
        let accInfo = JSON.parse(sessionStorage["accountInfo"]);
       return this.http.get(myGlobals.startStopBatteryCharge+sessionStorage["params"]+"&emailId="+accInfo['emailId']+"&phoneNumber="+accInfo['phoneNumber']+"&maxCurrent="+50+"&requestType=rbcStart", this.options)
           .map(this.extractData)
           .catch(this.handleError);
  }

  stopBatteryCharging(): Observable<any> {
        let accInfo = JSON.parse(sessionStorage["accountInfo"]);
       return this.http.get(myGlobals.startStopBatteryCharge+sessionStorage["params"]+"&emailId="+accInfo['emailId']+"&phoneNumber="+accInfo['phoneNumber']+"&maxCurrent="+50+"&requestType=rbcStop", this.options)
           .map(this.extractData)
           .catch(this.handleError);
  }

  private extractData(res: Response) {
      let body = res.json();
      return body.data?body.data: (body || {});
  }
  private handleError(error: Response | any) {
      // In a real world app, we might use a remote logging infrastructure
      let errMsg: string;
      if (error instanceof Response) {
          const body = error.json() || '';
          const err = body.error || JSON.stringify(body);
          errMsg = `${error.status} - ${error.statusText || ''} `;
      } else {
          errMsg = error.message ? error.message : error.toString();
      }
      
      errMsg = (error.status == '0') ? myGlobals.badGateWay : errMsg;

      return Observable.throw(errMsg);
  }

}
