import { Component, OnInit } from '@angular/core';
import { Message } from 'primeng/primeng';
import { BatteryService } from '../battery.service';
import { BatterySettingsDTO } from '../../../../model/BatterySettingsDTO.model';
import { myGlobals } from '../../../../constants/globals';
@Component({
  selector: 'batterystartstopcharging',
  templateUrl: './battery-startstopcharging.component.html',
  providers: [BatteryService]
})
export class BatteryStartstopchargingComponent  {

 information: any;
  isAccountCollapsed: any;
  tabName: any;
  msgs: Message[] = [];
  loading: any;
  growlLife: Number = myGlobals.disAppearTimeMessage;
  batterySetting = new BatterySettingsDTO(null, '', false, false, false, '', '', false, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
  constructor(private batteryChargingService: BatteryService) {
    this.tabName = "Alert";
    this.isAccountCollapsed = false;

  }

  ngOnInit(): void {
    this.chargeSettingsDetail();
  }

  commonTabs(tabs) {
    this.tabName = "";
    this.tabName = tabs;
  }

  expand() {
    this.isAccountCollapsed = !this.isAccountCollapsed;
  }

  collapsed(isCollapsed) {
    this.isAccountCollapsed = isCollapsed;
  }

  // Methods to get the bettary state
  getBatteryState() {
    this.loading = true;
    let postData = {
      "maxCurrent": 50,
      "requsttype": 'rbcSettings'
    }
    this.batteryChargingService.getBatteryState(postData).subscribe(
      info => {
        this.loading = false;
        this.batterySetting = info;
      },
      error => {
        this.loading = false;
        this.msgs.push({ severity: 'error', summary: '', detail: myGlobals.noData });
      }
    );
  }

  
  chargeSettingsDetail() {
    this.loading = true;
    this.batteryChargingService.chargeSettingsDetail().subscribe(
      info => {
       this.loading = false;
        this.batterySetting = info;
      },
      error => {
        this.loading = false;
        this.msgs.push({ severity: 'error', summary: '', detail: error });
      }
    );
  }

  //Methods to unlock charging
  unlockChargingPlug() {

    this.loading = true;

    this.batteryChargingService.unlockChargingPlug().subscribe(
      info => {
        this.loading = false;
        if (info['responseStatus'] === "success") {
          this.msgs.push({ severity: 'success', summary: '', detail: info['responseDescription'] });
        } else {
          this.msgs.push({ severity: 'error', summary: '', detail: info["responseDescription"] });
        }
      },
      error => {
        this.loading = false;
        this.msgs.push({ severity: 'error', summary: '', detail: error });
      }
    );
  }

  //Methods to startBatteryCharging
  startBatteryCharging() {
    this.loading = true;

    this.batteryChargingService.startBatteryCharging().subscribe(
      info => {
        this.loading = false;
        if (info['responseStatus'] === "success") {
          this.msgs.push({ severity: 'success', summary: '', detail: info['responseDescription'] });
        } else {
          this.msgs.push({ severity: 'error', summary: '', detail: info["responseDescription"] });
        }
      },
      error => {
        this.loading = false;
        this.msgs.push({ severity: 'error', summary: '', detail: myGlobals.noData });
      }
    );
  }
  stopBatteryCharging() {
    this.loading = true;
    this.batteryChargingService.stopBatteryCharging().subscribe(
      info => {
        this.loading = false;
        if (info['responseStatus'] == "success") {
          this.msgs.push({ severity: 'success', summary: '', detail: info['responseDescription'] });
        } else {
          this.msgs.push({ severity: 'error', summary: '', detail: info["responseDescription"] });
        }
      },
      error => {
        this.loading = false;
        this.msgs.push({ severity: 'error', summary: '', detail: myGlobals.noData });
      }
    );
  }


}
