// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { BatteryStartstopchargingComponent } from './battery-startstopcharging.component';

// describe('BatteryStartstopchargingComponent', () => {
//   let component: BatteryStartstopchargingComponent;
//   let fixture: ComponentFixture<BatteryStartstopchargingComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ BatteryStartstopchargingComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(BatteryStartstopchargingComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
