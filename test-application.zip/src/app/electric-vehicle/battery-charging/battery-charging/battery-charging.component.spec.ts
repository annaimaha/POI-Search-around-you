// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { BatteryChargingComponent } from './battery-charging.component';

// describe('BatteryChargingComponent', () => {
//   let component: BatteryChargingComponent;
//   let fixture: ComponentFixture<BatteryChargingComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ BatteryChargingComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(BatteryChargingComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
