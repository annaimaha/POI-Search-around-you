import { Component } from '@angular/core';

@Component({
  selector: 'batterycharging',
  templateUrl: './battery-charging.component.html'
})
export class BatteryChargingComponent {

 information: any;
  tabName: any;
  constructor() {
    this.tabName = "settings";
  }

  commonTabs(Tabs) {
    this.tabName = "";
    this.tabName = Tabs;
  }

}
