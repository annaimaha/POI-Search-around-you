import { Component, OnInit } from '@angular/core';
import { Message,SelectItem } from 'primeng/primeng';
import { BatterySettingsDTO } from '../../../../model/BatterySettingsDTO.model';
import { BatteryService } from '../battery.service';
import { myGlobals } from '../../../../constants/globals';
@Component({
  selector: 'batterysettings',
  templateUrl: './battery-settings.component.html',
  providers: [BatteryService]
})
export class BatterySettingsComponent implements OnInit {

  information: any;
  tabName: any;
  msgs: Message[] = [];
  errormsgs: any;
  growlLife: Number = myGlobals.disAppearTimeMessage;
  data: any;
  chargemaxcurrents = [
    { label: '5', value: '5' },
    { label: '10', value: '10' },
    { label: '16', value: '16' },
    { label: '32', value: '32' },
    { label: '50', value: '50' }
  ];
  loading: any;
  batterySettings = new BatterySettingsDTO("5", '', false, false, false, '', '', false, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
  constructor(private batteryChargingService: BatteryService) {
    this.tabName = "Alert";
  }

  commonTabs(tabs) {
    this.tabName = "";
    this.tabName = tabs;
  }

  ngOnInit() {
    //this.chargeSettingsDetail();
    this.chargeSettings('');
  }

  chargeSettings(params:any) {   
    
    if(params == "refresh"){
      this.loading = true;  
    }

    this.batteryChargingService.chargeSettings(this.batterySettings).subscribe(
      info => {        
        this.loading = false;
        this.data = info;                 
      },
      error => {        
        this.loading = false;        
      }
    );
  }



  saveBatteryCharging() {
    this.loading = true;    
     if (sessionStorage["accountInfo"]) {
      this.information = JSON.parse(sessionStorage["accountInfo"]);
      this.batterySettings['email'] = this.information.userDTO.email;
    }        
    
    this.batteryChargingService.saveChargeSettings(this.batterySettings).subscribe(
      info => {
        this.manageInfo(info);
        this.data = info;        
      },
      error => {
        this.loading = false;
        this.msgs.push({ severity: 'error', summary: '', detail: error });
      }
    );
  }

  manageInfo(info) {
    this.loading = false;
    this.msgs.push({ severity: 'success', summary: '', detail: myGlobals.saveBatteryChargingmsg });
  }

}
