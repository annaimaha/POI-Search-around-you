// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { RemoteClimatizationStartstopComponent } from './remote-climatization-startstop.component';

// describe('RemoteClimatizationStartstopComponent', () => {
//   let component: RemoteClimatizationStartstopComponent;
//   let fixture: ComponentFixture<RemoteClimatizationStartstopComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ RemoteClimatizationStartstopComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(RemoteClimatizationStartstopComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
