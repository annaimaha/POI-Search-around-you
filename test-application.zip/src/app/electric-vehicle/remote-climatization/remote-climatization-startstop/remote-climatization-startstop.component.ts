import { Component, OnInit } from '@angular/core';
import {Message} from 'primeng/primeng';
import {ClimatizationsettingsDTO} from '../../../../model/ClimatizationsettingsDTO';
import {RemoteClimatizationService} from '../remote-climatization.service';
import {myGlobals} from '../../../../constants/globals';

@Component({
  selector: 'remoteclimatizationstartstop',
  templateUrl: './remote-climatization-startstop.component.html',
  providers:[RemoteClimatizationService],
})
export class RemoteClimatizationStartstopComponent implements OnInit {

   information: any;
  isAccountCollapsed: any;
  tabName: any;
  loading:any;
  msgs: Message[] = [];
  growlLife:Number = myGlobals.disAppearTimeMessage;
  saveClimatization = new ClimatizationsettingsDTO(null,null,null,'','',null,null,null,null,null,null,null,null,null,null,null,null,null,false,'',null,false,false,false,false,null,null,null);
  constructor(private climatizationService:RemoteClimatizationService) {
    this.tabName = "Alert";
    this.isAccountCollapsed = false;
  }
  // Init the page
  ngOnInit(){
      this.getstartStopClimatization();
  }

  // Methods for tabs
  commonTabs(tabs){
	  this.tabName	= "";
	  this.tabName	= tabs;
  }

  // Methods to expand the vehicleinformations
  expand() {
    this.isAccountCollapsed = !this.isAccountCollapsed;
  }
  // Methods to collapsed the vehicleinformations
  collapsed(isCollapsed){
   this.isAccountCollapsed = isCollapsed;
  }

  // Methods to get the climatization
  getstartStopClimatization(){
    this.loading = true;
    this.climatizationService.remoteClimateActivate().subscribe(
      info=>{
        this.manageResponse(info);
      },
      error=>{
        this.errors(error);
      }
    );
  }

  /* Methods to stop or start the windowheating

    @params windowheating string value start or stop
  */
  startStopClimateActivate(climateid){
    this.loading = true;
    this.climatizationService.startStopClimateActivate(this.saveClimatization,climateid).subscribe(
      info=>{
        this.manageResponse(info);
      },
      error=>{
        this.errors(error);
      }
    );
  }


  /* Methods to stop or start the windowheating

    @params windowheating string value start or stop
  */
  startStopClimatewindowheating(windowheating){
    this.loading = true;
    this.climatizationService.startStopClimatewindowheating(this.saveClimatization,windowheating).subscribe(
      info=>{
        this.manageResponse(info);
      },
      error=>{
        this.errors(error);
      }
    );
  }
  //manageResponse
  manageResponse(info){
    this.loading = false;
    if(info['responseStatus'] ==='success'){
      this.msgs.push({ severity: 'success', summary: '', detail: info['responseDescription'] });
    }else if(info['responseStatus'] ==='failure'){
      this.msgs.push({ severity: 'error', summary: '', detail: info['responseDescription'] });
    }else{
        this.msgs.push({ severity: 'error', summary: '', detail: myGlobals.noData });
    }
  }

  // manage errormsgs
  errors(error){
    this.loading = false;
    this.msgs.push({ severity: 'error', summary: '', detail: myGlobals.noData });
  }


}
