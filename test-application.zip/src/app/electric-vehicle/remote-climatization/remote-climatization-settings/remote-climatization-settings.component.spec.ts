// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { RemoteClimatizationSettingsComponent } from './remote-climatization-settings.component';

// describe('RemoteClimatizationSettingsComponent', () => {
//   let component: RemoteClimatizationSettingsComponent;
//   let fixture: ComponentFixture<RemoteClimatizationSettingsComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ RemoteClimatizationSettingsComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(RemoteClimatizationSettingsComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
