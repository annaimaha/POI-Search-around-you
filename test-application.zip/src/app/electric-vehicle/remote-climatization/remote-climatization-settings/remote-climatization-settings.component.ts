import {Component,Input, style, state, animate, transition, trigger } from '@angular/core';
import {SliderModule,Message} from 'primeng/primeng';
import {ClimatizationsettingsDTO} from '../../../../model/ClimatizationsettingsDTO';
import {RemoteClimatizationService} from '../remote-climatization.service';
import { myGlobals } from '../../../../constants/globals';

@Component({
  selector: 'remoteclimatizationsettings',
  templateUrl: './remote-climatization-settings.component.html',
  providers:[RemoteClimatizationService],
  animations: [
    trigger('flyInOut', [
      state('in', style({ transform: 'translateX(0)' })),
      transition('void => *', [
        style({ transform: 'translateX(-100%)' }),//
        animate(200)
      ]),
      transition('* => void', [
        animate(50, style({ transform: 'translateX(100%)' }))
      ])
    ]),
    trigger('swipeUpDown', [
      state('in', style({ transform: 'translateY(0)' })),
      transition('void=> *', [
        style({ transform: 'translateY(-100%)' }),
        animate(300)
      ]),
      transition('* => void', [
        animate(0, style({ transform: 'translateX(100%)' }))
      ])
    ])
  ]
})
export class RemoteClimatizationSettingsComponent  {

  information: any;
	isAccountCollapsed: any;
	tabName: any;
	data:any;
	errormsgs:any;
	loading:any;
	msgs : Message[] = [];
	growlLife:Number = myGlobals.disAppearTimeMessage;
	saveClimatization = new ClimatizationsettingsDTO(null,null,null,'','','17',null,null,null,null,null,null,null,null,null,null,null,false,false,'',null,false,false,false,false,null,null,null);

  constructor(private climatizationService:RemoteClimatizationService) {
    this.tabName = "Alert";
    this.isAccountCollapsed = false;
  }
  ngOnInit(){
    this.getRemoteClimatization('');
  }
  commonTabs(tabs){
	  this.tabName	= "";
	  this.tabName	= tabs;
  }
  expand() {
    this.isAccountCollapsed = !this.isAccountCollapsed;
  }
  collapsed(isCollapsed){
   this.isAccountCollapsed = isCollapsed;
  }

  getRemoteClimatization(params:any){
    if(params == "refresh"){
      this.loading = true;  
    }
    this.climatizationService.remoteClimateSettings().subscribe(
      info=>{
        this.data = info;
        this.loading = false;
        if(this.data["winHeat"] !== "Both"){
          this.data['winHeatStateFront'] = (this.data["winHeat"] === "Front") ? "On" : "Off" ;
          this.data['winHeatStateRear'] = (this.data["winHeat"] === "Rear") ?    "On" : "Off" ;
        }else{
          this.data['winHeatStateFront'] = "On";
          this.data['winHeatStateRear'] =  "On";
        }
      },
      error=>{
        this.loading = false;
        this.errormsgs = error.err;
      }
    );
  }
  /*
	Method to save the climatizationsettings
  */
  climatizationsettings(){
    this.loading = true;
    this.saveClimatization['extPwrSpply'] = (this.saveClimatization['extPwrSpply'])  ? "Yes" : "No";
    //this.saveClimatization['trgtTemp'] = this.saveClimatization['trgtTemp'];
    if(this.saveClimatization['winHeatStateRear']  && this.saveClimatization['winHeatStateFront']){
        this.saveClimatization['winHeat'] = "Both";
     }else if(this.saveClimatization['winHeatStateFront'] && this.saveClimatization['winHeat'] ===''){
        this.saveClimatization['winHeat'] =  "Front";
    }else if(this.saveClimatization['winHeatStateRear'] && this.saveClimatization['winHeat'] ===''){
        this.saveClimatization['winHeat'] = "Rear";
    }else{
        this.saveClimatization['winHeat'] = '';
    }

    this.climatizationService.saveclimatization(this.saveClimatization).subscribe(
      info=>{
          this.getRemoteClimatization('');
          this.loading = false;
          this.msgs.push({ severity: 'success', summary: '', detail: myGlobals.update });
      },
      error=>{
        this.loading = false;
        this.msgs.push({ severity: 'error', summary: '', detail: error });
      }
  );
  }

  
}
