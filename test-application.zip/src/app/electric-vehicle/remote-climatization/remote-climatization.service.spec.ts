// import { TestBed, inject } from '@angular/core/testing';

// import { RemoteClimatizationService } from './remote-climatization.service';

// describe('RemoteClimatizationService', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       providers: [RemoteClimatizationService]
//     });
//   });

//   it('should ...', inject([RemoteClimatizationService], (service: RemoteClimatizationService) => {
//     expect(service).toBeTruthy();
//   }));
// });
