// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { RemoteClimatizationComponent } from './remote-climatization.component';

// describe('RemoteClimatizationComponent', () => {
//   let component: RemoteClimatizationComponent;
//   let fixture: ComponentFixture<RemoteClimatizationComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ RemoteClimatizationComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(RemoteClimatizationComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
