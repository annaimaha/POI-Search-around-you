import { Component } from '@angular/core';

@Component({
  selector: 'remotelcimatization',
  templateUrl: './remote-climatization.component.html'
})
export class RemoteClimatizationComponent  {

  information: any;
  tabName: any;
  constructor() {
    this.tabName = "settings";
  }

  commonTabs(Tabs) {
    this.tabName = "";
    this.tabName = Tabs;
  }
}
