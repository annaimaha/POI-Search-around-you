import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';



import { PerfectScrollbarModule } from 'angular2-perfect-scrollbar';
import { By }           from '@angular/platform-browser';
import { PerfectScrollbarConfigInterface } from 'angular2-perfect-scrollbar';


import { EcallDetailsViewComponent } from './ecall-details-view.component';
import { LoadingGifDataComponent } from '../../../loading-gif-data/loading-gif-data.component';
import { GrowlModule } from 'primeng/primeng';

import { MapService } from '../../../../services/map.service';
import { Observable }     from 'rxjs/Observable';
import { MockBackend, MockConnection } from '@angular/http/testing';
import {
  Http, HttpModule, XHRBackend, ResponseOptions,
  Response, BaseRequestOptions
} from '@angular/http';

import {EcallService} from '../ecall.service';
import {FakeEcallService} from '../../../../services/mock-services/ecall.fake-service';
declare var L: any;

 const PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
    suppressScrollX: true
        };
let mockWindow : any = {

};
let eCallService: any;
let mockViewItems: any =  {
                                "srNumber": "1-1287068981",
                                "accountName": null,
                                "createDate": "2016-10-21 10:11:06 UTC",
                                "srStatus": "Closed",
                                "source": "A.C.N",
                                "closedDate": null,
                                "type": "Emergency",
                                "resolution": null,
                                "description": null,
                                "address": null,
                                "city": null,
                                "state": null,
                                "zip": null,
                                "county": null,
                                "country": null,
                                "altitude": null,
                                "vehInMovement": null,
                                "directionHeading": null,
                                "odometerReading": null,
                                "latitude": 40.731253,
                                "longitude": -73.996139,
                                "locationConfidence": null,
                                "location": "loc",
                                "protocolDevId": null,
                                "seqNum": null,
                                "eCallModeIndicator": null,
                                "hmiLang": null,
                                "estLocPrec": null,
                                "crashIntsty": null,
                                "crashInfoFront": null,
                                "crashInfoLeft": null,
                                "crashInfoRear": null,
                                "crashInfoRight": null,
                                "crashInfoRolOvr": null,
                                "seatOcc1stLft": null,
                                "seatOcc1stMid": null,
                                "seatOcc1stRgt": null,
                                "seatOcc2ndLft": null,
                                "seatOcc2ndRgt": null,
                                "seatOcc2ndMid": null,
                                "ignStat": null,
                                "asmdOccpts": null,
                                "vehSpd": null,
                                "engStat": null,
                                "doorStat1stLft": null,
                                "doorStat1stRgt": null,
                                "doorStat2ndLft": null,
                                "doorStat2ndRgt": null,
                                "doorStatEngHood": null,
                                "doorStatRrFlp": null,
                                "locTrueInd": null,
                                "freeRNSPositions": null,
                                "crusingRange": null,
                                "smsOriginDateTime": "2016-10-21 10:11:05 UTC",
                                "interactionId": "INTAECCALL12345"
};

mockWindow.L = L;

describe('EcallDetailsViewComponent', () => {
  let component: EcallDetailsViewComponent;
  let fixture: ComponentFixture<EcallDetailsViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EcallDetailsViewComponent, LoadingGifDataComponent],
      imports: [PerfectScrollbarModule.forRoot(PERFECT_SCROLLBAR_CONFIG), GrowlModule],
      providers : [
          MapService,
          {
          provide: Http, useFactory: (backend: any, options: any) => {
            return new Http(backend, options);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        MockBackend,
        BaseRequestOptions,
        {provide: EcallService, useClass: FakeEcallService}  ,
        {provide: Window, useValue: mockWindow}
      ]
    })
    .overrideComponent(LoadingGifDataComponent, {
            set: {
                selector: 'loading-gif-data',
                template: `<span></span>`
            }
        })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EcallDetailsViewComponent);
    component = fixture.componentInstance;
    component.viewItems = mockViewItems;
    eCallService = fixture.debugElement.injector.get(EcallService);
 //   fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  
it('should create map onInit', () => {
     
     spyOn(component,'getEcallDetails');
      component.ngOnInit();
      expect(component.map).not.toBe(undefined);
      expect(component.markersLayer).not.toBe(undefined);
      expect(component.getEcallDetails).toHaveBeenCalled();
  });

  it('should set markers on getEcallDetails ', () => {
      fixture.detectChanges();
      spyOn(component.map, 'panTo');
      spyOn(component.markersLayer, 'addLayer');
      component.getEcallDetails();
      expect(component.emergencyCall).toEqual(component.viewItems);
     expect(component.map.panTo).toHaveBeenCalled();
   //  expect(component.markersLayer.addLayer).toHaveBeenCalled();
  });
  it('should execute ecallService.closeServiceRequestEcall on closeServiceRequestIcall: success ', () => {
     spyOn(eCallService, 'closeServiceRequestEcall')
          .and.returnValue(Observable.of({
              responseStatus: 'success',
              responseDescription:''
          })); 
          component.closeServiceRequestIcall();
           expect(eCallService.closeServiceRequestEcall).toHaveBeenCalled();
          expect(component.loading).toBe(false);
          expect(component.msgs).toEqual([{severity: 'success', summary: '', detail: "" }]);
  });

   it('should execute ecallService.closeServiceRequestEcall on closeServiceRequestIcall: else', () => {
     spyOn(eCallService, 'closeServiceRequestEcall')
          .and.returnValue(Observable.of({
              responseStatus: 'something',
              responseDescription:''
          })); 
          component.closeServiceRequestIcall();
           expect(eCallService.closeServiceRequestEcall).toHaveBeenCalled();
          expect(component.loading).toBe(false);
          expect(component.msgs).toEqual([{severity: 'error', summary: '', detail: "" }]);
  });

  it('should execute ecallService.closeServiceRequestEcall on closeServiceRequestIcall: error ', () => {
     spyOn(eCallService, 'closeServiceRequestEcall')
          .and.returnValue(Observable.throw('error')); 
          component.closeServiceRequestIcall();
          expect(eCallService.closeServiceRequestEcall).toHaveBeenCalled();
          expect(component.loading).toBe(false);
          expect(component.msgs).toEqual([{severity: 'error', summary: '', detail: "error" }]);
  });

  it('should execute ecallService.inBandLocationIcall on inBandLocationIcall: success ', () => {
     spyOn(eCallService, 'inBandLocationEcall')
          .and.returnValue(Observable.of({
              responseStatus: 'success',
              responseDescription:''
          })); 
          component.inBandLocationIcall();
          expect(eCallService.inBandLocationEcall).toHaveBeenCalled();
          expect(component.loading).toBe(false);
          expect(component.msgs).toEqual([{severity: 'success', summary: '', detail: "" }]);
  });

   it('should execute ecallService.inBandLocationIcall on inBandLocationIcall: else', () => {
     spyOn(eCallService, 'inBandLocationEcall')
          .and.returnValue(Observable.of({
              responseStatus: 'something',
              responseDescription:''
          })); 
          component.inBandLocationIcall();
          expect(eCallService.inBandLocationEcall).toHaveBeenCalled();
          expect(component.loading).toBe(false);
          expect(component.msgs).toEqual([{severity: 'error', summary: '', detail: "" }]);
  });

  it('should execute ecallService.inBandLocationIcall on inBandLocationIcall: error ', () => {
     spyOn(eCallService, 'inBandLocationEcall')
          .and.returnValue(Observable.throw('error')); 
          component.inBandLocationIcall();
           expect(eCallService.inBandLocationEcall).toHaveBeenCalled();
          expect(component.loading).toBe(false);
          expect(component.msgs).toEqual([{severity: 'error', summary: '', detail: "error" }]);
  });

  it('should change tabName on commonTabs click', () => {
    component.commonTabs('newTab');
    fixture.detectChanges();
    expect(component.tabName).toBe('newTab');
  });

  it('should call closeServiceRequestIcall on close req button click', () => {
      spyOn(component,'closeServiceRequestIcall');
      fixture.detectChanges();
      let clickElem: any = fixture.debugElement.query(By.css('.closeReq'));
     // clickElem.dispatchEvent(new Event('click'));
     clickElem.nativeElement.click();
      expect(component.closeServiceRequestIcall).toHaveBeenCalled();
  });

  it('should call inBandLocationIcall on  inBandLoc button click', () => {
      spyOn(component,'inBandLocationIcall');
      fixture.detectChanges();
      let clickElem: any = fixture.debugElement.query(By.css('.inBandLoc'));
     // clickElem.dispatchEvent(new Event('click'));
     clickElem.nativeElement.click();
      expect(component.inBandLocationIcall).toHaveBeenCalled();
  });
});
