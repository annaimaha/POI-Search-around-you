import { Component, OnInit,Input} from '@angular/core';
import {emergencyCallDTO} from '../../../../model/emergencyCallDTO';
import { MapService } from '../../../../services/map.service';
import {EcallService} from '../ecall.service';
import {myGlobals} from '../../../../constants/globals';
import {Message} from 'primeng/primeng';
declare var L: any;
@Component({
  selector: 'ecalldetailsview',
  templateUrl: 'ecall-details-view.component.html',
  providers:[EcallService,MapService]
})
export class EcallDetailsViewComponent implements OnInit {

  tabName: any;
    data:any;
    loading:any;
    @Input() viewItems:any;
    msgs: Message[] = [];
    growlLife: Number = myGlobals.disAppearTimeMessage;
    map:any;
    markersLayer:any;
    greenIcon = new L.Icon({ iconUrl: myGlobals.greenIcon, shadowUrl: myGlobals.greenIcon, iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], shadowSize: [41, 41] });
    emergencyCall = new emergencyCallDTO('','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','');

    constructor(private ecallservice:EcallService,private mapService:MapService) {
      this.tabName = "listview";
    }

    ngOnInit() {
      this.map = L.map('ecallpoi').setView([40.731253, -73.996139], 13);
      // base layer
      this.map.addLayer(new L.TileLayer('https://{s}.tiles.mapbox.com/v4/mapquest.streets/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwcXVlc3QiLCJhIjoiY2Q2N2RlMmNhY2NiZTRkMzlmZjJmZDk0NWU0ZGJlNTMifQ.mPRiEubbajc6a5y9ISgydg'));
      this.markersLayer = new L.LayerGroup();
      this.map.addLayer(this.markersLayer);
      this.getEcallDetails();
    }

    /*
      Method to get the Details of the list views
    */

    getEcallDetails(){

      this.emergencyCall = this.viewItems;
      
      let latitude  = this.emergencyCall['latitude'];
      let longitude = this.emergencyCall['longitude'];

      if (latitude !==null && latitude !=="" && longitude !==null && longitude !=="" ) {
        let loc = [parseFloat(latitude), parseFloat(longitude)];
        let marker = new L.Marker(loc, { icon: this.greenIcon });
        this.markersLayer.addLayer(marker);
        this.map.panTo(loc);
      }

    }

    // Methods  to triger the close service Request
    closeServiceRequestIcall(){
      this.loading = true;
      this.ecallservice.closeServiceRequestEcall(this.emergencyCall).subscribe(        
        info => {
            this.loading = false;
            if(info['responseStatus']==="success"){              
              this.msgs.push({ severity: 'success', summary: '', detail: info['responseDescription'] });
            }else{              
              this.msgs.push({ severity: 'error', summary: '', detail: info['responseDescription'] });
            }              
            },
        error =>{
            this.loading = false;
            this.msgs.push({ severity: 'error', summary: '', detail: error });
        }
      );
    }

    // Methods  to triger the inband Location call
    inBandLocationIcall(){
      this.loading = true;
      this.ecallservice.inBandLocationEcall(this.emergencyCall).subscribe(
				info => {
            this.loading = false;
            if(info['responseStatus']==="success"){              
              this.msgs.push({ severity: 'success', summary: '', detail: info['responseDescription'] });
            }else{              
              this.msgs.push({ severity: 'error', summary: '', detail: info['responseDescription'] });
            } 
        		},
				error =>{
            this.loading = false;
            this.msgs.push({ severity: 'error', summary: '', detail: error });
				}
      );
    }

    /*
      Methods to Enable and disable the views of components
      @params tabs string which tab Should be view
    */
    commonTabs(Tabs: any) {
      this.tabName = "";
      this.tabName = Tabs;
    }

}
