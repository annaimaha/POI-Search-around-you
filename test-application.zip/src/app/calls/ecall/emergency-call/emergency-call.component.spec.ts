import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmergencyCallComponent } from './emergency-call.component';
import { DebugElement, NO_ERRORS_SCHEMA }    from '@angular/core';

describe('EmergencyCallComponent', () => {
  let component: EmergencyCallComponent;
  let fixture: ComponentFixture<EmergencyCallComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmergencyCallComponent ],
      schemas:[NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmergencyCallComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should have tabName inittailized', () => {
      fixture.detectChanges();
      expect(component.tabName).toBe('listview');  
  });
  it('should change view items on viewCallDetails', () =>{
      component.viewecallDetails({view:'detailview',item:{"srNumber": "1-1287068981"}});
      expect(component.tabName).toBe('detailview');
      expect(component.viewItems).toEqual({"srNumber": "1-1287068981"});
  });
  it('should change tabName on commonTabs click', () => {
    component.commonTabs('newTab');
    fixture.detectChanges();
    expect(component.tabName).toBe('newTab');
  });
});
