import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'aecall',
  templateUrl: 'emergency-call.component.html'
})
export class EmergencyCallComponent implements OnInit {
	tabName: any;
    viewItems:any;
	
    constructor() {
      this.tabName = "listview";
    }

    ngOnInit() {

    }

    viewecallDetails(events: any){
      this.tabName = events.view;
      this.viewItems    = events.item;
    }

    /*
      Methods to Enable and disable the views of components
      @params tabs string which tab Should be view
    */
    
    commonTabs(Tabs: any) {
      this.tabName = "";
      this.tabName = Tabs;
    }

}
