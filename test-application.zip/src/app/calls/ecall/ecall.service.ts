import { Injectable } from '@angular/core';
import { Observable }     from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import {myGlobals} from '../../../constants/globals';
import { Http, Response,Headers,RequestOptions,URLSearchParams} from '@angular/http';
declare var sessionStorage : any;
@Injectable()
export class EcallService {

	private headers:any;
	
	constructor(private http:Http){
        this.headers = new Headers();
        this.headers.append('Content-Type', 'application/json');
		this.headers.append('api-key', 'vzt-vtp-locationsvc');
    }

	// Icall
	getEcall(){
        return this.http.get(myGlobals.emergencyCallList+sessionStorage["params"],{ headers: this.headers,withCredentials: true })
            .map(this.extractData)
            .catch(this.handleError);
    }

	getEcallDetails(postdata:any){
    let params = new URLSearchParams();
    params.set('detailView', "false");
    params.set('srNo', postdata.srNumber);
    params.set('emergencySrID', postdata.srNumber);
        return this.http.get(myGlobals.emergencyCallDetail+sessionStorage["params"],{search: params,headers: this.headers,withCredentials: true})
            .map(this.extractData)
            .catch(this.handleError);
    }


    // Methods to get inBandLocationIcall

    inBandLocationEcall(postdata:any){
      let paramsInBand = new URLSearchParams();
      paramsInBand.set('srNo', postdata.srNumber);
      paramsInBand.set('interactionId', postdata.interactionId);

      return this.http.get(myGlobals.inBandLocationEcall+sessionStorage["params"],{search: paramsInBand,headers: this.headers,withCredentials: true})
              .map(this.extractData)
              .catch(this.handleError);
    }

    // Methods to closeServiceRequest Icall

    closeServiceRequestEcall(postdata:any){
      let paramsclose = new URLSearchParams();
      paramsclose.set('srNo', postdata.srNumber);

      return this.http.get(myGlobals.closeServiceRequestEcall+sessionStorage["params"],{search: paramsclose,headers: this.headers})
              .map(this.extractData)
              .catch(this.handleError);
    }

    private extractData(res: Response) {
        let body = res.json();
        return body.data?body.data: (body || {});
    }
    private handleError(error: Response | any) {
        // In a real world app, we might use a remote logging infrastructure
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} `;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        errMsg = (error.status == '0') ? myGlobals.badGateWay : errMsg;
        return Observable.throw(errMsg);
    }
}
