import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PerfectScrollbarModule } from 'angular2-perfect-scrollbar';
import { By }           from '@angular/platform-browser';
import { PerfectScrollbarConfigInterface } from 'angular2-perfect-scrollbar';
import { DataTableModule } from "angular2-datatable";
import { GrowlModule } from 'primeng/primeng';
import { MockBackend, MockConnection } from '@angular/http/testing';
import {
  Http, HttpModule, XHRBackend, ResponseOptions,
  Response, BaseRequestOptions
} from '@angular/http';

import {EcallService} from '../ecall.service';
import {FakeEcallService} from '../../../../services/mock-services/ecall.fake-service';
import { EcallListViewComponent } from './ecall-list-view.component';
import { LoadingGifDataComponent } from '../../../loading-gif-data/loading-gif-data.component';
import { Injectable } from '@angular/core';
import { Observable }     from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

describe('EcallListViewComponent', () => {
  let component: EcallListViewComponent;
  let fixture: ComponentFixture<EcallListViewComponent>;
  let eCallService: any;
  let serviceSpies: any = {};
  let listViewData: any = [{
                "srNumber": "1-1287068991",
                "accountName": "DEVICESIMULATIONDEVICESIMULATION AUDIAUDI",
                "createDate": "2016-10-21 10:11:17 UTC",
                "srStatus": "Closed",
                "source": null,
                "closedDate": null,
                "type": null,
                "resolution": null,
                "description": null,
                "address": null,
                "city": null,
                "state": null,
                "zip": null,
                "county": null,
                "country": null,
                "altitude": null,
                "vehInMovement": null,
                "directionHeading": null,
                "odometerReading": null,
                "latitude": null,
                "longitude": null,
                "locationConfidence": null,
                "location": null,
                "protocolDevId": null,
                "seqNum": null,
                "eCallModeIndicator": null,
                "hmiLang": null,
                "estLocPrec": null,
                "crashIntsty": null,
                "crashInfoFront": null,
                "crashInfoLeft": null,
                "crashInfoRear": null,
                "crashInfoRight": null,
                "crashInfoRolOvr": null,
                "seatOcc1stLft": null,
                "seatOcc1stMid": null,
                "seatOcc1stRgt": null,
                "seatOcc2ndLft": null,
                "seatOcc2ndRgt": null,
                "seatOcc2ndMid": null,
                "ignStat": null,
                "asmdOccpts": null,
                "vehSpd": null,
                "engStat": null,
                "doorStat1stLft": null,
                "doorStat1stRgt": null,
                "doorStat2ndLft": null,
                "doorStat2ndRgt": null,
                "doorStatEngHood": null,
                "doorStatRrFlp": null,
                "locTrueInd": null,
                "freeRNSPositions": null,
                "crusingRange": null,
                "smsOriginDateTime": null,
                "interactionId": null
}];

let detailViewData: any ={
                "emergencyCallDTO": {
                                "srNumber": "1-1287068981",
                                "accountName": null,
                                "createDate": "2016-10-21 10:11:06 UTC",
                                "srStatus": "Closed",
                                "source": "A.C.N",
                                "closedDate": null,
                                "type": "Emergency",
                                "resolution": null,
                                "description": null,
                                "address": null,
                                "city": null,
                                "state": null,
                                "zip": null,
                                "county": null,
                                "country": null,
                                "altitude": null,
                                "vehInMovement": null,
                                "directionHeading": null,
                                "odometerReading": null,
                                "latitude": "",
                                "longitude": "",
                                "locationConfidence": null,
                                "location": "loc",
                                "protocolDevId": null,
                                "seqNum": null,
                                "eCallModeIndicator": null,
                                "hmiLang": null,
                                "estLocPrec": null,
                                "crashIntsty": null,
                                "crashInfoFront": null,
                                "crashInfoLeft": null,
                                "crashInfoRear": null,
                                "crashInfoRight": null,
                                "crashInfoRolOvr": null,
                                "seatOcc1stLft": null,
                                "seatOcc1stMid": null,
                                "seatOcc1stRgt": null,
                                "seatOcc2ndLft": null,
                                "seatOcc2ndRgt": null,
                                "seatOcc2ndMid": null,
                                "ignStat": null,
                                "asmdOccpts": null,
                                "vehSpd": null,
                                "engStat": null,
                                "doorStat1stLft": null,
                                "doorStat1stRgt": null,
                                "doorStat2ndLft": null,
                                "doorStat2ndRgt": null,
                                "doorStatEngHood": null,
                                "doorStatRrFlp": null,
                                "locTrueInd": null,
                                "freeRNSPositions": null,
                                "crusingRange": null,
                                "smsOriginDateTime": "2016-10-21 10:11:05 UTC",
                                "interactionId": "INTAECCALL12345"
                },
                "unitlocDtoList": []
};

  const PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
    suppressScrollX: true
        };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EcallListViewComponent, LoadingGifDataComponent ],
      imports: [PerfectScrollbarModule.forRoot(PERFECT_SCROLLBAR_CONFIG),
      DataTableModule,
      GrowlModule
      ],
      providers: [
          {
          provide: Http, useFactory: (backend: any, options: any) => {
            return new Http(backend, options);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        MockBackend,
        BaseRequestOptions,
        {provide: EcallService, useClass: FakeEcallService}  
      ]
    })
    .overrideComponent(LoadingGifDataComponent, {
            set: {
                selector: 'loading-gif-data',
                template: `<span></span>`
            }
        })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EcallListViewComponent);
    component = fixture.componentInstance;
    eCallService = fixture.debugElement.injector.get(EcallService);
    /*serviceSpies.getEcall = spyOn(eCallService, 'getEcall')
          .and.returnValue(Observable.of([]));*/
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have tabName initialized', () => {
      expect(component.tabName).toBe('listview');
  });

  it('should call getEcallLists on Init',() => {
      spyOn(component, 'getEcallLists');
      component.ngOnInit();
      expect(component.getEcallLists).toHaveBeenCalled();
  });
  it('should call eCallService.getEcall on getEcallLists', () => {
    spyOn(eCallService, 'getEcall')
          .and.returnValue(Observable.of([]));
      component.getEcallLists();
      fixture.detectChanges();
      expect(eCallService.getEcall).toHaveBeenCalled();
      expect(component.errormsgs).toBe('No Records Found.');
   //   accountNumber=103011633&tcuId=355414050002595&vin=BVWL07AJ2FM263381&userTimeZoneStr=est
  });

  it('should execute if JSON condition on receiving data', () => {
    spyOn(eCallService, 'getEcall')
          .and.returnValue(Observable.of(listViewData));
      fixture.detectChanges();
      expect(component.data.length).not.toBe(0);
    //  expect(eCallService.getEcall).toHaveBeenCalled();
   //   accountNumber=103011633&tcuId=355414050002595&vin=BVWL07AJ2FM263381&userTimeZoneStr=est
  });

  it('should execute error block if error is returned ', () => {
    spyOn(eCallService, 'getEcall')
          .and.returnValue(Observable.throw('error is thrown'));

      fixture.detectChanges();
      expect(component.errormsgs).toBe('error is thrown');
   //   accountNumber=103011633&tcuId=355414050002595&vin=BVWL07AJ2FM263381&userTimeZoneStr=est
  });

  it('shoud call ecallService.getEcallDetails with params on viewEcallItem', () => {
    spyOn(eCallService, 'getEcallDetails')
          .and.returnValue(Observable.of({}));
      component.viewEcallItem(listViewData);
      fixture.detectChanges();
      expect(component.loading).toBe(false);
      expect(eCallService.getEcallDetails).toHaveBeenCalled();
      expect(component.msgs).toEqual([{
        severity: 'error', summary: '', detail: "No Records Found."}
      ]);
     // expect(component.errormsgs).toBe('No Records Found.');
  });


   it('shoud call ecallService.getEcallDetails with params on viewEcallItem: If emergencyCallDTO', () => {
      spyOn(eCallService, 'getEcallDetails')
            .and.returnValue(Observable.of(detailViewData));
      spyOn(component.ecallViewEvent, 'emit');
      component.viewEcallItem(listViewData);
      fixture.detectChanges();
      expect(component.ecallViewEvent.emit).toHaveBeenCalled();
      expect(component.ecallViewEvent.emit).toHaveBeenCalledWith({view:'detailview',item:detailViewData['emergencyCallDTO']});

     // expect(component.errormsgs).toBe('No Records Found.');
  });

  it('should execute error block if error is returned ', () => {
    spyOn(eCallService, 'getEcallDetails')
          .and.returnValue(Observable.throw('error is thrown'));
      component.viewEcallItem(listViewData);
      fixture.detectChanges();
      expect(component.loading).toBe(false);
      expect(component.msgs).toContain({ severity: 'error', summary: '', detail: "error is thrown" });
   //   accountNumber=103011633&tcuId=355414050002595&vin=BVWL07AJ2FM263381&userTimeZoneStr=est
  });

  it('should change tabName on commonTabs click', () => {
    component.commonTabs('newTab');
    fixture.detectChanges();
    expect(component.tabName).toBe('newTab');
  });

  it('should initialize datatable when list data is provided', () => {
      spyOn(eCallService, 'getEcall')
            .and.returnValue(Observable.of([listViewData, listViewData]));
      spyOn(component,'viewEcallItem');
      fixture.detectChanges();
      expect(component.data.length).not.toBe(0);
      let clickElem: any = fixture.debugElement.query(By.css('.callDetailView'));
     // clickElem.dispatchEvent(new Event('click'));
     clickElem.nativeElement.click();
      expect(component.viewEcallItem).toHaveBeenCalled();
  });

  

});
