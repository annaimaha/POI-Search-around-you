import { Component, OnInit,Output, EventEmitter } from '@angular/core';
import {Message} from 'primeng/primeng';
import {EcallService} from '../ecall.service';
import {myGlobals} from '../../../../constants/globals';
@Component({
  selector: 'ecalllistview',
  templateUrl: 'ecall-list-view.component.html',
  providers:[EcallService]
})
export class EcallListViewComponent implements OnInit {

	tabName: any;
    public data:any;
    public filterQuery = "";
    public rowsOnPage = myGlobals.rowsOnPage;
    public sortBy = "accountName";
    public sortOrder = myGlobals.sortOrder;
    msgs: Message[] = [];
    growlLife: Number = myGlobals.disAppearTimeMessage;
    loading:any;
    errormsgs:any;
    @Output() ecallViewEvent: EventEmitter<any> = new EventEmitter();
    constructor(private ecallservice:EcallService) {
      this.tabName = "listview";
    }

    ngOnInit() {
      this.getEcallLists();  
    }

    /*
    Method to get the list view
    */
    getEcallLists(){
      this.ecallservice.getEcall().subscribe(
				info => {
							if(!(JSON.stringify(info) === JSON.stringify([]))){
                this.data = info;
              }else{
                this.errormsgs = myGlobals.noData;
              }
						},
				error =>{
						this.errormsgs = error;
				}
      );
    }

    /*
      Methods to trigger the emit event for the call details viewItems
      @params items object
    */
    viewEcallItem(items: any){      
      this.loading = true;
      this.ecallservice.getEcallDetails(items).subscribe(
				info => {
            this.loading = false;
              if(info['emergencyCallDTO'] && info['emergencyCallDTO'] !==null && info['emergencyCallDTO'] !==""){
                this.ecallViewEvent.emit({view:'detailview',item:info['emergencyCallDTO']});
              }else{
                this.msgs.push({ severity: 'error', summary: '', detail: myGlobals.noData });    
              }
						},
				    error =>{
            this.loading = false;
            this.msgs.push({ severity: 'error', summary: '', detail: error });
				}
      );
      
    }

    /*
      Methods to Enable and disable the views of components
      @params tabs string which tab Should be view
    */
    commonTabs(Tabs: any) {
      this.tabName = "";
      this.tabName = Tabs;
    }
}
