import { TestBed, inject } from '@angular/core/testing';
import { MockBackend, MockConnection } from '@angular/http/testing';
import {
  Http, HttpModule, XHRBackend, ResponseOptions,
  Response, BaseRequestOptions
} from '@angular/http';
import { Observable }     from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import { EcallService } from './ecall.service';

describe('EcallService', () => {
    let ecallService: EcallService = null;
  let backend: MockBackend = null;
  let listViewData: any = [{
                "srNumber": "1-1287068991",
                "accountName": "DEVICESIMULATIONDEVICESIMULATION AUDIAUDI",
                "createDate": "2016-10-21 10:11:17 UTC",
                "srStatus": "Closed",
                "source": null,
                "closedDate": null,
                "type": null,
                "resolution": null,
                "description": null,
                "address": null,
                "city": null,
                "state": null,
                "zip": null,
                "county": null,
                "country": null,
                "altitude": null,
                "vehInMovement": null,
                "directionHeading": null,
                "odometerReading": null,
                "latitude": null,
                "longitude": null,
                "locationConfidence": null,
                "location": null,
                "protocolDevId": null,
                "seqNum": null,
                "eCallModeIndicator": null,
                "hmiLang": null,
                "estLocPrec": null,
                "crashIntsty": null,
                "crashInfoFront": null,
                "crashInfoLeft": null,
                "crashInfoRear": null,
                "crashInfoRight": null,
                "crashInfoRolOvr": null,
                "seatOcc1stLft": null,
                "seatOcc1stMid": null,
                "seatOcc1stRgt": null,
                "seatOcc2ndLft": null,
                "seatOcc2ndRgt": null,
                "seatOcc2ndMid": null,
                "ignStat": null,
                "asmdOccpts": null,
                "vehSpd": null,
                "engStat": null,
                "doorStat1stLft": null,
                "doorStat1stRgt": null,
                "doorStat2ndLft": null,
                "doorStat2ndRgt": null,
                "doorStatEngHood": null,
                "doorStatRrFlp": null,
                "locTrueInd": null,
                "freeRNSPositions": null,
                "crusingRange": null,
                "smsOriginDateTime": null,
                "interactionId": null
}];



let detailViewData: any ={
                "emergencyCallDTO": {
                                "srNumber": "1-1287068981",
                                "accountName": null,
                                "createDate": "2016-10-21 10:11:06 UTC",
                                "srStatus": "Closed",
                                "source": "A.C.N",
                                "closedDate": null,
                                "type": "Emergency",
                                "resolution": null,
                                "description": null,
                                "address": null,
                                "city": null,
                                "state": null,
                                "zip": null,
                                "county": null,
                                "country": null,
                                "altitude": null,
                                "vehInMovement": null,
                                "directionHeading": null,
                                "odometerReading": null,
                                "latitude": "",
                                "longitude": "",
                                "locationConfidence": null,
                                "location": "loc",
                                "protocolDevId": null,
                                "seqNum": null,
                                "eCallModeIndicator": null,
                                "hmiLang": null,
                                "estLocPrec": null,
                                "crashIntsty": null,
                                "crashInfoFront": null,
                                "crashInfoLeft": null,
                                "crashInfoRear": null,
                                "crashInfoRight": null,
                                "crashInfoRolOvr": null,
                                "seatOcc1stLft": null,
                                "seatOcc1stMid": null,
                                "seatOcc1stRgt": null,
                                "seatOcc2ndLft": null,
                                "seatOcc2ndRgt": null,
                                "seatOcc2ndMid": null,
                                "ignStat": null,
                                "asmdOccpts": null,
                                "vehSpd": null,
                                "engStat": null,
                                "doorStat1stLft": null,
                                "doorStat1stRgt": null,
                                "doorStat2ndLft": null,
                                "doorStat2ndRgt": null,
                                "doorStatEngHood": null,
                                "doorStatRrFlp": null,
                                "locTrueInd": null,
                                "freeRNSPositions": null,
                                "crusingRange": null,
                                "smsOriginDateTime": "2016-10-21 10:11:05 UTC",
                                "interactionId": "INTAECCALL12345"
                },
                "unitlocDtoList": []
};


  
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [{
          provide: Http, useFactory: (backend: any, options: any) => {
            return new Http(backend, options);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        MockBackend,
        BaseRequestOptions,
        EcallService]
    });
  });

  beforeEach(inject([EcallService, MockBackend], (service: EcallService, mockBackend: MockBackend) => {
    ecallService = service;
    backend = mockBackend;
  }));

  it('should be initialized', inject([EcallService], (service: EcallService) => {
    expect(service).toBeTruthy();
  }));


   it('should get listViewdata on invocation of Ecall', (done) => {
       console.log(backend, ecallService);
    backend.connections.subscribe((connection: MockConnection) => {
      let options = new ResponseOptions({ body: listViewData });

      connection.mockRespond(new Response(options));
    });

    ecallService.getEcall().subscribe((response: any) => {
      expect(response).toEqual(listViewData);
      done();
    });
  });


   it ('should return result on invocation of getEcall: empty array', inject([EcallService], (service: EcallService) => {
    spyOn(service, 'getEcall')
          .and.returnValue(Observable.throw({error: 'error'}));
          service.getEcall().subscribe( res => {

          },
          err =>{
              expect(err.error).toBe('error');
          }
          );
  }));



it('should get detailViewData on invocation of getEcallDetails', (done) => {
       console.log(backend, ecallService);
    backend.connections.subscribe((connection: MockConnection) => {
      let options = new ResponseOptions({ body: detailViewData });

      connection.mockRespond(new Response(options));
    });

    ecallService.getEcallDetails(listViewData[0]).subscribe((response: any) => {
      expect(response).toEqual(detailViewData);
      done();
    });
  });

   it ('should return result on invocation of getEcallDetails: empty array', inject([EcallService], (service: EcallService) => {
    spyOn(service, 'getEcallDetails')
          .and.returnValue(Observable.throw({error: 'error'}));
          service.getEcallDetails({}).subscribe( res => {

          },
          err =>{
              expect(err.error).toBe('error');
          }
          );
  }));


  it('should get inBandLocationEcalldata on invocation of inBandLocationEcall', (done) => {
      let res = {responseStatus:'success', responseDescription:''};
    backend.connections.subscribe((connection: MockConnection) => {
      let options = new ResponseOptions({ body:  res});

      connection.mockRespond(new Response(options));
    });

    ecallService.inBandLocationEcall(detailViewData['emergencyCallDTO']).subscribe((response: any) => {
      expect(response).toEqual(res);
      done();
    });
  });

   it ('should return result on invocation of inBandLocationEcall: empty array', inject([EcallService], (service: EcallService) => {
    spyOn(service, 'inBandLocationEcall')
          .and.returnValue(Observable.throw({error: 'error'}));
          service.inBandLocationEcall({}).subscribe( res => {

          },
          err =>{
              expect(err.error).toBe('error');
          }
          );
  }));




 it('should get closeServiceRequestEcalldata on invocation of closeServiceRequestEcall', (done) => {
      let res = {responseStatus:'success', responseDescription:''};
    backend.connections.subscribe((connection: MockConnection) => {
      let options = new ResponseOptions({ body:  res});

      connection.mockRespond(new Response(options));
    });

    ecallService.closeServiceRequestEcall(detailViewData['emergencyCallDTO']).subscribe((response: any) => {
      expect(response).toEqual(res);
      done();
    });
  });

   it ('should return result on invocation of closeServiceRequestEcall: empty array', inject([EcallService], (service: EcallService) => {
    spyOn(service, 'closeServiceRequestEcall')
          .and.returnValue(Observable.throw({error: 'error'}));
          service.closeServiceRequestEcall({}).subscribe( res => {

          },
          err =>{
              expect(err.error).toBe('error');
          }
          );
  }));
});
