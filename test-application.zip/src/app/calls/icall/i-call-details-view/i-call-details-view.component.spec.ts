import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';



import { PerfectScrollbarModule } from 'angular2-perfect-scrollbar';
import { By }           from '@angular/platform-browser';
import { PerfectScrollbarConfigInterface } from 'angular2-perfect-scrollbar';


import { ICallDetailsViewComponent } from './i-call-details-view.component';
import { LoadingGifDataComponent } from '../../../loading-gif-data/loading-gif-data.component';
import { GrowlModule } from 'primeng/primeng';

import { MapService } from '../../../../services/map.service';
import { Observable }     from 'rxjs/Observable';
import { MockBackend, MockConnection } from '@angular/http/testing';
import {
  Http, HttpModule, XHRBackend, ResponseOptions,
  Response, BaseRequestOptions
} from '@angular/http';

import {IcallService} from '../icall.service';
import {FakeIcallService} from '../../../../services/mock-services/icall.fake-service';
declare var L: any;

 const PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
    suppressScrollX: true
        };
let mockWindow : any = {

};
let iCallService: any;
let mockViewItems: any =  {
                                "srNumber": "1-1287090731",
                                "accountName": null,
                                "createDate": "2016-10-21 12:43:18 UTC",
                                "srStatus": "Closed",
                                "source": "I-Call",
                                "closedDate": null,
                                "type": "I-Call",
                                "resolution": null,
                                "description": null,
                                "address": null,
                                "city": null,
                                "state": null,
                                "zip": null,
                                "county": null,
                                "country": null,
                                "altitude": null,
                                "vehInMovement": null,
                                "directionHeading": null,
                                "odometerReading": null,
                                "latitude": 40.731253,
                                "longitude": -73.996139,
                                "locationConfidence": null,
                                "location": "loc",
                                "protocolDevId": null,
                                "seqNum": null,
                                "eCallModeIndicator": null,
                                "hmiLang": null,
                                "estLocPrec": null,
                                "freeRnsPos": null,
                                "locTrueInd": null,
                                "cruiseRange": null,
                                "smsOriginDateTime": "2016-10-21 12:43:17 UTC",
                                "interactionId": "INTICALL12345",
                                "ecallModeIndicator": null

};

mockWindow.L = L;

describe('IcallDetailsViewComponent', () => {
  let component: ICallDetailsViewComponent;
  let fixture: ComponentFixture<ICallDetailsViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ICallDetailsViewComponent, LoadingGifDataComponent],
      imports: [PerfectScrollbarModule.forRoot(PERFECT_SCROLLBAR_CONFIG), GrowlModule],
      providers : [
          MapService,
          {
          provide: Http, useFactory: (backend: any, options: any) => {
            return new Http(backend, options);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        MockBackend,
        BaseRequestOptions,
        {provide: IcallService, useClass: FakeIcallService}  ,
        {provide: Window, useValue: mockWindow}
      ]
    })
    .overrideComponent(LoadingGifDataComponent, {
            set: {
                selector: 'loading-gif-data',
                template: `<span></span>`
            }
        })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ICallDetailsViewComponent);
    component = fixture.componentInstance;
    component.viewItems = mockViewItems;
    iCallService = fixture.debugElement.injector.get(IcallService);
 //   fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  
it('should create map onInit', () => {
     
     spyOn(component,'getIcallDetails');
      component.ngOnInit();
      expect(component.map).not.toBe(undefined);
      expect(component.markersLayer).not.toBe(undefined);
      expect(component.getIcallDetails).toHaveBeenCalled();
  });

  it('should set markers on getIcallDetails ', () => {
      fixture.detectChanges();
      spyOn(component.map, 'panTo');
      component.getIcallDetails();
      expect(component.informationCall).toEqual(component.viewItems);
     expect(component.map.panTo).toHaveBeenCalled();
   //  expect(component.markersLayer.addLayer).toHaveBeenCalled();
  });
  it('should execute icallService.closeServiceRequestIcall on closeServiceRequestIcall: success ', () => {
     spyOn(iCallService, 'closeServiceRequestIcall')
          .and.returnValue(Observable.of({
              responseStatus: 'success',
              responseDescription:''
          })); 
          component.closeServiceRequestIcall();
           expect(iCallService.closeServiceRequestIcall).toHaveBeenCalled();
          expect(component.loading).toBe(false);
          expect(component.msgs).toEqual([{severity: 'success', summary: '', detail: "" }]);
  });

   it('should execute icallService.closeServiceRequestIcall on closeServiceRequestIcall: else', () => {
     spyOn(iCallService, 'closeServiceRequestIcall')
          .and.returnValue(Observable.of({
              responseStatus: 'something',
              responseDescription:''
          })); 
          component.closeServiceRequestIcall();
           expect(iCallService.closeServiceRequestIcall).toHaveBeenCalled();
          expect(component.loading).toBe(false);
          expect(component.msgs).toEqual([{severity: 'error', summary: '', detail: "" }]);
  });

  it('should execute icallService.closeServiceRequestIcall on closeServiceRequestIcall: error ', () => {
     spyOn(iCallService, 'closeServiceRequestIcall')
          .and.returnValue(Observable.throw('error')); 
          component.closeServiceRequestIcall();
          expect(iCallService.closeServiceRequestIcall).toHaveBeenCalled();
          expect(component.loading).toBe(false);
          expect(component.msgs).toEqual([{severity: 'error', summary: '', detail: "error" }]);
  });

  it('should execute icallService.inBandLocationIcall on inBandLocationIcall: success ', () => {
     spyOn(iCallService, 'inBandLocationIcall')
          .and.returnValue(Observable.of({
              responseStatus: 'success',
              responseDescription:''
          })); 
          component.inBandLocationIcall();
          expect(iCallService.inBandLocationIcall).toHaveBeenCalled();
          expect(component.loading).toBe(false);
          expect(component.msgs).toEqual([{severity: 'success', summary: '', detail: "" }]);
  });

   it('should execute icallService.inBandLocationIcall on inBandLocationIcall: else', () => {
     spyOn(iCallService, 'inBandLocationIcall')
          .and.returnValue(Observable.of({
              responseStatus: 'something',
              responseDescription:''
          })); 
          component.inBandLocationIcall();
          expect(iCallService.inBandLocationIcall).toHaveBeenCalled();
          expect(component.loading).toBe(false);
          expect(component.msgs).toEqual([{severity: 'error', summary: '', detail: "" }]);
  });

  it('should execute icallService.inBandLocationIcall on inBandLocationIcall: error ', () => {
     spyOn(iCallService, 'inBandLocationIcall')
          .and.returnValue(Observable.throw('error')); 
          component.inBandLocationIcall();
           expect(iCallService.inBandLocationIcall).toHaveBeenCalled();
          expect(component.loading).toBe(false);
          expect(component.msgs).toEqual([{severity: 'error', summary: '', detail: "error" }]);
  });

  it('should change tabName on commonTabs click', () => {
    component.commonTabs('newTab');
    fixture.detectChanges();
    expect(component.tabName).toBe('newTab');
  });

  it('should call closeServiceRequestIcall on close req button click', () => {
      spyOn(component,'closeServiceRequestIcall');
      fixture.detectChanges();
      let clickElem: any = fixture.debugElement.query(By.css('.closeReq'));
     // clickElem.dispatchEvent(new Event('click'));
     clickElem.nativeElement.click();
      expect(component.closeServiceRequestIcall).toHaveBeenCalled();
  });

  it('should call inBandLocationIcall on  inBandLoc button click', () => {
      spyOn(component,'inBandLocationIcall');
      fixture.detectChanges();
      let clickElem: any = fixture.debugElement.query(By.css('.inBandLoc'));
     // clickElem.dispatchEvent(new Event('click'));
     clickElem.nativeElement.click();
      expect(component.inBandLocationIcall).toHaveBeenCalled();
  });
});
