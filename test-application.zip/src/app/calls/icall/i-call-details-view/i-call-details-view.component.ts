import { Component, OnInit, Input } from '@angular/core';
import { informationCallDTO } from '../../../../model/informationCallDTO';
import {IcallService} from '../icall.service';
import {myGlobals} from '../../../../constants/globals';
import { Message } from 'primeng/primeng';
import { MapService } from '../../../../services/map.service';
declare var L: any;

@Component({
  selector: 'icalldetailsview',
  templateUrl: 'i-call-details-view.component.html',
  providers: [IcallService, MapService]
})
export class ICallDetailsViewComponent implements OnInit {

  tabName: any;
  data: any;
  loading: any;
  @Input() viewItems;
  msgs: Message[] = [];
  growlLife: Number = myGlobals.disAppearTimeMessage;
  map: any;
  markersLayer: any;
  greenIcon = new L.Icon({ iconUrl: myGlobals.greenIcon, shadowUrl: myGlobals.shadowIcon, iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], shadowSize: [41, 41] });
  informationCall = new informationCallDTO('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
  constructor(private icallservice: IcallService, private mapService: MapService) {
    this.tabName = "listview";
  }
  
  ngOnInit() {
    
    this.map = L.map('icallpoi').setView([40.731253, -73.996139], 13);
    // base layer
    this.map.addLayer(new L.TileLayer('https://{s}.tiles.mapbox.com/v4/mapquest.streets/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwcXVlc3QiLCJhIjoiY2Q2N2RlMmNhY2NiZTRkMzlmZjJmZDk0NWU0ZGJlNTMifQ.mPRiEubbajc6a5y9ISgydg'));
    this.markersLayer = new L.LayerGroup();
    this.map.addLayer(this.markersLayer);
    this.getIcallDetails();
  }
  
   /*
    Method to get the Details of the list views
  */

  getIcallDetails() {
    this.informationCall = this.viewItems
    if(this.informationCall['latitude'] !=="" && this.informationCall['latitude'] !==null && this.informationCall['longitude'] !=="" && this.informationCall['longitude'] !==null){      
      let loc = [parseFloat(this.informationCall['latitude']), parseFloat(this.informationCall['longitude'])];
      let marker = new L.Marker(loc, { icon: this.greenIcon });
      this.markersLayer.addLayer(marker);
      this.map.panTo(loc);
    }
    
  }

  // Methods  to triger the close service Request
  closeServiceRequestIcall() {
    this.loading = true;
    this.icallservice.closeServiceRequestIcall(this.informationCall).subscribe(
      info => {
        this.loading = false;
        if (info['responseStatus'] === "success") {
          this.msgs.push({ severity: 'success', summary: '', detail: info['responseDescription'] });
        } else {
          this.msgs.push({ severity: 'error', summary: '', detail: info['responseDescription'] });
        }
      },
      error => {
        this.loading = false;
        this.msgs.push({ severity: 'error', summary: '', detail: error });
      }
    );
  }

  // Methods  to triger the inband Location call
  inBandLocationIcall() {
    this.loading = true;
    this.icallservice.inBandLocationIcall(this.informationCall).subscribe(
      info => {
        this.loading = false;
        if (info['responseStatus'] === "success") {
          this.msgs.push({ severity: 'success', summary: '', detail: info['responseDescription'] });
        } else {
          this.msgs.push({ severity: 'error', summary: '', detail: info['responseDescription'] });
        }
      },
      error => {
        this.loading = false;
        this.msgs.push({ severity: 'error', summary: '', detail: error });
      }
    );
  }

  /*
    Methods to Enable and disable the views of components
    @params tabs string which tab Should be view
  */
  commonTabs(Tabs) {
    this.tabName = "";
    this.tabName = Tabs;
  }

}
