import { TestBed, inject } from '@angular/core/testing';
import { MockBackend, MockConnection } from '@angular/http/testing';
import {
  Http, HttpModule, XHRBackend, ResponseOptions,
  Response, BaseRequestOptions
} from '@angular/http';
import { Observable }     from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import { IcallService } from './icall.service';

describe('IcallService', () => {
    let icallService: IcallService = null;
  let backend: MockBackend = null;
let listViewData: any = [{
                "srNumber": "1-1287103341",
                "accountName": "DEVICESIMULATIONDEVICESIMULATION AUDIAUDI",
                "createDate": "2016-10-21 13:28:49 UTC",
                "srStatus": "Closed",
                "source": null,
                "closedDate": null,
                "type": null,
                "resolution": null,
                "description": null,
                "address": null,
                "city": null,
                "state": null,
                "zip": null,
                "county": null,
                "country": null,
                "altitude": null,
                "vehInMovement": null,
                "directionHeading": null,
                "odometerReading": null,
                "latitude": null,
                "longitude": null,
                "locationConfidence": null,
                "location": null,
                "protocolDevId": null,
                "seqNum": null,
                "eCallModeIndicator": null,
                "hmiLang": null,
                "estLocPrec": null,
                "freeRnsPos": null,
                "locTrueInd": null,
                "cruiseRange": null,
                "smsOriginDateTime": null,
                "interactionId": null,
                "ecallModeIndicator": null
}, {
                "srNumber": "1-1287090731",
                "accountName": "DEVICESIMULATIONDEVICESIMULATION AUDIAUDI",
                "createDate": "2016-10-21 12:43:18 UTC",
                "srStatus": "Closed",
                "source": null,
                "closedDate": null,
                "type": null,
                "resolution": null,
                "description": null,
                "address": null,
                "city": null,
                "state": null,
                "zip": null,
                "county": null,
                "country": null,
                "altitude": null,
                "vehInMovement": null,
                "directionHeading": null,
                "odometerReading": null,
                "latitude": null,
                "longitude": null,
                "locationConfidence": null,
                "location": null,
                "protocolDevId": null,
                "seqNum": null,
                "eCallModeIndicator": null,
                "hmiLang": null,
                "estLocPrec": null,
                "freeRnsPos": null,
                "locTrueInd": null,
                "cruiseRange": null,
                "smsOriginDateTime": null,
                "interactionId": null,
                "ecallModeIndicator": null
}, {
                "srNumber": "1-1287069221",
                "accountName": "DEVICESIMULATIONDEVICESIMULATION AUDIAUDI",
                "createDate": "2016-10-21 10:22:45 UTC",
                "srStatus": "Closed",
                "source": null,
                "closedDate": null,
                "type": null,
                "resolution": null,
                "description": null,
                "address": null,
                "city": null,
                "state": null,
                "zip": null,
                "county": null,
                "country": null,
                "altitude": null,
                "vehInMovement": null,
                "directionHeading": null,
                "odometerReading": null,
                "latitude": null,
                "longitude": null,
                "locationConfidence": null,
                "location": null,
                "protocolDevId": null,
                "seqNum": null,
                "eCallModeIndicator": null,
                "hmiLang": null,
                "estLocPrec": null,
                "freeRnsPos": null,
                "locTrueInd": null,
                "cruiseRange": null,
                "smsOriginDateTime": null,
                "interactionId": null,
                "ecallModeIndicator": null
}, {
                "srNumber": "1-1287068961",
                "accountName": "DEVICESIMULATIONDEVICESIMULATION AUDIAUDI",
                "createDate": "2016-10-21 10:10:40 UTC",
                "srStatus": "Closed",
                "source": null,
                "closedDate": null,
                "type": null,
                "resolution": null,
                "description": null,
                "address": null,
                "city": null,
                "state": null,
                "zip": null,
                "county": null,
                "country": null,
                "altitude": null,
                "vehInMovement": null,
                "directionHeading": null,
                "odometerReading": null,
                "latitude": null,
                "longitude": null,
                "locationConfidence": null,
                "location": null,
                "protocolDevId": null,
                "seqNum": null,
                "eCallModeIndicator": null,
                "hmiLang": null,
                "estLocPrec": null,
                "freeRnsPos": null,
                "locTrueInd": null,
                "cruiseRange": null,
                "smsOriginDateTime": null,
                "interactionId": null,
                "ecallModeIndicator": null
}];


let detailViewData: any ={
                "informationCallDTO": {
                                "srNumber": "1-1287090731",
                                "accountName": null,
                                "createDate": "2016-10-21 12:43:18 UTC",
                                "srStatus": "Closed",
                                "source": "I-Call",
                                "closedDate": null,
                                "type": "I-Call",
                                "resolution": null,
                                "description": null,
                                "address": null,
                                "city": null,
                                "state": null,
                                "zip": null,
                                "county": null,
                                "country": null,
                                "altitude": null,
                                "vehInMovement": null,
                                "directionHeading": null,
                                "odometerReading": null,
                                "latitude": "",
                                "longitude": "",
                                "locationConfidence": null,
                                "location": "loc",
                                "protocolDevId": null,
                                "seqNum": null,
                                "eCallModeIndicator": null,
                                "hmiLang": null,
                                "estLocPrec": null,
                                "freeRnsPos": null,
                                "locTrueInd": null,
                                "cruiseRange": null,
                                "smsOriginDateTime": "2016-10-21 12:43:17 UTC",
                                "interactionId": "INTICALL12345",
                                "ecallModeIndicator": null
                },
                "unitlocDtoList": []
};


  
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [{
          provide: Http, useFactory: (backend: any, options: any) => {
            return new Http(backend, options);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        MockBackend,
        BaseRequestOptions,
        IcallService]
    });
  });

  beforeEach(inject([IcallService, MockBackend], (service: IcallService, mockBackend: MockBackend) => {
    icallService = service;
    backend = mockBackend;
  }));

  it('should be initialized', inject([IcallService], (service: IcallService) => {
    expect(service).toBeTruthy();
  }));


   it('should get listViewdata on invocation of Icall', (done) => {
       console.log(backend, icallService);
    backend.connections.subscribe((connection: MockConnection) => {
      let options = new ResponseOptions({ body: listViewData });

      connection.mockRespond(new Response(options));
    });

    icallService.getIcall().subscribe((response: any) => {
      expect(response).toEqual(listViewData);
      done();
    });
  });


   it ('should return result on invocation of getIcall: empty array', inject([IcallService], (service: IcallService) => {
    spyOn(service, 'getIcall')
          .and.returnValue(Observable.throw({error: 'error'}));
          service.getIcall().subscribe( res => {

          },
          err =>{
              expect(err.error).toBe('error');
          }
          );
  }));



it('should get detailViewData on invocation of getIcallDetails', (done) => {
       console.log(backend, icallService);
    backend.connections.subscribe((connection: MockConnection) => {
      let options = new ResponseOptions({ body: detailViewData });

      connection.mockRespond(new Response(options));
    });

    icallService.getIcallDetails(listViewData[0]).subscribe((response: any) => {
      expect(response).toEqual(detailViewData);
      done();
    });
  });

   it ('should return result on invocation of getIcallDetails: empty array', inject([IcallService], (service: IcallService) => {
    spyOn(service, 'getIcallDetails')
          .and.returnValue(Observable.throw({error: 'error'}));
          service.getIcallDetails({}).subscribe( res => {

          },
          err =>{
              expect(err.error).toBe('error');
          }
          );
  }));


  it('should get inBandLocationIcalldata on invocation of inBandLocationIcall error', (done) => {
      let res = {"error": [
    {
      "status": "422",
      statusText: "some error"
    }
  ]};
    backend.connections.subscribe((connection: MockConnection) => {
      let options = new ResponseOptions({ body:  res});

      connection.mockRespond(new Response(options));
    });

    icallService.inBandLocationIcall(detailViewData['informationCallDTO']).subscribe((response: any) => {
      expect(response).toEqual(res);
      done();
    },
    err =>{
       expect(err).toEqual(res);
      done(); 
    });
  });


  it('should get inBandLocationIcalldata on invocation of inBandLocationIcall', (done) => {
      let res = {responseStatus:'success', responseDescription:''};
    backend.connections.subscribe((connection: MockConnection) => {
      let options = new ResponseOptions({ body:  res});

      connection.mockRespond(new Response(options));
    });

    icallService.inBandLocationIcall(detailViewData['informationCallDTO']).subscribe((response: any) => {
      expect(response).toEqual(res);
      done();
    });
  });

   it ('should return result on invocation of inBandLocationIcall: empty array', inject([IcallService], (service: IcallService) => {
    spyOn(service, 'inBandLocationIcall')
          .and.returnValue(Observable.throw({error: 'error'}));
          service.inBandLocationIcall({srNo: '', interactionId: ''}).subscribe( res => {

          },
          err =>{
              expect(err.error).toBe('error');
          }
          );
  }));




 it('should get closeServiceRequestIcalldata on invocation of closeServiceRequestIcall error', (done) => {
      let res = {responseStatus:'success', responseDescription:''};
    backend.connections.subscribe((connection: MockConnection) => {
      let options = new ResponseOptions({ body:  res});

      connection.mockRespond(new Response(options));
    });

    icallService.closeServiceRequestIcall(detailViewData['informationCallDTO']).subscribe((response: any) => {
      expect(response).toEqual(res);
      done();
    });
  });

   it ('should return result on invocation of closeServiceRequestIcall: empty array', inject([IcallService], (service: IcallService) => {
    spyOn(service, 'closeServiceRequestIcall')
          .and.returnValue(Observable.throw({error: 'error'}));
          service.closeServiceRequestIcall({srNo: ''}).subscribe( res => {

          },
          err =>{
              expect(err.error).toBe('error');
          }
          );
  }));
});
