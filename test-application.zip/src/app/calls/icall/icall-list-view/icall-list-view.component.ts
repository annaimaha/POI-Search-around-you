import { Component, OnInit,Output, EventEmitter } from '@angular/core';
import {Message} from 'primeng/primeng';
import {IcallService} from '../icall.service';
import {myGlobals} from '../../../../constants/globals';
@Component({
  selector: 'icalllistview',
  templateUrl: 'icall-list-view.component.html',
   providers:[IcallService]
})
export class IcallListViewComponent implements OnInit {
	tabName: any;
    public data:any;
    public filterQuery = "";
    public rowsOnPage = 10;
    public sortBy = "alertname";
    public sortOrder = "asc";
    loading:any;
    msgs: Message[] = [];
    growlLife: Number = myGlobals.disAppearTimeMessage;
    errormsgs:any;
    @Output() icallViewEvent: EventEmitter<any> = new EventEmitter();

    constructor(private icallservice:IcallService) {
      this.tabName = "listview";
    }

    ngOnInit() {
      this.getIcalList();
    }
    /*
      Methods to get the icall lists
    */
    getIcalList(){
      this.icallservice.getIcall().subscribe(
        info => {
                if(!(JSON.stringify(info) === JSON.stringify([]))){
                this.data = info;
              }else{
                this.errormsgs = myGlobals.noData;
              }
            },
        error =>{
            this.errormsgs = error;
        }
      );
    }

    /*
      Methods to trigger the emit event for the call details viewItems
      @params items object
    */
    viewIcallItem(items){
       this.loading = true;
      this.icallservice.getIcallDetails(items).subscribe(
				info => {
              this.loading = false;
							if(info['informationCallDTO'] && info['informationCallDTO'] !==null && info['informationCallDTO'] !=""){
                this.icallViewEvent.emit({view:'detailview',item:info['informationCallDTO']});
              }else{
                this.msgs.push({ severity: 'error', summary: '', detail: myGlobals.noData });
              }              
						},
				error =>{
            this.loading = false;
            this.msgs.push({ severity: 'error', summary: '', detail: error });
				}
      );     
    }

    /*
      Methods to trigger the emit event for the call details viewItems
      @params items object
    */

    commonTabs(Tabs) {
      this.tabName = "";
      this.tabName = Tabs;
    }

}
