import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PerfectScrollbarModule } from 'angular2-perfect-scrollbar';
import { By }           from '@angular/platform-browser';
import { PerfectScrollbarConfigInterface } from 'angular2-perfect-scrollbar';
import { DataTableModule } from "angular2-datatable";
import { GrowlModule } from 'primeng/primeng';
import { MockBackend, MockConnection } from '@angular/http/testing';
import {
  Http, HttpModule, XHRBackend, ResponseOptions,
  Response, BaseRequestOptions
} from '@angular/http';

import {IcallService} from '../icall.service';
import {FakeIcallService} from '../../../../services/mock-services/icall.fake-service';
import { IcallListViewComponent } from './icall-list-view.component';
import { LoadingGifDataComponent } from '../../../loading-gif-data/loading-gif-data.component';
import { Injectable } from '@angular/core';
import { Observable }     from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

describe('IcallListViewComponent', () => {
  let component: IcallListViewComponent;
  let fixture: ComponentFixture<IcallListViewComponent>;
  let iCallService: any;
  let serviceSpies: any = {};
  let listViewData: any = [{
                "srNumber": "1-1287103341",
                "accountName": "DEVICESIMULATIONDEVICESIMULATION AUDIAUDI",
                "createDate": "2016-10-21 13:28:49 UTC",
                "srStatus": "Closed",
                "source": null,
                "closedDate": null,
                "type": null,
                "resolution": null,
                "description": null,
                "address": null,
                "city": null,
                "state": null,
                "zip": null,
                "county": null,
                "country": null,
                "altitude": null,
                "vehInMovement": null,
                "directionHeading": null,
                "odometerReading": null,
                "latitude": null,
                "longitude": null,
                "locationConfidence": null,
                "location": null,
                "protocolDevId": null,
                "seqNum": null,
                "eCallModeIndicator": null,
                "hmiLang": null,
                "estLocPrec": null,
                "freeRnsPos": null,
                "locTrueInd": null,
                "cruiseRange": null,
                "smsOriginDateTime": null,
                "interactionId": null,
                "ecallModeIndicator": null
}, {
                "srNumber": "1-1287090731",
                "accountName": "DEVICESIMULATIONDEVICESIMULATION AUDIAUDI",
                "createDate": "2016-10-21 12:43:18 UTC",
                "srStatus": "Closed",
                "source": null,
                "closedDate": null,
                "type": null,
                "resolution": null,
                "description": null,
                "address": null,
                "city": null,
                "state": null,
                "zip": null,
                "county": null,
                "country": null,
                "altitude": null,
                "vehInMovement": null,
                "directionHeading": null,
                "odometerReading": null,
                "latitude": null,
                "longitude": null,
                "locationConfidence": null,
                "location": null,
                "protocolDevId": null,
                "seqNum": null,
                "eCallModeIndicator": null,
                "hmiLang": null,
                "estLocPrec": null,
                "freeRnsPos": null,
                "locTrueInd": null,
                "cruiseRange": null,
                "smsOriginDateTime": null,
                "interactionId": null,
                "ecallModeIndicator": null
}, {
                "srNumber": "1-1287069221",
                "accountName": "DEVICESIMULATIONDEVICESIMULATION AUDIAUDI",
                "createDate": "2016-10-21 10:22:45 UTC",
                "srStatus": "Closed",
                "source": null,
                "closedDate": null,
                "type": null,
                "resolution": null,
                "description": null,
                "address": null,
                "city": null,
                "state": null,
                "zip": null,
                "county": null,
                "country": null,
                "altitude": null,
                "vehInMovement": null,
                "directionHeading": null,
                "odometerReading": null,
                "latitude": null,
                "longitude": null,
                "locationConfidence": null,
                "location": null,
                "protocolDevId": null,
                "seqNum": null,
                "eCallModeIndicator": null,
                "hmiLang": null,
                "estLocPrec": null,
                "freeRnsPos": null,
                "locTrueInd": null,
                "cruiseRange": null,
                "smsOriginDateTime": null,
                "interactionId": null,
                "ecallModeIndicator": null
}, {
                "srNumber": "1-1287068961",
                "accountName": "DEVICESIMULATIONDEVICESIMULATION AUDIAUDI",
                "createDate": "2016-10-21 10:10:40 UTC",
                "srStatus": "Closed",
                "source": null,
                "closedDate": null,
                "type": null,
                "resolution": null,
                "description": null,
                "address": null,
                "city": null,
                "state": null,
                "zip": null,
                "county": null,
                "country": null,
                "altitude": null,
                "vehInMovement": null,
                "directionHeading": null,
                "odometerReading": null,
                "latitude": null,
                "longitude": null,
                "locationConfidence": null,
                "location": null,
                "protocolDevId": null,
                "seqNum": null,
                "eCallModeIndicator": null,
                "hmiLang": null,
                "estLocPrec": null,
                "freeRnsPos": null,
                "locTrueInd": null,
                "cruiseRange": null,
                "smsOriginDateTime": null,
                "interactionId": null,
                "ecallModeIndicator": null
}];


let detailViewData: any ={
                "informationCallDTO": {
                                "srNumber": "1-1287090731",
                                "accountName": null,
                                "createDate": "2016-10-21 12:43:18 UTC",
                                "srStatus": "Closed",
                                "source": "I-Call",
                                "closedDate": null,
                                "type": "I-Call",
                                "resolution": null,
                                "description": null,
                                "address": null,
                                "city": null,
                                "state": null,
                                "zip": null,
                                "county": null,
                                "country": null,
                                "altitude": null,
                                "vehInMovement": null,
                                "directionHeading": null,
                                "odometerReading": null,
                                "latitude": "",
                                "longitude": "",
                                "locationConfidence": null,
                                "location": "loc",
                                "protocolDevId": null,
                                "seqNum": null,
                                "eCallModeIndicator": null,
                                "hmiLang": null,
                                "estLocPrec": null,
                                "freeRnsPos": null,
                                "locTrueInd": null,
                                "cruiseRange": null,
                                "smsOriginDateTime": "2016-10-21 12:43:17 UTC",
                                "interactionId": "INTICALL12345",
                                "ecallModeIndicator": null
                },
                "unitlocDtoList": []
};


  const PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
    suppressScrollX: true
        };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IcallListViewComponent, LoadingGifDataComponent ],
      imports: [PerfectScrollbarModule.forRoot(PERFECT_SCROLLBAR_CONFIG),
      DataTableModule,
      GrowlModule
      ],
      providers: [
          {
          provide: Http, useFactory: (backend: any, options: any) => {
            return new Http(backend, options);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        MockBackend,
        BaseRequestOptions,
        {provide: IcallService, useClass: FakeIcallService}  
      ]
    })
    .overrideComponent(LoadingGifDataComponent, {
            set: {
                selector: 'loading-gif-data',
                template: `<span></span>`
            }
        })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IcallListViewComponent);
    component = fixture.componentInstance;
    iCallService = fixture.debugElement.injector.get(IcallService);
    /*serviceSpies.getIcall = spyOn(IcallService, 'getIcall')
          .and.returnValue(Observable.of([]));*/
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have tabName initialized', () => {
      expect(component.tabName).toBe('listview');
  });

  it('should call getIcalList on Init',() => {
      spyOn(component, 'getIcalList');
      component.ngOnInit();
      expect(component.getIcalList).toHaveBeenCalled();
  });
  it('should call iCallService.getIcall on getIcalList', () => {
    spyOn(iCallService, 'getIcall')
          .and.returnValue(Observable.of([]));
      component.getIcalList();
      fixture.detectChanges();
      expect(iCallService.getIcall).toHaveBeenCalled();
      expect(component.errormsgs).toBe('No Records Found.');
   //   accountNumber=103011633&tcuId=355414050002595&vin=BVWL07AJ2FM263381&userTimeZoneStr=est
  });

  it('should execute if JSON condition on receiving data', () => {
    spyOn(iCallService, 'getIcall')
          .and.returnValue(Observable.of(listViewData));
      fixture.detectChanges();
      expect(component.data.length).not.toBe(0);
    //  expect(iCallService.getIcall).toHaveBeenCalled();
   //   accountNumber=103011633&tcuId=355414050002595&vin=BVWL07AJ2FM263381&userTimeZoneStr=est
  });

  it('should execute error block if error is returned ', () => {
    spyOn(iCallService, 'getIcall')
          .and.returnValue(Observable.throw('error is thrown'));

      fixture.detectChanges();
      expect(component.errormsgs).toBe('error is thrown');
   //   accountNumber=103011633&tcuId=355414050002595&vin=BVWL07AJ2FM263381&userTimeZoneStr=est
  });

  it('shoud call icallService.getIcallDetails with params on viewIcallItem', () => {
    spyOn(iCallService, 'getIcallDetails')
          .and.returnValue(Observable.of({}));
      component.viewIcallItem(listViewData);
      fixture.detectChanges();
      expect(component.loading).toBe(false);
      expect(iCallService.getIcallDetails).toHaveBeenCalled();
      expect(component.msgs).toEqual([{
        severity: 'error', summary: '', detail: "No Records Found."}
      ]);
     // expect(component.errormsgs).toBe('No Records Found.');
  });


   it('shoud call icallService.getIcallDetails with params on viewIcallItem: If informationCallDTO', () => {
      spyOn(iCallService, 'getIcallDetails')
            .and.returnValue(Observable.of(detailViewData));
      spyOn(component.icallViewEvent, 'emit');
      component.viewIcallItem(listViewData);
      fixture.detectChanges();
      expect(component.icallViewEvent.emit).toHaveBeenCalled();
      expect(component.icallViewEvent.emit).toHaveBeenCalledWith({view:'detailview',item:detailViewData['informationCallDTO']});

     // expect(component.errormsgs).toBe('No Records Found.');
  });

  it('should execute error block if error is returned ', () => {
    spyOn(iCallService, 'getIcallDetails')
          .and.returnValue(Observable.throw('error is thrown'));
      component.viewIcallItem(listViewData);
      fixture.detectChanges();
      expect(component.loading).toBe(false);
      expect(component.msgs).toContain({ severity: 'error', summary: '', detail: "error is thrown" });
   //   accountNumber=103011633&tcuId=355414050002595&vin=BVWL07AJ2FM263381&userTimeZoneStr=est
  });

  it('should change tabName on commonTabs click', () => {
    component.commonTabs('newTab');
    fixture.detectChanges();
    expect(component.tabName).toBe('newTab');
  });

  it('should initialize datatable when list data is provided', () => {
      spyOn(iCallService, 'getIcall')
            .and.returnValue(Observable.of([listViewData, listViewData]));
      spyOn(component,'viewIcallItem');
      fixture.detectChanges();
      expect(component.data.length).not.toBe(0);
      let clickElem: any = fixture.debugElement.query(By.css('.callDetailView'));
     // clickElem.dispatchEvent(new Event('click'));
     clickElem.nativeElement.click();
      expect(component.viewIcallItem).toHaveBeenCalled();
  });

  

});
