import { Injectable } from '@angular/core';
import { Observable }     from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import {myGlobals} from '../../../constants/globals';
import { Http, Response,Headers,RequestOptions,URLSearchParams} from '@angular/http';
declare var sessionStorage : any;

@Injectable()
export class IcallService {

  private headers:any;
  constructor(private http:Http){
        this.headers = new Headers();
        this.headers.append('Content-Type', 'application/json');
		this.headers.append('api-key', 'vzt-vtp-locationsvc');
    }

	
	// Icall
	getIcall(){
        return this.http.get(myGlobals.informationCallList+sessionStorage["params"],{ headers: this.headers,withCredentials: true })
            .map(this.extractData)
            .catch(this.handleError);
    }

  // Methods to get the Icall Details View data

	getIcallDetails(postdata:any){
    let params = new URLSearchParams();
    params.set('detailView', "false");
    params.set('srNo', postdata.srNumber);
    params.set('infoCallSrID', postdata.srNumber);
        return this.http.get(myGlobals.informationCallDetail+sessionStorage["params"],{search: params,headers: this.headers,withCredentials: true})
            .map(this.extractData)
            .catch(this.handleError);
    }

    // Methods to get inBandLocationIcall

    inBandLocationIcall(postdata:any){
      let paramsInBand = new URLSearchParams();
      paramsInBand.set('srNo', postdata.srNumber);
      paramsInBand.set('interactionId', postdata.interactionId);

      return this.http.get(myGlobals.inBandLocationIcall+sessionStorage["params"],{search: paramsInBand,headers: this.headers,withCredentials: true})
              .map(this.extractData)
              .catch(this.handleError);
    }

    // Methods to closeServiceRequest Icall

    closeServiceRequestIcall(postdata:any){
      let paramsclose = new URLSearchParams();
      paramsclose.set('srNo', postdata.srNumber);

      return this.http.get(myGlobals.closeServiceRequestIcall+sessionStorage["params"],{search: paramsclose,headers: this.headers,withCredentials: true})
              .map(this.extractData)
              .catch(this.handleError);
    }

    private extractData(res: Response) {
        let body = res.json();
        return body.data?body.data: (body || {});
    }
    private handleError(error: Response | any) {
        // In a real world app, we might use a remote logging infrastructure
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} `;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        errMsg = (error.status == '0') ? myGlobals.badGateWay : errMsg;
        return Observable.throw(errMsg);
    }

}
