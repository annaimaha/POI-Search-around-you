import { Component, OnInit } from '@angular/core';

@Component({

  selector: 'app-information-call',
  templateUrl: './information-call.component.html'
})
export class InformationCallComponent implements OnInit {

  tabName: any;
  viewItems: any;
  constructor() {
    this.tabName = "listview";
  }

  ngOnInit() {

  }

  /*
    Methods to set the params of Call details
  */

  viewIcallDetails(events:any) {
    this.tabName = events.view;
    this.viewItems = events.item;
  }

  /*
    Methods to Enable and disable the views of components
    @params tabs string which tab Should be view
  */

  commonTabs(Tabs:any) {
    this.tabName = "";
    this.tabName = Tabs;
  }
}
