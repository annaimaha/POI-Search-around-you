import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InformationCallComponent } from './information-call.component';
import { DebugElement, NO_ERRORS_SCHEMA }    from '@angular/core';

describe('EmergencyCallComponent', () => {
  let component: InformationCallComponent;
  let fixture: ComponentFixture<InformationCallComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InformationCallComponent ],
      schemas:[NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InformationCallComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should have tabName inittailized', () => {
      fixture.detectChanges();
      expect(component.tabName).toBe('listview');  
  });
  it('should change view items on viewCallDetails', () =>{
      component.viewIcallDetails({view:'detailview',item:{"srNumber": "1-1287090731"}});
      expect(component.tabName).toBe('detailview');
      expect(component.viewItems).toEqual({"srNumber": "1-1287090731"});
  });
  it('should change tabName on commonTabs click', () => {
    component.commonTabs('newTab');
    fixture.detectChanges();
    expect(component.tabName).toBe('newTab');
  });
});
