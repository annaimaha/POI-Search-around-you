// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { RcallDetailsViewComponent } from './rcall-details-view.component';

// describe('RcallDetailsViewComponent', () => {
//   let component: RcallDetailsViewComponent;
//   let fixture: ComponentFixture<RcallDetailsViewComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ RcallDetailsViewComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(RcallDetailsViewComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
