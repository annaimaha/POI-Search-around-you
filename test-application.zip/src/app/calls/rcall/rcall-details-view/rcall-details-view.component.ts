import { Component, OnInit, Input } from '@angular/core';
import { roadsideassitanceCallDTO } from '../../../../model/roadsideassitanceCallDTO';
import { RCallServiceKeyDataDTO } from '../../../../model/rCallServiceKeyData';
import { RcallService } from '../rcall.service';
import { Message } from 'primeng/primeng';
import { myGlobals } from '../../../../constants/globals';
import { MapService } from '../../../../services/map.service';
declare var L: any;
@Component({
  selector: 'rcalldetailsview',
  templateUrl: './rcall-details-view.component.html',
  providers: [RcallService, MapService]
})
export class RcallDetailsViewComponent implements OnInit {

  tabName: any;
  data: any;
  loading: any;
  @Input() viewItems: any;
  msgs: Message[] = [];
  growlLife: Number = myGlobals.disAppearTimeMessage;
  map: any;
  markersLayer: any;
  rCallServiceKeyData = new RCallServiceKeyDataDTO('', '', '');
  greenIcon = new L.Icon({ iconUrl: myGlobals.greenIcon, shadowUrl: myGlobals.shadowIcon, iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], shadowSize: [41, 41] });
  roadsideassistanceCall = new roadsideassitanceCallDTO('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

  constructor(private rcallservice: RcallService, private mapService: MapService) {
    this.tabName = "listview";
  }

  ngOnInit() {
    this.getRcallDetails();
    this.map = L.map('ecallpoi').setView([40.731253, -73.996139], 13);
    // base layer
    this.map.addLayer(new L.TileLayer('https://{s}.tiles.mapbox.com/v4/mapquest.streets/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwcXVlc3QiLCJhIjoiY2Q2N2RlMmNhY2NiZTRkMzlmZjJmZDk0NWU0ZGJlNTMifQ.mPRiEubbajc6a5y9ISgydg'));
    this.markersLayer = new L.LayerGroup();
    this.map.addLayer(this.markersLayer);
  }

  /*
    Method to get the Details of the list views
  */

  getRcallDetails() {
    let info = this.viewItems

    if (info['roadSideAssitanceDTO'] !== "" && info['roadSideAssitanceDTO'] !== null) {
      this.roadsideassistanceCall = info['roadSideAssitanceDTO'];
    }

    if (info['rCallServiceKeyDataDTO'] !== "" && info['rCallServiceKeyDataDTO'] !== null) {
      this.rCallServiceKeyData = info['rCallServiceKeyDataDTO'];
    }


    let latitude = info['roadSideAssitanceDTO']['latitude'];
    let longitude = info['roadSideAssitanceDTO']['longitude'];

    if (latitude !== "" && latitude !== null && longitude !== "" && longitude !== null) {
      let loc = [latitude, longitude];
      let marker = new L.Marker(loc, { icon: this.greenIcon });
      this.markersLayer.addLayer(marker);
      this.map.panTo(loc);
    }

  }

  // Methods  to triger the close service Request
  closeServiceRequestIcall() {
    this.loading = true;
    this.rcallservice.closeServiceRequestRcall(this.roadsideassistanceCall).subscribe(
      info => {
        this.loading = false;
        if (info['responseStatus'] === "success") {
          this.msgs.push({ severity: 'success', summary: '', detail: info['responseDescription'] });
        } else {
          this.msgs.push({ severity: 'error', summary: '', detail: info['responseDescription'] });
        }
      },
      error => {
        this.loading = false;
        this.msgs.push({ severity: 'error', summary: '', detail: error });
      }
    );
  }

  // Methods  to triger the inband Location call
  inBandLocationIcall() {
    this.loading = true;
    this.rcallservice.inBandLocationRcall(this.roadsideassistanceCall).subscribe(
      info => {
        this.loading = false;
        if (info['responseStatus'] === "success") {
          this.msgs.push({ severity: 'success', summary: '', detail: info['responseDescription'] });
        } else {
          this.msgs.push({ severity: 'error', summary: '', detail: info['responseDescription'] });
        }
      },
      error => {
        this.loading = false;
        this.msgs.push({ severity: 'error', summary: '', detail: error });
      }
    );
  }

  /*
    Methods to Enable and disable the views of components
    @params tabs string which tab Should be view
  */

  commonTabs(Tabs: any) {
    this.tabName = "";
    this.tabName = Tabs;
  }

}
