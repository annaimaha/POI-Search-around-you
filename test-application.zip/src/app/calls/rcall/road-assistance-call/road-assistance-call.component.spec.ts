// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { RoadAssistanceCallComponent } from './road-assistance-call.component';

// describe('RoadAssistanceCallComponent', () => {
//   let component: RoadAssistanceCallComponent;
//   let fixture: ComponentFixture<RoadAssistanceCallComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ RoadAssistanceCallComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(RoadAssistanceCallComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
