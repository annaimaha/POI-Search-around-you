import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rcall',
  templateUrl: './road-assistance-call.component.html'
})
export class RoadAssistanceCallComponent implements OnInit {
	tabName: any;
    viewItems:any;
	
    constructor() {
      this.tabName = "listview";
     }

    ngOnInit() {

    }

    /*
      Methods to set the params of Call details
    */

    viewRcallDetails(events){
      this.tabName = events.view;
      this.viewItems    = events.item;
    }

    /*
      Methods to Enable and disable the views of components
      @params tabs string which tab Should be view
    */
    
    commonTabs(Tabs) {
      this.tabName = "";
      this.tabName = Tabs;
    }
}
