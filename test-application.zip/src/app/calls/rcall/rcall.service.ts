import { Injectable } from '@angular/core';
import { Observable }     from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { Http, Response,Headers,RequestOptions,URLSearchParams} from '@angular/http';
import {myGlobals} from '../../../constants/globals';
declare var sessionStorage : any;
@Injectable()
export class RcallService {
  
  private headers:any;
  
  constructor(private http:Http){
        this.headers = new Headers();
        this.headers.append('Content-Type', 'application/json');
		    this.headers.append('api-key', 'vzt-vtp-locationsvc');
    }
	// Icall
	getRcall(){
        return this.http.get(myGlobals.roadSideAssistanceList+sessionStorage["params"],{ headers: this.headers,withCredentials: true })
            .map(this.extractData)
            .catch(this.handleError);
    }

	getRcallDetails(postdata:any){
        let params = new URLSearchParams();
        params.set('detailView', "false");
        params.set('srNo', postdata.srNumber);
        params.set('roadSideAssistSrID', postdata.srNumber);

        return this.http.get(myGlobals.roadSideAssistance+sessionStorage["params"],{search: params,headers: this.headers,withCredentials: true })
            .map(this.extractData)
            .catch(this.handleError);
    }

    // Methods to get inBandLocationIcall

    inBandLocationRcall(postdata:any){
      let paramsInBand = new URLSearchParams();
      paramsInBand.set('srNo', postdata.srNumber);
      paramsInBand.set('interactionId', postdata.interactionId);

      return this.http.get(myGlobals.inBandLocationRcall+sessionStorage["params"],{search: paramsInBand,headers: this.headers,withCredentials: true})
              .map(this.extractData)
              .catch(this.handleError);
    }

    // Methods to closeServiceRequest Rcall

    closeServiceRequestRcall(postdata:any){
      let paramsclose = new URLSearchParams();
      paramsclose.set('srNo', postdata.srNumber);

      return this.http.get(myGlobals.closeServiceRequestRcall+sessionStorage["params"],{search: paramsclose,headers: this.headers,withCredentials: true})
              .map(this.extractData)
              .catch(this.handleError);
    }


    private extractData(res: Response) {
        let body = res.json();
        return body.data?body.data: (body || {});
    }
    private handleError(error: Response | any) {
        // In a real world app, we might use a remote logging infrastructure
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} `;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        errMsg = (error.status == '0') ? myGlobals.badGateWay : errMsg;
        return Observable.throw(errMsg);
    }

}
