// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { RcallListViewComponent } from './rcall-list-view.component';

// describe('RcallListViewComponent', () => {
//   let component: RcallListViewComponent;
//   let fixture: ComponentFixture<RcallListViewComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ RcallListViewComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(RcallListViewComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
