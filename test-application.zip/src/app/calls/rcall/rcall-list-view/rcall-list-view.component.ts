import { Component, OnInit,Output, EventEmitter } from '@angular/core';
import {RcallService} from '../rcall.service';
import {myGlobals} from '../../../../constants/globals';
import {Message} from 'primeng/primeng';
@Component({
  selector: 'rcalllistview',
  templateUrl: './rcall-list-view.component.html',  
  providers:[RcallService]
})
export class RcallListViewComponent implements OnInit {

  tabName: any;
    public data:any;
    public filterQuery = "";
    public rowsOnPage = myGlobals.rowsOnPage;
    public sortBy = "accountName";
    public sortOrder = myGlobals.sortOrder;
    msgs: Message[] = [];
    growlLife: Number = myGlobals.disAppearTimeMessage;
    loading:any;
    errormsgs:any;
    @Output() rcallViewEvent: EventEmitter<any> = new EventEmitter();

    constructor(private rcallservice:RcallService) {
      this.tabName = "listview";
    }

    ngOnInit() {
      this.getRcalList();
    }

    /*
      Methods to get the icall lists
    */
    getRcalList(){
      this.rcallservice.getRcall().subscribe(
        info => {
          if(!(JSON.stringify(info) === JSON.stringify([]))){
                this.data = info;
              }else{
                this.errormsgs = myGlobals.noData;
              }              
            },
        error =>{
            this.errormsgs = error;
        }
      );
    }

    /*
      Methods to trigger the emit event for the call details viewItems
      @params items object
    */
    viewRcallItem(items) {
      this.loading = true;
      this.rcallservice.getRcallDetails(items).subscribe(
        info => {
          this.loading = false;
          //this.roadsideassistanceCall = info['roadSideAssitanceDTO'];
          //this.rCallServiceKeyData    = info['rCallServiceKeyDataDTO'];
          if (info['roadSideAssitanceDTO'] !== "" && info['roadSideAssitanceDTO'] !== null) {
            this.rcallViewEvent.emit({ view: 'detailview', item: info });
          }else{
            this.msgs.push({ severity: 'error', summary: '', detail: myGlobals.noData });  
          }
        },
        error => {
          this.loading = false;
          this.msgs.push({ severity: 'error', summary: '', detail: error });
        }
      );
    }


    /*
      Methods to trigger the emit event for the call details viewItems
      @params items object
    */
    commonTabs(Tabs) {
      this.tabName = "";
      this.tabName = Tabs;
    }
}
