import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { mainroutes } from './main.routes'
import { NotFoundComponent } from './not-found/not-found.component';
const routes: Routes = [
  {
    path: '',
    redirectTo: '/login',
    pathMatch: 'full'
  }, {
    path: 'login',
    component: LoginComponent
  },
  ...mainroutes,
  {
    path: '**', redirectTo: '404', pathMatch: 'full'
  }, {
    path: '404', component: NotFoundComponent
  }
];

export const routing = RouterModule.forRoot(routes);
