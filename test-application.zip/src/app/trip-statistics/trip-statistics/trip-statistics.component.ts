import {Component, OnDestroy, Input, style, state, animate, transition, trigger } from '@angular/core';
import {TabViewModule} from 'primeng/primeng';

@Component({
  selector: 'trip-statistics',
  templateUrl: './trip-statistics.component.html',
   animations: [
        trigger('flyInOut', [
            state('in', style({ transform: 'translateX(0)' })),
            transition('void => *', [
                style({ transform: 'translateX(-100%)' }),//
                animate(200)
            ]),
            transition('* => void', [
                animate(50, style({ transform: 'translateX(100%)' }))
            ])
        ]),
        trigger('swipeUpDown', [
            state('in', style({ transform: 'translateY(0)' })),
            transition('void=> *', [
                style({ transform: 'translateY(-100%)' }),
                animate(300)
            ]),
            transition('* => void', [
                animate(0, style({ transform: 'translateX(100%)' }))
            ])
        ])
    ]
})
export class TripStatisticsComponent {

    information: any;
    geofence: any;
    isAccountCollapsed: any;
    tabName: any;
    constructor() {
        this.tabName = "lastTrip";
        this.isAccountCollapsed = false;
    }

    tabs(geofence) {
        this.tabName = "";
        this.tabName = geofence;
    }
    expand() {
        this.isAccountCollapsed = !this.isAccountCollapsed;
    }
    collapsed(isCollapsed) {
        this.isAccountCollapsed = isCollapsed;
    }
}
