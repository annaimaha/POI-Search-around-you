// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { TripStatisticsComponent } from './trip-statistics.component';

// describe('TripStatisticsComponent', () => {
//   let component: TripStatisticsComponent;
//   let fixture: ComponentFixture<TripStatisticsComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ TripStatisticsComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(TripStatisticsComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
