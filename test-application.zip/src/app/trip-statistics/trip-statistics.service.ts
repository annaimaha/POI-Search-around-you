import { Injectable } from '@angular/core';
import { Http, Response,Headers,RequestOptions,URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs';
import {myGlobals} from '../../constants/globals';
declare var sessionStorage : any;

@Injectable()
export class TripStatisticsService {

headers:any;
options:any;
  constructor(private http:Http) {
	  this.headers = new Headers();
      this.headers.append('Content-Type', 'application/json');
      this.headers.append('Accept', 'application/json');
      this.options = {headers :this.headers,withCredentials: true};
  }

  getLastTripReport(): Observable<any> {
        return this.http.get(myGlobals.lastTripReport+sessionStorage["params"],this.options)
            .map(this.extractData)
            .catch(this.handleError);
    }
    getUserResetReport(): Observable<any> {
          return this.http.get(myGlobals.userResetReport+sessionStorage["params"],this.options)
              .map(this.extractData)
              .catch(this.handleError);
      }

  private extractData(res: Response) {
        let body = res.json();
        return body.data?body.data: (body || {});
    }

 private handleError(error: Response | any) {
        // In a real world app, we might use a remote logging infrastructure
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        
        errMsg = (error.status == '0') ? myGlobals.badGateWay : errMsg;
        
        return Observable.throw(errMsg);
    }

}
