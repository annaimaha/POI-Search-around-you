// import { TestBed, inject } from '@angular/core/testing';

// import { TripStatisticsService } from './trip-statistics.service';

// describe('TripStatisticsService', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       providers: [TripStatisticsService]
//     });
//   });

//   it('should ...', inject([TripStatisticsService], (service: TripStatisticsService) => {
//     expect(service).toBeTruthy();
//   }));
// });
