// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { UserResetReportComponent } from './user-reset-report.component';

// describe('UserResetReportComponent', () => {
//   let component: UserResetReportComponent;
//   let fixture: ComponentFixture<UserResetReportComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ UserResetReportComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(UserResetReportComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
