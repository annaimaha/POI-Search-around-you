import { Component, OnInit } from '@angular/core';
import {Http} from "@angular/http";
import {Message} from 'primeng/primeng';
import {TripStatisticsService} from '../trip-statistics.service';
import {myGlobals} from '../../../constants/globals';
@Component({
  selector: 'last-trip-report',
  templateUrl: './last-trip-report.component.html',
  providers: [TripStatisticsService]
})
export class LastTripReportComponent implements OnInit {
information: any;
    public data:any;
    public filterQuery = "";
    public rowsOnPage = myGlobals.rowsOnPage;
    public sortOrder = myGlobals.sortOrder;
    public sortBy = "";
    msgs: Message[] = [];
    errormsgs:any;
    constructor(private http: Http,private tripStatService:TripStatisticsService) {
        this.msgs.push({ severity: 'info', summary: '', detail: 'Existing Speed Alert Violations are listed below. Select the Location link to view the location of the alert on a map view.' });
    }

    ngOnInit(): void {
        this.tripStatService.getLastTripReport()
        	this.tripStatService.getLastTripReport().subscribe(
             info => {  
                 if(!(JSON.stringify(info) === JSON.stringify([]))){
                        this.data = info;
                    }else{
                    this.errormsgs = myGlobals.noData;
                    }
              }
         );
    }

    public toInt(num: string) {
        return +num;
    }

    public sortByWordLength = (a: any) => {
        return a.city.length;
    }

    removeAll() {
        this.data = '';
    }
}
