// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { LastTripReportComponent } from './last-trip-report.component';

// describe('LastTripReportComponent', () => {
//   let component: LastTripReportComponent;
//   let fixture: ComponentFixture<LastTripReportComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ LastTripReportComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(LastTripReportComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
