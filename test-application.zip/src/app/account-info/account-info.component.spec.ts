import { ComponentFixture, inject, TestBed, async, fakeAsync, tick } from '@angular/core/testing';

import { AccountInfoComponent } from './account-info.component';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateService, TranslationChangeEvent } from '@ngx-translate/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {TooltipModule} from 'primeng/primeng';
import { AccountService } from './account.service';
import {Http, HttpModule,  ResponseOptions, XHRBackend} from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { Observable } from 'rxjs/Observable';
import { MockBackend } from '@angular/http/testing';
import { Component, OnInit, Input, style, state, animate, transition, trigger, EventEmitter, Output } from '@angular/core';
 

@Component({
    selector: 'inline-editor',
    template: ''
})
export class FakeInlineEditorComponent {
    accountInfo:any;
        constructor(){
            this.accountInfo = {
            userDTO:{}
        }
        }
}

describe('AccountInfoComponent', () => {
  function findElement(fixture: ComponentFixture<AccountInfoComponent>, selector: string): any {
    return fixture.debugElement.query(By.css(selector)).nativeElement;
  }

    let comp: AccountInfoComponent;
  let fixture: ComponentFixture<AccountInfoComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), FormsModule, TooltipModule, HttpModule, BrowserModule],
      declarations: [ AccountInfoComponent, FakeInlineEditorComponent],
      providers: [TranslateService, AccountService,
              { provide: XHRBackend, useClass: MockBackend }],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountInfoComponent);
    comp = fixture.componentInstance;
  });

    it('true is true', () => {
    expect(true).toEqual(true);
  });

  it('can instantiate it', () => {
    expect(comp).not.toBeNull();
  });

    it('Account Info title should be empty initially until manually call `detectChanges', () => {
    de = fixture.debugElement.query(By.css('.accountInfo-title'));
    el = de.nativeElement;

    expect(el.textContent).toBe('');
  });

  it('Account Info title after initialization', () => {

    de = fixture.debugElement.query(By.css('.accountInfo-title'));
    el = de.nativeElement;

    fixture.detectChanges();
    expect(el.textContent).toContain('ACCOUNTINFO.ACCOUNTHEADER');
  });

      it('should call editButton', () => {
          comp.disabled = true;
          fixture.detectChanges();
          expect(comp.editButton()).toBeDefined;
  });

        it('should call save subscribe success', async(() => {

     let accountService = fixture.debugElement.injector.get(AccountService);
     let body = {statusCode:'200', status:'success'}
     let event = {obj:'value'};
    spyOn(accountService, 'updateAccountInfo').and.returnValue(Observable.of(body));
    fixture.detectChanges();
    expect(comp.save(event)).toBeDefined;
    expect(accountService.updateAccountInfo).toHaveBeenCalled();
    expect(comp.data).toEqual(body);
  }));
        it('should call save subscribe fail', async(() => {

     let accountService = fixture.debugElement.injector.get(AccountService);
     let event = {obj:'value'};
    spyOn(accountService, 'updateAccountInfo').and.returnValue(Observable.throw('error'));
    fixture.detectChanges();
    expect(comp.save(event)).toBeDefined;
    expect(accountService.updateAccountInfo).toHaveBeenCalled();
    expect(comp.errorMessage).toBe('error');
  }));

    it('should call cancel', () => {
          comp.disabled = true;
          fixture.detectChanges();
          expect(comp.cancel()).toBeDefined;
  });
});