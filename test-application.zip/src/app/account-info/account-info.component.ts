import { Component, OnInit,Input, ViewChildren} from '@angular/core';
import {URLSearchParams} from '@angular/http';
import { AccountService } from './account.service';

@Component({
  selector: 'accountInfo',
  templateUrl: 'account-info.component.html',
  styleUrls: ['account-info.component.css']
})
export class AccountInfoComponent  {
	
       data:any;
    errorMessage:any;
	@Input() accountInfo:any = {userDTO:{}};
    disabled: boolean = true;
    updateAcctInfo = {};
    
    @ViewChildren('phoneEdit') phoneEdits: any;
    @ViewChildren('inPlacePhone') phoneNumber: any;
    @ViewChildren('inPlaceMail') mail: any;
    constructor(private accountService: AccountService) {
     }
    
    editButton() {
        this.disabled = !this.disabled;
    }
	
    save(event:any) {
        this.disabled = true;
        this.updateAcctInfo = {
            emailAddress: this.accountInfo.userDTO.email,
            phoneNumber: this.accountInfo.userDTO.phoneNumber,
            acctNo: this.accountInfo.accountNumber,
            tcuId: this.accountInfo.tcuIds,
            vin: this.accountInfo.vin
        }
        let urlSearchParams = new URLSearchParams();
        for (let key in this.updateAcctInfo) {
            urlSearchParams.append(key, this.updateAcctInfo[key]);
        }
        
        let body = urlSearchParams.toString();
        
        this.accountService.updateAccountInfo(body).subscribe(
            info => {
                this.data = info;
            },error=>{

                this.errorMessage = error;
            }
        );
    }

    cancel() {
        this.disabled = true;
    }
}