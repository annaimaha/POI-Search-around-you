import { TestBed, async, inject, tick } from '@angular/core/testing'; //, addProviders 
import {
  HttpModule,
  Http,
  Response,
  ResponseOptions,
  XHRBackend,
  ResponseType
} from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { AccountService } from './account.service';
//import { serviceUrls } from '../../../environments/environment'
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';
import { myGlobals } from '../../constants/globals';
import 'rxjs/add/observable/throw';


describe('AccountService', () => {
  let accountNumber: any;
  let postData: string;
  // let ownerTransferObj:OwnerTransfer;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpModule],
      providers: [
        AccountService,
        { provide: XHRBackend, useClass: MockBackend },
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    accountNumber = '123456';
    postData = 'acountinfo:123456';
  });

    function cast<T>(obj, cl): T {
        obj.__proto__ = cl.prototype;
        return obj;
    }


  describe('getAccountInfo()', () => {

    it('should return an Observable<any>',
      inject([AccountService, XHRBackend], (AccountService, mockBackend) => {

        const mockResponse = {
          Status: '200',
          StatusDesc: 'success'
        } //"Status:'200', StatusDesc:'success'";

        mockBackend.connections.subscribe((connection) => {
          connection.mockRespond(new Response(new ResponseOptions({
            body: JSON.stringify(mockResponse)
          })));
        });

        AccountService.getAccountInfo(accountNumber).subscribe((response) => {
          console.log("response >> >>", response);
          expect(Object.keys(response).length).toBe(2);
          expect(response.Status).toEqual('200');
          expect(response.StatusDesc).toEqual('success');
        });

      }));

  });


  it('should log an error to the console on error', inject([AccountService, XHRBackend], (AccountService, mockBackend) => {

    mockBackend.connections.subscribe(
      (connection) => {
        connection.mockError(new Error('error thrown'));
      });

    AccountService.getAccountInfo(accountNumber).subscribe((error) => { },
      error => {
        spyOn(console, 'error');
        console.error(error);
        expect(console.error).toHaveBeenCalled();
        expect(console.error).toHaveBeenCalledWith(error);
      });
  }));

  describe('updateAccountInfo()', () => {

    it('should return an Observable<any>',
      inject([AccountService, XHRBackend], (AccountService, mockBackend) => {

        const mockResponse = {
          Status: '200',
          StatusDesc: 'success'
        } //"Status:'200', StatusDesc:'success'";

        mockBackend.connections.subscribe((connection) => {
          connection.mockRespond(new Response(new ResponseOptions({
            body: JSON.stringify(mockResponse)
          })));
        });

        AccountService.updateAccountInfo(postData).subscribe((response) => {
          console.log("response >> >>", response);
          expect(Object.keys(response).length).toBe(2);
          expect(response.Status).toEqual('200');
          expect(response.StatusDesc).toEqual('success');
        });
      }));
  });


  it('should log an error to the console on error', inject([AccountService, XHRBackend], (AccountService, mockBackend) => {

    mockBackend.connections.subscribe(
      (connection) => {
        connection.mockError(new Error('error thrown'));
      });

    AccountService.updateAccountInfo(postData).subscribe((error) => { },
      error => {
        spyOn(console, 'error');
        console.error(error);
        expect(console.error).toHaveBeenCalled();
        expect(console.error).toHaveBeenCalledWith(error);

      })
      //.catch(AccountService.handleError);
  }));

  it('should call handleError', inject([AccountService, XHRBackend], (AccountService, mockBackend) => {
    let error: Response = <Response>{
      type: ResponseType.Error, status: 404, statusText: 'some error', ok: true, url: 'http://abc.com',
      bytesLoaded: 123456, totalBytes: 12345678}
    let responseOpts = new ResponseOptions(error)
    cast<Response>(responseOpts, Response);       
      expect(AccountService.handleError(responseOpts)).toBeDefined();
  }));



});
