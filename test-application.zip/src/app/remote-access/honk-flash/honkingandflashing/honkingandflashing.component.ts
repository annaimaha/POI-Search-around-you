import { Component } from '@angular/core';
import {SliderModule,Message,SelectItem} from 'primeng/primeng';
import{Honkflash} from '../../../../model/HonkflashDTO';
import {HonkingflashService} from '../honkingflash.service';
import {myGlobals} from '../../../../constants/globals';

@Component({
  selector: 'honkingandflash',
  templateUrl: './honkingandflashing.component.html',
  providers:[HonkingflashService],
})
export class HonkingandflashingComponent  {

   honkmsgs: Message[] = [];
    flashmsgs: Message[] = [];
    msgs: Message[] = [];
    growlLife:Number = myGlobals.disAppearTimeMessage;
    tabName:any;
    loading:any;
    loadingRequring:any;
    val1: number;
    valuesofhonkflash = [{label:'Honk and Flash', value:'honkAndFlash'},{label:'Flash Only', value:'flashOnly'}];
    honkflash = new Honkflash(5,this.valuesofhonkflash[0]['value'],'');
    charging: SelectItem[];
    batterycharging: string;
    callHonkandFlash:any;    
    counter:any;
    honkflashStatus:any;
    emailId:any;
    constructor(private honkingFlash:HonkingflashService) {
      this.tabName = "honkflash";      
      this.counter = 0;
       if (sessionStorage["accountInfo"]) {      
        this.emailId = JSON.parse(sessionStorage["accountInfo"]);    
      }

    }

    commonTabs(tabs){
      this.tabName	= "";
      this.tabName	= tabs;
    }

    submitHandFlash(){
      this.loading=true;
      this.honkingFlash.honkingAndFlashingRequest(this.honkflash).subscribe(
             info => {
                this.loading = false;
                this.honkflashStatus = info;                
                if(this.honkflashStatus['statusText'] ==null || this.honkflashStatus['statusText'] == ""){                  
                  this.msgs.push({ severity: 'success', summary: '', detail: myGlobals.Inprogress });
                  this.loadingRequring = true;
                  this.callHonkandFlash = setInterval(() => this.callHonkandFlashWindowFromDb(info['transactionId']), myGlobals.recallApis);    
                }else{
                  this.msgs.push({ severity: 'success', summary: '', detail: info['statusText'] });
                }                                                

             },error=>{
                this.loading = false;
                this.msgs.push({ severity: 'error', summary: '', detail: error.err });
             }
         );
    }

    /**
     * Methods to call db for every 15 secs if data is empty on submitHandFlash
     * 
     */
    callHonkandFlashWindowFromDb(transitionId){       
      transitionId = "&transitionId="+transitionId
      this.honkingFlash.honkFlashDb(transitionId).subscribe(
        info => {                              
          this.honkflashStatus = info;
          if(this.honkflashStatus['statusText'] !==null && this.honkflashStatus['statusText'] !== ""){
            
            this.honkmsgs  = [{ severity: 'info', summary: 'Honk Status :', detail: this.honkflashStatus['honkState'] }];
            this.flashmsgs =[{ severity: 'info', summary: 'Flash Status :', detail: this.honkflashStatus['flashState'] }];            
            clearInterval(this.callHonkandFlash);
          }
        },
        error => {
          this.loadingRequring = false;          
          this.msgs.push({ severity: 'error', summary: '', detail: error.err });
        }
      );    
  }

  /**
   * Methods to cancel
   */
  cancelHonandFlash(){    
    let email = "emailId="+this.emailId;
      this.honkingFlash.honkFlashCancel(email).subscribe(
             info => {                
                this.msgs.push({ severity: 'success', summary: '', detail: myGlobals.requestSent });
                clearInterval(this.callHonkandFlash);                
                this.loadingRequring = false;                                                      
             },error=>{                
                this.msgs.push({ severity: 'error', summary: '', detail: error.err });
             }
         );
  }


}
