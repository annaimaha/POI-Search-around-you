// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { HonkingandflashingComponent } from './honkingandflashing.component';

// describe('HonkingandflashingComponent', () => {
//   let component: HonkingandflashingComponent;
//   let fixture: ComponentFixture<HonkingandflashingComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ HonkingandflashingComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(HonkingandflashingComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
