// import { TestBed, inject } from '@angular/core/testing';

// import { HonkingflashService } from './honkingflash.service';

// describe('HonkingflashService', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       providers: [HonkingflashService]
//     });
//   });

//   it('should ...', inject([HonkingflashService], (service: HonkingflashService) => {
//     expect(service).toBeTruthy();
//   }));
// });
