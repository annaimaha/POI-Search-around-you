// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { HonkflashhistoryComponent } from './honkflashhistory.component';

// describe('HonkflashhistoryComponent', () => {
//   let component: HonkflashhistoryComponent;
//   let fixture: ComponentFixture<HonkflashhistoryComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ HonkflashhistoryComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(HonkflashhistoryComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
