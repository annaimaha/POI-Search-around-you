import { Component, OnInit } from '@angular/core';
import {Message,DialogModule} from 'primeng/primeng';
import {HonkingflashService} from '../honkingflash.service';
import {myGlobals} from '../../../../constants/globals';

@Component({
  selector: 'honkflashhistory',
  templateUrl: './honkflashhistory.component.html',
  providers:[HonkingflashService]
})
export class HonkflashhistoryComponent implements OnInit {

  tabName:any;
  msgs: Message[] = [];
  info: Message[] = [];
  growlLife:Number = myGlobals.disAppearTimeMessage;
  public data:any;
  public filterQuery = "";
  public rowsOnPage = myGlobals.rowsOnPage;
  public sortBy = "eventName";
  public sortOrder = myGlobals.sortOrder;
  errormsgs:any;
  loading:any;
  loadingData:any;
  multiDelete = {
      checked : false
  };
  ids = {};
  constructor(private honkingFlash:HonkingflashService) {
    this.tabName = "honkflash";
    this.info.push({ severity: 'info', summary: '', detail: 'Below are your existing violations.To view the location of the alert on a map view,select the location link shown below.' });
  }

  ngOnInit(): void {
    this.honkingAndflashHistory();
  }

  honkingAndflashHistory(){
    this.loadingData = true;
    this.honkingFlash.honkingAndflashHistory().subscribe(
      info => {            
          this.loadingData = false;
            if(!(JSON.stringify(info) === JSON.stringify([]))){
              this.data = info;
            }else{
              this.errormsgs = myGlobals.noData;
            }
          },
      error =>{
          this.errormsgs = error;
          this.loadingData = false;
      }
     );
  }
  commonTabs(tabs){
    this.tabName	= "";
    this.tabName	= tabs;
  }

  selectAllDeselect(result){
    this.multiDelete.checked = result;
  }

  selectedItem(events,items,value){
      if(events){
        this.ids[value] = items.transactionId;
      }else{
        if(this.ids[value]){
          delete this.ids[value];
        }
      }
  }

  remove(value : any) {
  var transactionIds = [];
  for(let i in this.ids){
    transactionIds.push(this.ids[i])
  }

  this.loading = true;
  if(value !=="" && value !==null){
      this.honkingFlash.deletehonkandflashhistory(value.transactionId,'').subscribe(
                info => {
                  this.manageResponse(info);
                },error=>{
                  this.msgs.push({ severity: 'error', summary: '', detail: error });
                  this.loading = false;
                }
             );
    }else{
      this.honkingFlash.deletehonkandflashhistory(transactionIds,'multi').subscribe(
                 info => {
                   this.manageResponse(info);
                 },error=>{
                   this.msgs.push({ severity: 'error', summary: '', detail: error });
                   this.loading = false;
                 }
             );
    }
  }

  manageResponse(info){
    if(info['responseStatus'] ==='success'){
        this.honkingAndflashHistory();
        this.msgs.push({ severity: 'success', summary: '', detail: myGlobals.deleteRecord });
        this.loading = false;
    }else{
        this.msgs.push({ severity: 'error', summary: '', detail: info['responseDescription'] });
        this.loading = false;
    }

  }

}
