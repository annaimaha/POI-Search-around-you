// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { DoorstatusComponent } from './doorstatus.component';

// describe('DoorstatusComponent', () => {
//   let component: DoorstatusComponent;
//   let fixture: ComponentFixture<DoorstatusComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ DoorstatusComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(DoorstatusComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
