import { Component, OnInit } from '@angular/core';
import {RdluService} from '../rdlu.service';
import { myGlobals } from '../../../../constants/globals';
import {RdluDTO} from  '../../../../model/RdluDTO.model';
import {Message} from 'primeng/primeng';

@Component({
  selector: 'door-status',
  templateUrl: './doorstatus.component.html',
  styleUrls: ['./doorstatus.component.css'],
  providers: [RdluService]
})
export class DoorstatusComponent  {

  information: any;
  doorlockunlock: any;
  errormsgs: any;
  loading:any;
  callDoorLockDp:any;
  counter:number;
  msgs: Message[] = [];
  growlLife:Number = myGlobals.disAppearTimeMessage;
  rdlustatus = new RdluDTO('','locked','unlocked','locked','unlocked','unlocked','unlocked','unlocked','unlocked','unlocked','unlocked','unlocked','unlocked','unlocked','');
  constructor(private rdluService: RdluService) {
    this.counter = 0;
  }
  ngAfterViewInit() {

  }
  ngOnInit(){
    this.doorLockUnlock("");
  }

  doorAndWindow() {
    this.loading = true;
    this.rdluService.getDoorStatusService().subscribe(
      info => {
        this.loading = false;        
        if(this.rdlustatus['statusText'] ==null || this.rdlustatus['statusText'] == ""){          
            this.msgs.push({ severity: 'success', summary: '', detail: myGlobals.Inprogress });
            this.callDoorLockDp = setInterval(() => this.callDoorWindowFromDb(), myGlobals.recallApis);
        }else{
          clearInterval(this.callDoorLockDp);
        }
        this.msgs.push({ severity: 'success', summary: '', detail: myGlobals.requestSent });
      },
      error => {
        this.loading = false;
        this.msgs.push({ severity: 'error', summary: '', detail: error });
      }
    );
  }

  
  callDoorWindowFromDb(){
    if(this.counter < 8){
       this.loading = true;
      this.rdluService.rdluDoorWindowStatusDb().subscribe(
        info => {                    
          this.rdlustatus = info[0];
          if(this.rdlustatus['statusText'] !==null && this.rdlustatus['statusText'] !== ""){
            clearInterval(this.callDoorLockDp);
          }
        },
        error => {
          this.loading = false;          
        }
      );
      this.counter++;
    }else{
      clearInterval(this.callDoorLockDp);
    }
    
  }


  doorLockUnlock(options:any) {
    this.loading = true;
    this.rdluService.getDoorLockUnlock(options).subscribe(
      info => {
        this.loading = false;
        this.msgs.push({ severity: 'success', summary: '', detail: myGlobals.requestSent });
      },
      error => {
        this.loading = false;
        this.msgs.push({ severity: 'error', summary: '', detail: error });
      }
    );
  }

  switchWindow(objkey:any){
    if(this.rdlustatus[objkey]){
      this.rdlustatus[objkey] = 'unlocked';
    }else{
      this.rdlustatus[objkey] = true;
    }
  }

}
