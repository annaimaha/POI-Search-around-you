// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { DoorlockunlockComponent } from './doorlockunlock.component';

// describe('DoorlockunlockComponent', () => {
//   let component: DoorlockunlockComponent;
//   let fixture: ComponentFixture<DoorlockunlockComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ DoorlockunlockComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(DoorlockunlockComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
