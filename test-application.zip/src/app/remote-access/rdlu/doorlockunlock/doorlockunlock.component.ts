import { Component } from '@angular/core';
@Component({
  selector: 'doorlockunlock',
  templateUrl: './doorlockunlock.component.html'
})
export class DoorlockunlockComponent {

 information: any;
    doorlockunlock: any;
    errormsgs: any;
    tabName: any;
    constructor() {
        this.tabName = "doorlockunlock";
    }


    commonTabs(vtpTabs) {
        this.tabName = "";
        this.tabName = vtpTabs;
    }

}
