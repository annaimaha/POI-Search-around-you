// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { DoorlockunlockHistoryComponent } from './doorlockunlock-history.component';

// describe('DoorlockunlockHistoryComponent', () => {
//   let component: DoorlockunlockHistoryComponent;
//   let fixture: ComponentFixture<DoorlockunlockHistoryComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ DoorlockunlockHistoryComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(DoorlockunlockHistoryComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
