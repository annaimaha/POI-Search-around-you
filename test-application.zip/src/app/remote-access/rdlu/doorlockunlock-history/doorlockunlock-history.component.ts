import { Component, OnInit } from '@angular/core';
import {RdluService} from '../rdlu.service';
import { myGlobals } from '../../../../constants/globals';
@Component({
  selector: 'doorlockunlockHistory',
  templateUrl: './doorlockunlock-history.component.html',
  providers:[RdluService]
})
export class DoorlockunlockHistoryComponent implements OnInit {

  information: any;
	  public data:any;
    public filterQuery = "";
    public rowsOnPage = myGlobals.rowsOnPage;
    public sortBy = "eventname";
    public sortOrder = myGlobals.sortOrder;
	errormsgs:any;
    constructor(private rdluService:RdluService) {

	  }

    ngOnInit() {
			this.rdluService.getRdluHistory().subscribe(
				info => {
					if(!(JSON.stringify(info) === JSON.stringify([]))){
						this.data = info;
					}else{
						this.errormsgs = myGlobals.noData;
					}
				},
				error =>{
					this.errormsgs = error;
				}
      		);
    }

}
