// import { TestBed, inject } from '@angular/core/testing';

// import { RdluService } from './rdlu.service';

// describe('RdluService', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       providers: [RdluService]
//     });
//   });

//   it('should ...', inject([RdluService], (service: RdluService) => {
//     expect(service).toBeTruthy();
//   }));
// });
