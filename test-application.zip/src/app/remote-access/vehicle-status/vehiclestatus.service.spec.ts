// import { TestBed, inject } from '@angular/core/testing';

// import { VehiclestatusService } from './vehiclestatus.service';

// describe('VehiclestatusService', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       providers: [VehiclestatusService]
//     });
//   });

//   it('should ...', inject([VehiclestatusService], (service: VehiclestatusService) => {
//     expect(service).toBeTruthy();
//   }));
// });
