import { Component } from '@angular/core';
import {VehiclestatusService} from './vehiclestatus.service';
import {VehicleStatusDTO} from '../../../model/VehicleStatusDTO.model'
import {Message} from 'primeng/primeng';
import {myGlobals} from '../../../constants/globals';
@Component({
  selector: 'vehiclestatus',
  templateUrl: './vehicle-status.component.html',
  providers:[VehiclestatusService]
})
export class VehicleStatusComponent {

  chart:any;
  data:any;
  msgs: Message[] = [];
  growlLife:Number = myGlobals.disAppearTimeMessage;
  mapStatus:any;
  mapStatusLayer:any;
  shapeEnabled:any;
  options:any;
  loading:any;
  vehiclestatus = new VehicleStatusDTO('','locked','unlocked','locked','unlocked','unlocked','unlocked','unlocked','unlocked','unlocked','unlocked','unlocked','unlocked','unlocked','','','','','','','','','','','','',
  '','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','');
  mileage:any;
  constructor(private vehicleStatusService:VehiclestatusService) {
        this.shapeEnabled={
        shapes:{
            rectangle:true,
            circle:true,
            polygon:false,
            polyline:false
        },
        enableDraw:false,
        color:false,
        shape:false,
        height:'300px',
        width:'50%',
        showSearch:false
        };     
   }

   ngOnInit(){
     this.getVehicleStatus();
   }
   getVehicleStatus(){
     this.loading = true;
       this.vehicleStatusService.getVehicleStatus().subscribe(
       info=>{
         this.vehiclestatus = info; 
         this.loading = false;         
       },error=>{
         this.loading = false;
         this.msgs.push({ severity: 'error', summary: '', detail: error });
       }
     );
   }

   getVehicleStatuspost(){
       this.loading = true;
       this.vehicleStatusService.getVehicleStatusPost(this.vehiclestatus).subscribe(
       info=>{
         this.loading = false;
         this.msgs.push({ severity: 'success', summary: '', detail: myGlobals.vswatingMsg });
       },error=>{
         this.loading = false;
         this.msgs.push({ severity: 'error', summary: '', detail: error.err });
       }
     );
   }
}
