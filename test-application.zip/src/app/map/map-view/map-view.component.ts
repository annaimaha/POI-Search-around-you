import { Component, Input, OnInit, AfterViewInit, Output } from '@angular/core';
import { MapService } from '../../../services/map.service';
import {myGlobals} from '../../../constants/globals';

declare var L:any;

@Component({
  selector: 'mapdisplay',
  templateUrl: './map-view.component.html',
  providers: [MapService]
})
export class MapViewComponent implements OnInit {

  latlong: any;
  map: any;
  markersLayer: any;
  @Input() datas: any;
  greenIcon = new L.Icon({ iconUrl:myGlobals.greenIcon, shadowUrl: myGlobals.greenIcon, iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], shadowSize: [41, 41] });
  constructor(private MapService: MapService) {

  }

  ngOnInit() {
    let latitude = this.datas['latitude'];
    let longitude = this.datas['longitude'];

    if (typeof latitude !== "undefined" && latitude !== null) {
      this.map = L.map('mapdisplay').setView([latitude, longitude], 13);
      // base layer
      this.map.addLayer(new L.TileLayer("https://{s}.tiles.mapbox.com/v4/mapquest.streets/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwcXVlc3QiLCJhIjoiY2Q2N2RlMmNhY2NiZTRkMzlmZjJmZDk0NWU0ZGJlNTMifQ.mPRiEubbajc6a5y9ISgydg"));
      this.markersLayer = new L.LayerGroup();
      this.map.addLayer(this.markersLayer);
      let marker = new L.Marker([latitude, longitude], { icon: this.greenIcon });
      this.markersLayer.addLayer(marker);
      this.map._onResize();
    }

  }

  ngAfterViewInit() {

  }


}
