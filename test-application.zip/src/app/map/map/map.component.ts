import { Component, AfterViewInit,Input, OnChanges, SimpleChange, OnDestroy, EventEmitter, Output } from '@angular/core';
import { Map } from 'leaflet';
import { Http, Response, Headers, RequestOptions, URLSearchParams } from '@angular/http';
import { PoiService } from '../../location-services/poi/poi.service';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
declare var L: any;

@Component({
  selector: 'mapRender',
  templateUrl:'./map.component.html',
    providers: [PoiService]
})
export class MapComponent {

	ngOnDestroy() {
        this.map.remove()
    }
		
    map: Map;
    baseMaps: any;
    L: any;
    coordinates: any;
    //_shape: any;
    @Input() value: boolean;
    @Input() zoneType: boolean;
    @Output() updateCoordinates = new EventEmitter();
    @Input() shapeEnabled: any;

    @Input() editOption: any;
    items: any;
    autocomplete: any;
    searchString: any;
    poiSearchData: any;
    searchData: any;
    subscription: Subscription;
    shapeOptsGreen: any;
    color: any;
    shape: any;
    shapeOptsRed: any;
    layer: any;
    drawShape: any;
    drawnLayer: any;
    latitude: any;
    longitude: any;
    shapeType: any;
    drawControl: any;
    markersLayer: any;
    @Input() geofenceeditvalues:any;
    @Input('zoneType')
    set allowDay(value: any) {
        if(!this.editOption){
            this.zoneType = value;
            this.shapeEnabled.color = value;
            this.changeColor(value);
            this.drawControlChange(value);
        }
    }

    private searchTermStream = new Subject<string>();
    constructor(private poiService: PoiService, private http: Http) {

        this.autocomplete = false;
        var self = this;
        this.baseMaps = {
            OpenStreet: new L.tileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
                attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            }),
            CartoDark: new L.tileLayer('http://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png', {
                attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="http://cartodb.com/attributions">CartoDB</a>',
                subdomains: 'abcd',
                maxZoom: 19
            }),
            MapQuest: new L.TileLayer('https://{s}.tiles.mapbox.com/v4/mapquest.streets/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwcXVlc3QiLCJhIjoiY2Q2N2RlMmNhY2NiZTRkMzlmZjJmZDk0NWU0ZGJlNTMifQ.mPRiEubbajc6a5y9ISgydg', {
                attribution: '&copy; <a href="http://www.mapquest.com/">Mapquest Map</a>'
            }),
            Google: new L.TileLayer('http://mt1.google.com/vt/lyrs=m@129&hl=en&x={x}&y={y}&z={z}&s={s}', {
                attribution: '&copy; <a href="http://www.google.com/">Google Map</a>'
            }),
            StamenTerrain: new L.TileLayer('http://tile.stamen.com/terrain/{z}/{x}/{y}.jpg', {
                attribution: ' & Map tiles by <a href="http://stamen.com">Stamen Design</a>">',
                maxZoom: 19
            })
        }
        this.shapeOptsGreen = { strokeColor: "#EB393B", stroke: "#008000", color: "#008000", strokeOpacity: 0.9, strokeWidth: 3, fillColor: "#008000", fill: "#008000", fillOpacity: 0.25, draggable: false, weight: 3 }
        this.shapeOptsRed = { strokeColor: "#EB393B", stroke: "#cd040b", color: "#cd040b", strokeOpacity: 0.9, strokeWidth: 3, fillColor: "#cd040b", fill: "#008000", fillOpacity: 0.25, draggable: false, weight: 3 }
        
    }

    ngAfterViewInit() {
        if(this.editOption){
            this.shapeEnabled.enableDraw = false;
        }
        this.initializeMap('map', this.shapeEnabled);
        if(this.editOption){
            this.geofenceEditOptions(this.geofenceeditvalues);            
        }        
    }

    ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
        // if (changes['shapeEnabled'].previousValue && (changes['shapeEnabled'].previousValue['color'] != changes['shapeEnabled'].currentValue['color'])) {
        //     this.changeColor(changes['shapeEnabled'].currentValue['color']);
        // }
        // if (changes['shapeEnabled'].previousValue && (changes['shapeEnabled'].previousValue['shape'] != changes['shapeEnabled'].currentValue['shape'])) {
        //     this.renderShape(changes['shapeEnabled'].currentValue['shape']);
        // }
    }
    save() {
        this.coordinates = this.outputCoordinates();
        this.updateCoordinates.emit(this.coordinates);
    }

    search(term: string) {        
        this.autocomplete = true;
        this.poiService.searchthePois(term).subscribe(
            info => {
                this.items = info;
            }
        );
    }

    selectedVal(latitude:any, longitude:any, textBind:any) {
        
        this.panToLocation(latitude, longitude, textBind);
        this.searchString = textBind;
        this.autocomplete = false;
    }

    getBaseMaps() {
        return this.baseMaps;
    }

    initializeMap(id:any, shapeEnabled:any) {
        var self = this;
        self.map = L.map(id, {
            zoomControl: true,
            center: new L.LatLng(40.731253, -73.996139),
            zoom: 12,
            minZoom: 2,
            maxZoom: 19,
            layers: [self.baseMaps.MapQuest],
            scrollWheelZoom: false
        });
        self.map.zoomControl.setPosition('topleft');
        this.drawnLayer = new L.FeatureGroup();
        self.map.addLayer(this.drawnLayer);
        var options = {
            position: 'topleft',
            draw: {
                polyline: shapeEnabled.shapes.polyline,
                polygon: shapeEnabled.shapes.polygon,
                circle: shapeEnabled.shapes.circle,
                rectangle: shapeEnabled.shapes.rectangle,
                marker: false
            },
            edit: {
                featureGroup: this.drawnLayer,
                remove: false
            }
        };
        if (shapeEnabled.enableDraw) {
            this.drawControl = new L.Control.Draw(options);
            for (var x in shapeEnabled.shapes) {
                if (shapeEnabled.shapes[x]) {
                    this.drawControl.options.draw[x].shapeOptions = shapeEnabled.color ? this.shapeOptsGreen : this.shapeOptsRed;
                }
            }
            self.map.addControl(this.drawControl);
        }

        L.control.layers(self.baseMaps).addTo(self.map);
        var map = self.map;
        this.renderShape(this.shape);
        self.map.on(L.Draw.Event.CREATED, function (e) {
            var type = e.layerType
            self.layer = e.layer;
            self.drawnLayer.addLayer(self.layer);
            //self.layer.editing.enable()
            self.save();
        });
        self.map.on('focus', function () {
            self.map.scrollWheelZoom.enable();
        });
        self.map.on('blur', function () {
            self.map.scrollWheelZoom.disable();
        });
        self.map.on(L.Draw.Event.DRAWSTART, function (e) {
            // if (!self.shapeType) {
            //     self.shapeType = e.layerType;
            // }
            if (!self.shapeType) {
                self.shapeType = e.layerType;
            }
            else if (self.shapeType != e.layerType && self.layer && self.drawnLayer.hasLayer(self.layer)) {
                self.clearShape();
                self.shapeType = e.layerType;
            } else if (self.shapeType == e.layerType) {

                return;
            }
        })
    }
    outputCoordinates() {
        if (this.layer && this.layer.getRadius && this.layer.getRadius()) {
            this.coordinates = {
                "latLng": this.layer.getLatLng(),
                "radius": this.layer.getRadius(),
                "bounds": this.layer.getBounds(),
                "type": this.shapeType
            }
        } else if (this.layer) {
            this.coordinates = {
                "latLng": this.layer.getLatLngs(),
                "bounds": this.layer.getBounds(),
                "type": this.shapeType
            }
        }
        return this.coordinates;
    }
    resizeMap() {
        //this.map._onResize();
    }

    clearShape() {
        if (this.layer) {
            this.layer.editing.disable();
            this.drawnLayer.removeLayer(this.layer);
        }
        if (this.drawShape) {
            this.drawShape.disable();
            this.drawShape = {};
        }
    }
    renderShape(shape) {
        this.shape = shape ? shape : this.shape;
        switch (this.shape) {
            case 'Ellipse':
                this.drawEclipse();
                break;
            case 'Rectangle':
                this.drawRectangle();
                break;
            case 'Polygon':
                this.drawPolygon();
                break;
            case 'Polyline':
                this.drawPolyline();
                break;
        }
    }

    changeColor(color) {
        this.color = color;
        if (this.drawShape) {
            this.drawShape.setOptions({ shapeOptions: this.color ? this.shapeOptsGreen : this.shapeOptsRed });
        }
        if (this.drawnLayer && this.drawnLayer.getLayers().length > 0) {
            let layer = this.layer;            
                layer.options = this.color ? this.shapeOptsGreen : this.shapeOptsRed;
                this.drawnLayer.removeLayer(this.layer);
                this.drawnLayer.addLayer(layer);            
        }
    }

    drawEclipse() {
        this.clearShape();
        //let shapeOpts = { strokeColor: "#EB393B", stroke: "#EB393B", color: "#EB393B", strokeOpacity: 0.9, strokeWidth: 3, fillColor: "#707070", fillOpacity: 0.35, draggable: false, weight: 3 }
        if (this.map) {
            this.drawShape = new L.Draw.Circle(this.map, "CIRCLE")
            this.drawShape.setOptions({ shapeOptions: this.color ? this.shapeOptsGreen : this.shapeOptsRed })
            this.drawShape.enable();
        }
    }
    drawRectangle() {
        this.clearShape();
        if (this.map) {
            // this.drawShape = new L.Draw.Rectangle(this.map, "RECTANGLE")
            // this.drawShape.setOptions({ shapeOptions: this.color ? this.shapeOptsGreen : this.shapeOptsRed })
            // this.drawShape.enable();
        }
    }
    drawPolygon() {
        this.clearShape();
        if (this.map) {
            // this.drawShape = new L.Draw.Polygon(this.map, "POLYGON")
            // this.drawShape.setOptions({ shapeOptions: this.color ? this.shapeOptsGreen : this.shapeOptsRed })
            // this.drawShape.enable();
        }
    }
    drawPolyline() {
        this.clearShape();
        if (this.map) {
            // this.drawShape = new L.Draw.Polyline(this.map, "POLYLINE")
            // this.drawShape.setOptions({ shapeOptions: this.color ? this.shapeOptsGreen : this.shapeOptsRed })
            // this.drawShape.enable();
        }
    }
    panToLocation(latitude, longitude, textBind) {
        if (latitude !== null && longitude !== null) {
            this.latitude = Number(latitude);
            this.longitude = Number(longitude);
            this.map.panTo(new L.LatLng(this.latitude, this.longitude));
        }
    }
    drawControlChange(value) {
        if (this.drawControl) {
            this.map.removeControl(this.drawControl);
            for (var x in this.shapeEnabled.shapes) {
                if (this.shapeEnabled.shapes[x]) {
                    this.drawControl.options.draw[x].shapeOptions = this.shapeEnabled.color ? this.shapeOptsGreen : this.shapeOptsRed;
                }
            }
            this.drawControl.initialize(this.drawControl.options);
            this.map.addControl(this.drawControl);
        }
    }

    /**
     * Methods to display the shape when edit geofenceEditOptions
     * @editValues Object edit geofence objects
     */

    geofenceEditOptions(editValues) {

        if (typeof editValues !== "undefined" && editValues !== null) {

            let color = (editValues['greenZoneFlag']) ? this.shapeOptsGreen : this.shapeOptsRed;
            this.drawnLayer = new L.LayerGroup();

            // Display Circle

            if (editValues['circleFlag'] === true) {
                let radius = parseInt(editValues['circleRadius'])
                this.map.addLayer(this.drawnLayer);
                let drawShape = L.circle([editValues['ellipseCenterLat'], editValues['ellipseCenterLongi']], radius, color);
                this.drawnLayer.addLayer(drawShape);
                this.map.panTo(new L.LatLng(editValues['ellipseCenterLat'], editValues['ellipseCenterLongi']));
            }

            // Display Rectangle

            if (editValues['rectangleFlag'] === true) {

                let rectcolor = (editValues['greenZoneFlag']) ? "#008000" : "#cd040b";
                let bounds = [[editValues['rectangleNeLat'], editValues['rectangleNeLongi']], [editValues['rectangleNwLat'], editValues['rectangleNwLongi']], [editValues['rectangleSwLat'], editValues['rectangleSwLongi']], [editValues['rectangleSeLat'], editValues['rectangleSeLongi']]];
                this.map.addLayer(this.drawnLayer);
                let drawShape = L.rectangle(bounds, { color: rectcolor, weight: 3 });
                this.drawnLayer.addLayer(drawShape);
                this.map.panTo(new L.LatLng(editValues['rectangleCenterLat'], editValues['rectangleCenterLongi']));
            }
        }
    }

}
