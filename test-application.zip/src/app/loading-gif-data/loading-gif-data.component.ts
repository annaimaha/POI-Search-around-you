import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'loading-gif-data',
  templateUrl: './loading-gif-data.component.html'
})
export class LoadingGifDataComponent implements OnInit {

  constructor() { }
  @Input() loading: any;
  ngOnInit() {
  }

}
