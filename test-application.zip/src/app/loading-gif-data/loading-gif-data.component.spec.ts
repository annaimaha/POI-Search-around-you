// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { LoadingGifDataComponent } from './loading-gif-data.component';

// describe('LoadingGifDataComponent', () => {
//   let component: LoadingGifDataComponent;
//   let fixture: ComponentFixture<LoadingGifDataComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ LoadingGifDataComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(LoadingGifDataComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
