// import { TestBed, inject } from '@angular/core/testing';

// import { VehiclesdisablingService } from './vehiclesdisabling.service';

// describe('VehiclesdisablingService', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       providers: [VehiclesdisablingService]
//     });
//   });

//   it('should ...', inject([VehiclesdisablingService], (service: VehiclesdisablingService) => {
//     expect(service).toBeTruthy();
//   }));
// });
