import { Component} from '@angular/core';

@Component({
  selector: 'vehicleDisablingandHistory',
  templateUrl: './disabling-and-history.component.html'
})
export class DisablingAndHistoryComponent  {

  information: any;
  geofence: any;
  isAccountCollapsed: any;
  tabName: any;
  constructor() {
    this.tabName = "vehicledisable";
    this.isAccountCollapsed = false;
  }

  commonTabs(tabs){
	  this.tabName	= "";
	  this.tabName	= tabs;
  }
  expand() {
    this.isAccountCollapsed = !this.isAccountCollapsed;
  }
  collapsed(isCollapsed){
   this.isAccountCollapsed = isCollapsed;
  }

}
