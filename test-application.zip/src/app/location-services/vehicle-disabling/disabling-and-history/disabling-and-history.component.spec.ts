// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { DisablingAndHistoryComponent } from './disabling-and-history.component';

// describe('DisablingAndHistoryComponent', () => {
//   let component: DisablingAndHistoryComponent;
//   let fixture: ComponentFixture<DisablingAndHistoryComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ DisablingAndHistoryComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(DisablingAndHistoryComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
