// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { VehicleDisablingHistoryComponent } from './vehicle-disabling-history.component';

// describe('VehicleDisablingHistoryComponent', () => {
//   let component: VehicleDisablingHistoryComponent;
//   let fixture: ComponentFixture<VehicleDisablingHistoryComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ VehicleDisablingHistoryComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(VehicleDisablingHistoryComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
