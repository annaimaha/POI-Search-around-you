import {Component, Input} from '@angular/core';
import {VehiclesdisablingService} from '../vehiclesdisabling.service';
import {Message,DialogModule} from 'primeng/primeng';
import {myGlobals} from '../../../../constants/globals';
@Component({
  selector: 'vehicleDisablinghistory',
  templateUrl: './vehicle-disabling-history.component.html',
  providers:[VehiclesdisablingService]
})
export class VehicleDisablingHistoryComponent  {

isAccountCollapsed: any;
  tabName: any;
  public data:any;
  public filterQuery = "";
  public sortBy = "";
  public rowsOnPage = myGlobals.rowsOnPage;
  public sortOrder = myGlobals.sortOrder;  
  growlLife: Number = myGlobals.disAppearTimeMessage;
  msgs:Message[]=[];
  errormsgs:any;
  loading:any;
  requestTypeViews:any;
  viewData:any;
  constructor(private vehicleDisablingService:VehiclesdisablingService) {
    this.tabName = "Alert";
    this.isAccountCollapsed = false;
  }

  ngOnInit(): void {
    this.vehiclesDisablingHistory();
  }

  commonTabs(tabs:any){
	  this.tabName	= "";
	  this.tabName	= tabs;
  }
  expand() {
    this.isAccountCollapsed = !this.isAccountCollapsed;
  }
  collapsed(isCollapsed:any){
   this.isAccountCollapsed = isCollapsed;
  }

  vehiclesDisablingHistory(){
    this.vehicleDisablingService.vehicleDisablingHistory().subscribe(
      info=>{
        this.data = info;
      },error=>{
        this.errormsgs = error;
      }
    );
  }

  viewRequestType(params:any){
    this.loading = true;
    this.vehicleDisablingService.vehicleDisablingDInfoByTransId(params).subscribe(
        info=>{
          this.loading = false;
          this.requestTypeViews = true;
          this.viewData = info;
        },error=>{
          this.loading = false;
          this.errormsgs = error;          
        }
      );
  }


}
