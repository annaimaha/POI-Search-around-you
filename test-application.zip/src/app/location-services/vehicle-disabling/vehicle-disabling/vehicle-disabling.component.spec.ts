// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { VehicleDisablingComponent } from './vehicle-disabling.component';

// describe('VehicleDisablingComponent', () => {
//   let component: VehicleDisablingComponent;
//   let fixture: ComponentFixture<VehicleDisablingComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ VehicleDisablingComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(VehicleDisablingComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
