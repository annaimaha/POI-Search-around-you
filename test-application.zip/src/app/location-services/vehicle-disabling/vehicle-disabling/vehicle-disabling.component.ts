import {Component, OnDestroy, Input, style, state, animate, transition, trigger } from '@angular/core';
import {Message} from 'primeng/primeng';
import {MapService} from '../../../../services/map.service';
import {VehiclesdisablingService} from '../vehiclesdisabling.service';
import {Vehicledisabling} from '../../../../model/VhicleDisablingDTO';
import {myGlobals} from '../../../../constants/globals';
declare var L:any;
@Component({
  selector: 'vehicleDisabling',
  templateUrl: './vehicle-disabling.component.html',
  providers:[VehiclesdisablingService],
   animations: [
        trigger('flyInOut', [
            state('in', style({ transform: 'translateX(0)' })),
            transition('void => *', [
                style({ transform: 'translateX(-100%)' }),//
                animate(200)
            ]),
            transition('* => void', [
                animate(50, style({ transform: 'translateX(100%)' }))
            ])
        ]),
        trigger('swipeUpDown', [
            state('in', style({ transform: 'translateY(0)' })),
            transition('void=> *', [
                style({ transform: 'translateY(-100%)' }),
                animate(300)
            ]),
            transition('* => void', [
                animate(0, style({ transform: 'translateX(100%)' }))
            ])
        ])
    ]
})
export class VehicleDisablingComponent  {

  information: any;
    geofence: any;
    isAccountCollapsed: any;
    tabName: any;
    vdisableMap: any;
    vdisableMapLayer: any;
    vehicledisabling = new Vehicledisabling(null);
    vehicle: any;
    growlLife: Number = myGlobals.disAppearTimeMessage;
    msgs: Message[] = [];
    msgsOne: Message[] = [];
    msgsTwo: Message[] = [];
    msgsThree: Message[] = [];
    msgsFour: Message[] = [];
    vdDataBounds:any;
    loading:any;
    redIcon = new L.Icon({ iconUrl: myGlobals.redIcon, shadowUrl: myGlobals.shadowIcon, iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], shadowSize: [41, 41] });
    constructor(private vehicleDisablingService: VehiclesdisablingService) {
        this.tabName = "Alert";
        this.vehicle = 'Enable';
        this.isAccountCollapsed = false;
        
    }

    ngOnInit() {
        // Initialize the Map with some position
        this.vdisableMap = L.map('vdisableMap').setView([40.731253, -73.996139], 11);
        // base layer
        this.vdisableMap.addLayer(new L.TileLayer('https://{s}.tiles.mapbox.com/v4/mapquest.streets/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwcXVlc3QiLCJhIjoiY2Q2N2RlMmNhY2NiZTRkMzlmZjJmZDk0NWU0ZGJlNTMifQ.mPRiEubbajc6a5y9ISgydg'));
        this.vdisableMapLayer = new L.LayerGroup();
        this.vdisableMap.addLayer(this.vdisableMapLayer);
       // Disabled as per request
       // this.vehicleDisabling();
    }

    commonTabs(tabs) {
        this.tabName = "";
        this.tabName = tabs;
    }

    expand() {
        this.isAccountCollapsed = !this.isAccountCollapsed;
    }
    collapsed(isCollapsed) {
        this.isAccountCollapsed = isCollapsed;
    }

    /*
      Methods to get vehicle disabling or enabling
      @param vehicleswitch boolean true or false
    */
    vehicleDisablingEnabling(vehicleswitch) {
      this.loading = true;
      
      let status = (vehicleswitch === "Enable") ? "activateVehicleDisabling" : "deActivateVehicleDisabling";
      this.vehicleDisablingService.vehicleDisablingRequest(status).subscribe(
        info=>{
          this.vdLocatemarkers(info['latLongList']);
          if(info['vehicleDisablingStatus'] !==null){
              this.vehicle = vehicleswitch;
          }
        },
        error=>{
          this.msgs.push({ severity: 'error', summary: '', detail: error });
          this.loading = false;
        }
      );
    }

    // Methods to get the vehicle Disabling Status
    vehicleDisabling(){
      this.loading = true;
      this.vehicleDisablingService.vehicleDisablingStatus().subscribe(
        info=>{
          this.vdLocatemarkers(info['latLongList']);
        },
        error=>{
          this.loading = false;
          this.msgs.push({ severity: 'error', summary: '', detail: error });
        }
      );
    }


    // Method to locate or palce the marker on Map
    vdLocatemarkers(vdData) {
        this.removeAllMapMarkers();
        this.loading = false;
        if (vdData !== null && !(JSON.stringify(vdData) === JSON.stringify([]))) {
            this.vdDataBounds = [];
            for (let i in vdData) {
                if (vdData[i] != null) {
                    let loc = [vdData[i]['latitude'], vdData[i]['longitude']];
                    let marker = new L.Marker(loc, { icon: this.redIcon });
                    this.vdisableMapLayer.addLayer(marker);
                    this.vdDataBounds.push(loc);
                }
            }
            this.msgs.push({ severity: 'error', summary:'', detail: myGlobals.requestSent });
            this.vdisableMap.fitBounds(this.vdDataBounds);
        }else{
            this.msgsOne = [{ severity: 'info', summary: 'Vehicle Disabling Status :', detail: myGlobals.noData }];
            this.msgsTwo = [{ severity: 'info', summary: 'Clamp State :', detail: myGlobals.noData }];
            this.msgsThree = [{ severity: 'info', summary: 'Engine Status :', detail: myGlobals.noData }];
            this.msgsFour = [{ severity: 'info', summary: 'UTC TimeStamp :', detail: myGlobals.noData }];
            this.msgs.push({ severity: 'error', summary: '', detail: myGlobals.noData });
        }
    }

    // Method to Remove all Markers from layer
    removeAllMapMarkers() {
        this.vdisableMapLayer.clearLayers();
    }


}
