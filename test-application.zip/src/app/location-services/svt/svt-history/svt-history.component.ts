import { Component, OnDestroy, Input, style, state, animate, transition, trigger,Output} from '@angular/core';
import { Message,DialogModule } from 'primeng/primeng'
import {SvtService} from '../svt.service';
import {myGlobals} from '../../../../constants/globals';
@Component({
  selector: 'StolenVehicleTrackingHistory',
  templateUrl: './svt-history.component.html',
  providers: [SvtService],
   animations: [
    trigger('flyInOut', [
      state('in', style({ transform: 'translateX(0)' })),
      transition('void => *', [
        style({ transform: 'translateX(-100%)' }),//
        animate(200)
      ]),
      transition('* => void', [
        animate(50, style({ transform: 'translateX(100%)' }))
      ])
    ]),
    trigger('swipeUpDown', [
      state('in', style({ transform: 'translateY(0)' })),
      transition('void=> *', [
        style({ transform: 'translateY(-100%)' }),
        animate(300)
      ]),
      transition('* => void', [
        animate(0, style({ transform: 'translateX(100%)' }))
      ])
    ])
  ]
})
export class SvtHistoryComponent  {

  geofence: any;
  isAccountCollapsed: any;
  tabName: any;
  msgs: Message[] = [];
  public data:any;
  public filterQuery = "";
  public sortBy = "";
  public rowsOnPage = myGlobals.rowsOnPage;  
  public sortOrder = myGlobals.sortOrder;
  growlLife: Number = myGlobals.disAppearTimeMessage;
  errormsgs: any;
  showOnMap:any;
  mapInfo:any;  
  loading:any;
  constructor(private svtService: SvtService) {
    this.tabName = "Alert";
    this.isAccountCollapsed = false;
  }

  ngOnInit(): void {
    this.svtHistories();
  }

  svtHistories() {
    this.svtService.getSvtHistory().subscribe(
      info => {        
        if(!(JSON.stringify(info) === JSON.stringify([]))){
           this.data = info;
        }else{
          this.errormsgs = myGlobals.noData;
        }
      }, error => {        
        this.errormsgs = error;
      }
    );
  }

  /**
   * Methods to view the Map Info by transaction Id
   */
  viewMapInfo(items:any) {
    this.loading = true; 
    this.svtService.mapInfoByTransactionId(items.transactionId).subscribe(
      info => {
        this.loading = false;
        this.mapInfo = info['0'];
        this.showOnMap = true;        
      }, error => {        
        this.errormsgs = error;
      }
    );
  }


  commonTabs(tabs) {
    this.tabName = "";
    this.tabName = tabs;
  }
  expand() {
    this.isAccountCollapsed = !this.isAccountCollapsed;
  }
  collapsed(isCollapsed) {
    this.isAccountCollapsed = isCollapsed;
  }


}
