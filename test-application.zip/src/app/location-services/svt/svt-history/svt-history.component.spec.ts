// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { SvtHistoryComponent } from './svt-history.component';

// describe('SvtHistoryComponent', () => {
//   let component: SvtHistoryComponent;
//   let fixture: ComponentFixture<SvtHistoryComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ SvtHistoryComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(SvtHistoryComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
