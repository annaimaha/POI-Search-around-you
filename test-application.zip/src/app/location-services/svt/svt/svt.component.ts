import {Component, OnDestroy, Input, style, state, animate, transition, trigger } from '@angular/core';
@Component({
  selector: 'StolenVehicle',
  templateUrl: './svt.component.html',
   animations: [
    trigger('flyInOut', [
      state('in', style({ transform: 'translateX(0)' })),
      transition('void => *', [
        style({ transform: 'translateX(-100%)' }),//
        animate(200)
      ]),
      transition('* => void', [
        animate(50, style({ transform: 'translateX(100%)' }))
      ])
    ]),
    trigger('swipeUpDown', [
      state('in', style({ transform: 'translateY(0)' })),
      transition('void=> *', [
        style({ transform: 'translateY(-100%)' }),
        animate(300)
      ]),
      transition('* => void', [
        animate(0, style({ transform: 'translateX(100%)' }))
      ])
    ])
  ]
})
export class SvtComponent  {

  information: any;
  geofence: any;
  isAccountCollapsed: any;
  tabName: any;
  constructor() {
    this.tabName = "vehicletracking";
    this.isAccountCollapsed = false;
  }

  commonTabs(tabs){
	  this.tabName	= "";
	  this.tabName	= tabs;
  }
  expand() {
    this.isAccountCollapsed = !this.isAccountCollapsed;
  }
  collapsed(isCollapsed){
   this.isAccountCollapsed = isCollapsed;
  }

}
