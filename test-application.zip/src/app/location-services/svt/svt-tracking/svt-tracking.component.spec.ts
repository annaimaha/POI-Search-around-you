// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { SvtTrackingComponent } from './svt-tracking.component';

// describe('SvtTrackingComponent', () => {
//   let component: SvtTrackingComponent;
//   let fixture: ComponentFixture<SvtTrackingComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ SvtTrackingComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(SvtTrackingComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
