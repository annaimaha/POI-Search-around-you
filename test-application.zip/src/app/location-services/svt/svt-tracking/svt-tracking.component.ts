import { Component, OnDestroy, Input, style, state, animate, transition, trigger,Output} from '@angular/core';
import { MapService } from '../../../../services/map.service';
import { Stolenvehicletrack } from '../../../../model/StolenvehicletrackDTO';
import { SelectItem, Message } from 'primeng/primeng';
import { SvtService } from '../svt.service';
import {myGlobals} from '../../../../constants/globals';
import { HelperService } from "../../../../services/helper.service";
declare var L:any;

@Component({
  selector: 'StolenVehicleTracking',
  templateUrl: './svt-tracking.component.html',
  providers: [MapService, SvtService],
  animations: [
    trigger('flyInOut', [
      state('in', style({ transform: 'translateX(0)' })),
      transition('void => *', [
        style({ transform: 'translateX(-100%)' }),//
        animate(200)
      ]),
      transition('* => void', [
        animate(50, style({ transform: 'translateX(100%)' }))
      ])
    ]),
    trigger('swipeUpDown', [
      state('in', style({ transform: 'translateY(0)' })),
      transition('void=> *', [
        style({ transform: 'translateY(-100%)' }),
        animate(300)
      ]),
      transition('* => void', [
        animate(0, style({ transform: 'translateX(100%)' }))
      ])
    ])
  ]
})
export class SvtTrackingComponent {
	information: any;
  geofence: any;
  isAccountCollapsed: any;
  tabName: any;
  errormsgs: any;
  msgs: Message[] = [];
  growlLife: Number = myGlobals.disAppearTimeMessage;
  loading: any;
  vehicleLocated = false;
  trackingmodes = [
    { label: 'Time', value: 'Time' },
    { label: 'Distance', value: 'Mileage' },
    { label: 'Time and Distance', value: 'Combined' },
    { label: 'Pearl Chain', value: 'derivedPearlChain' },
    { label: 'Simulation', value: 'Simulation' }
  ];

  stolenvehicletrack = new Stolenvehicletrack(this.trackingmodes[0]['value'], null, null, '');
  Time: any;
  Distance: any;
  Simulation: any;
  currentTypeMode: any;
  track: any;
  mapTrack: any;
  trackMarkersLayer: any;
  trackingmarker: any;
  Inc = 0;
  greenIcon: any;
  locateCarIcon: any;
  triggerSetInterval: any;
  markerLocatevehicle: any;
  latitude = 40.714339;
  longitude = -74.007370;
  polyLineArray = [];
  callLocateFromDp: any;
  counter: any;
  transactionId: any;
  trackOp: any;
  idx: any;
  constructor(private mapService: MapService, private svtService: SvtService) {
    this.counter = 0;
    this.track = false;
    this.tabName = "Alert";
    this.isAccountCollapsed = false;
    this.greenIcon = new L.Icon({ iconUrl: myGlobals.greenIcon, shadowUrl: myGlobals.shadowIcon, iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], shadowSize: [41, 41] });
    this.locateCarIcon = new L.Icon({ iconUrl: myGlobals.carIcon, iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], shadowSize: [41, 41] });
    this.currentTypeMode = this.stolenvehicletrack.trackingmode;    
    this.idx = 0;
  }

  ngOnDestroy() {
    // Clear the set Interval
    clearInterval(this.triggerSetInterval);
  }

  expand() {
    this.isAccountCollapsed = !this.isAccountCollapsed;
  }
  collapsed(isCollapsed) {
    this.isAccountCollapsed = isCollapsed;
  }

  ngOnInit() {
    // Initialize the Map with some position
    this.mapTrack = L.map('mapTrack').setView([40.731253, -73.996139], 11);
    // base layer
    this.mapTrack.addLayer(new L.TileLayer('https://{s}.tiles.mapbox.com/v4/mapquest.streets/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwcXVlc3QiLCJhIjoiY2Q2N2RlMmNhY2NiZTRkMzlmZjJmZDk0NWU0ZGJlNTMifQ.mPRiEubbajc6a5y9ISgydg'));
    this.trackMarkersLayer = new L.LayerGroup();
    this.mapTrack.addLayer(this.trackMarkersLayer);
    this.getStolenvehicletrack();
  }

  /*
   Method to close and open the tracking and tracking history tabs
   @param tabs string value fom the tab angertag
  */
  commonTabs(tabs) {
    this.tabName = "";
    this.tabName = tabs;
  }

  /*
    Methods get stolenvehicletrack
  */
  getStolenvehicletrack() {
    this.svtService.stolenVehicleTracking().subscribe(
      info => {

      }, error => {

      }
    );
  }

  /*
   Method to locate the current vehicle location by placing the marker
  */
  locateVehicle() {
    this.loading = true;
    this.svtService.locateVehicle().subscribe(
      info => {
        this.loading = false;        
        if (info['latitude'] === null || info['latitude'] === "" || info['longitude'] === "" || info['longitude'] === null) {
          this.transactionId = info['transactionId'];
          this.callLocateFromDp = setInterval(() => this.locateVehicleFromDb(), myGlobals.recallApis);
        } else {
          this.managelocateVehicle(info);
        }
      }, error => {
        this.loading = false;
        this.msgs.push({ severity: 'error', summary: '', detail: error });
      });
  }

  /**
   * Methods to get data from DB 
   */
  locateVehicleFromDb() {
    if (this.counter < 8) {
      this.loading = true;
      let transactionId = "&vehTrackingTransId=" + this.transactionId;
      this.svtService.locateVehicleFromDb(transactionId).subscribe(
        info => {
          if (info['latitude'] !== null && info['latitude'] !== "" && info['longitude'] !== "" && info['longitude'] !== null) {
            clearInterval(this.callLocateFromDp);
            this.managelocateVehicle(info);
          }
        }, error => {
          this.loading = false;
          this.msgs.push({ severity: 'error', summary: '', detail: error });
        });
      this.counter++;
    } else {
      clearInterval(this.callLocateFromDp);
    }
  }

  /*
  Method to track
  */
  vehicleTrack() {
    this.loading = true;    
    this.svtService.stolenVehicleTracking().subscribe(
      info => {
        this.loading = false;
        if (!(JSON.stringify(info) === JSON.stringify([]))) {
          // Uncomment to Start the tracking 
          //this.track = true;
          this.polyLineArray = [];
          this.removeAllTrackMarkers();
          this.msgs.push({ severity: 'success', summary: '', detail: myGlobals.noData });
        } else {
          this.msgs.push({ severity: 'error', summary: '', detail: myGlobals.noData });
        }
      }, error => {
        this.loading = false;
        this.msgs.push({ severity: 'error', summary: '', detail: myGlobals.noData });
      }
    );
  }

  /*
  Method start tracking immediate
  */
  startVehicleTracking() {
    this.loading = true;
    this.svtService.vehicleTrackingMWCall(this.stolenvehicletrack.trackingmode, this.stolenvehicletrack.timeduration, this.stolenvehicletrack.distance).subscribe(
      info => {    
        if (!(JSON.stringify(info) === JSON.stringify([]))) {
          //Uncomment to Start the tracking           
          this.track = true;
          this.polyLineArray = [];
          this.removeAllTrackMarkers();
          this.transactionId = info['transactionId'];
          var vehStartTrackResult = info['locLatLongList'];
          if (!(JSON.stringify(vehStartTrackResult) === JSON.stringify([]))) {
            var firstLatitude = vehStartTrackResult[0].latitude;
            var err = firstLatitude.substring(0, 5);
            if (err == "error") {
              var exception = firstLatitude.substring(5);
              this.msgs.push({ severity: 'error', summary: '', detail: exception });
            } else {
              vehStartTrackResult.forEach(el => {
                this.placingtheMarker(this.idx, el['latitude'], el['longitude'])
                this.idx = this.idx + 1;
              });
              this.loading = false;
              this.startTrackingPeriodicCall(this.transactionId);
            }
          }else{
            this.track = false;
            this.loading = false;
            this.msgs.push({ severity: 'error', summary: '', detail: myGlobals.noData });    
          }
          
        } else {
          this.loading = false;
          this.startTrackingPeriodicCall(this.transactionId);
        }
      }, error => {    
        this.loading = false;
        this.msgs.push({ severity: 'error', summary: '', detail: error });
      }
    );
  }

  /*
  Method start tracking periodic
  */
  startTrackingPeriodicCall(transactionId: any) {
      if(this.idx < 10){
          this.trackOp = setInterval(() => {
          this.svtService.startVehicleTracking(transactionId).subscribe(
            info => {
              this.track = true;
              if (!(JSON.stringify(info) === JSON.stringify([]))) {
                this.placingtheMarker(this.idx, info[0]['latitude'], info[0]['longitude']);
                this.idx = this.idx + 1;
              } else {
                this.msgs.push({ severity: 'error', summary: '', detail: myGlobals.noData });
              }
            }, error => {    
              this.msgs.push({ severity: 'error', summary: '', detail: myGlobals.noData });
            }
          )
        }, this.getTrackingCallPeriod()); 
      }         
  }

  /*
  Method stop tracking
  */
  stopVehicleTracking(transactionId: any) {
    this.loading = true;
    this.svtService.stopVehicleTracking(transactionId).subscribe(
      info => {
        this.loading = false;
        this.track = false;
        clearInterval(this.trackOp);
        this.idx = 0;
        if (!(JSON.stringify(info) === JSON.stringify([]))) {
          this.track = false;
          this.msgs.push({ severity: 'success', summary: '', detail: myGlobals.requestSent });
        } else {
          this.msgs.push({ severity: 'error', summary: '', detail: myGlobals.noData });
        }
      }, error => {
        this.loading = false;
        this.msgs.push({ severity: 'error', summary: '', detail: myGlobals.noData });
      }
    );
  }

  /*
  Method to select the mode of tracking option from mode  of tracking dropdown
  mode will show the corresponding time or time Distance dropdown
  */
  basedOnModeofTrack() {
    // currentTypeMode has value time means it show time dropdown
    this.currentTypeMode = this.stolenvehicletrack.trackingmode;
  }




  /**
   * 
   */
  managelocateVehicle(info) {
    this.loading = false;
    if (!(JSON.stringify(info) === JSON.stringify([])) && info['latitude'] !== null && info['latitude'] !== "" && info['longitude'] !== "" && info['longitude'] !== null) {
      this.latitude = info['latitude'];
      this.longitude = info['longitude'];
      this.markerLocatevehicle = new L.Marker([this.latitude, this.longitude], { icon: this.locateCarIcon }); //se property searched
      this.trackMarkersLayer.addLayer(this.markerLocatevehicle);
      this.mapTrack.panTo(new L.LatLng(this.latitude, this.longitude));
      this.vehicleLocated = true;
    } else {
      this.msgs.push({ severity: 'error', summary: '', detail: myGlobals.noData });
    }
  }

  /*
   Method to place the marker on position by Initialized latitude and longitude
   This mehtod will invoke from
  */
  placingtheMarker(j, latitude, longitude) {
    let inc = j + 1;
    let trackgreenIcon = L.divIcon({ className: "number-icon", html: '<i>' + inc + '</i>' });
    this.trackingmarker = new L.Marker([latitude, longitude], { icon: trackgreenIcon });
    this.trackMarkersLayer.addLayer(this.trackingmarker);      
    /*if (j >= 1) {
      this.polyLineArray = [this.trackingLatLong[j - 1]];
      this.polyLineArray.push(this.trackingLatLong[j]);
      let pathPattern = L.polylineDecorator(
        this.polyLineArray,
        {
          patterns: [
            { offset: 25, repeat: 50, symbol: L.Symbol.arrowHead({ pixelSize: 15, pathOptions: { fillOpacity: 1, color: '#00b3fd' } }) }
          ]
        }
      );
      this.mapTrack.addLayer(pathPattern);
    }*/

    this.mapTrack.panTo(new L.LatLng(latitude, longitude));
  }


  /*
    Method to Reomve all marker from tracing layer
  */
  removeAllTrackMarkers() {
    this.trackMarkersLayer.clearLayers();
  }

  /*
   Get the periodic time to call the tracking api
  */
  getTrackingCallPeriod() {
    if (this.stolenvehicletrack.trackingmode == 'Time') {
      var timeduration = this.stolenvehicletrack.timeduration;
      if (timeduration >= 1 && timeduration <= 5) {
        return timeduration * 60000;
      } else {
        return 30000;
      }
    } else return 30000;
  }

}
