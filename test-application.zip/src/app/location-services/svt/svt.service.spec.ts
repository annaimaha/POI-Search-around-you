// import { TestBed, inject } from '@angular/core/testing';

// import { SvtService } from './svt.service';

// describe('SvtService', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       providers: [SvtService]
//     });
//   });

//   it('should ...', inject([SvtService], (service: SvtService) => {
//     expect(service).toBeTruthy();
//   }));
// });
