import { Injectable } from '@angular/core';
import { Observable }     from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { Http, Response,Headers,RequestOptions } from '@angular/http';
import {myGlobals} from '../../../constants/globals';

@Injectable()
export class SvtService {

  private headers;
  options:any;
  constructor(private http:Http){
    this.headers = new Headers();
    this.headers.append('Content-Type', 'application/json');
    this.headers.append('api-key', 'vzt-vtp-locationsvc');
    this.options = {headers :this.headers,withCredentials: true};
  }

  // Methods to get stolenvehicletrack

  stolenVehicleTracking(){
       return this.http.get(myGlobals.stolenVehicleTracking+sessionStorage["params"],this.options)
            .map(this.extractData)
            .catch(this.handleError);
  }

  // Methods to get Locate Vehicle

  locateVehicle(){
        return this.http.post(myGlobals.locateVehicle+sessionStorage["params"],this.options)
            .map(this.extractData)
            .catch(this.handleError);
  }

  // Methods to get Locate Vehicle info from DB
  
  locateVehicleFromDb(transactionId){
      return this.http.post(myGlobals.locateVehicleFromDb+sessionStorage["params"]+transactionId,this.options)
            .map(this.extractData)
            .catch(this.handleError);
  }
  
  vehicleTrackingMWCall(triggerMode:any,trackingTimeInterval:any,distanceInterval:any){
      return this.http.post(myGlobals.vehicleTrackingMWCall+sessionStorage["params"]
      		+"&triggerMode="+triggerMode+"&trackingTimeInterval="+trackingTimeInterval+"&distanceInterval="+distanceInterval,this.options)
            .map(this.extractData)
            .catch(this.handleError);
  }
  startVehicleTracking(transactionId:any){
      return this.http.post(myGlobals.startVehicleTracking+sessionStorage["params"]+"&vehTrackingTransId="+transactionId,this.options)
            .map(this.extractData)
            .catch(this.handleError);
  }
  stopVehicleTracking(transactionId:any){
      return this.http.post(myGlobals.stopVehicleTracking+sessionStorage["params"]+"&vehTrackingTransId="+transactionId,this.options)
            .map(this.extractData)
            .catch(this.handleError);
  }

  // Method to svtHistory

  getSvtHistory(){
        return this.http.get(myGlobals.svtHistory+sessionStorage["params"],this.options)
            .map(this.extractData)
            .catch(this.handleError);
  }

  // Method to get map info of transaction
  
  mapInfoByTransactionId(transactionId:any){
      return this.http.post(myGlobals.getMapInfoByTransactionId+sessionStorage["params"]+"&vehTrackingTransId="+transactionId,this.options)
            .map(this.extractData)
            .catch(this.handleError);
  }

    private extractData(res: Response) {
        let body = res.json();
        return body.data?body.data: (body || {});
    }
    private handleError(error: Response | any) {
        // In a real world app, we might use a remote logging infrastructure
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} `;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        
        errMsg = (error.status == '0') ? myGlobals.badGateWay : errMsg;

        return Observable.throw(errMsg);
    }

}
