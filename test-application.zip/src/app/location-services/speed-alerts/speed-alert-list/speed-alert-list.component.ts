import { Component, OnDestroy, Input, style, state, animate, transition, trigger, Output, EventEmitter } from '@angular/core';
import {SpeedalertService} from '../speedalert.service';
import { Message } from 'primeng/primeng';
import {myGlobals} from '../../../../constants/globals';
import { HelperService } from "../../../../services/helper.service";
@Component({
  selector: 'SpeedAlertsList',
  templateUrl: './speed-alert-list.component.html',
providers: [SpeedalertService,HelperService]  
})
export class SpeedAlertListComponent  {

  information: any;
  public data:any;
  selectAll:any;
  public filterQuery = "";
  public rowsOnPage = myGlobals.rowsOnPage;
  public sortBy = "vehicleAlertId";
  public sortOrder = myGlobals.sortOrder;
  msgs: Message[] = [];
  info: Message[] = [];
  msgsdelete: Message[] = [];
  growlLife: Number = myGlobals.disAppearTimeMessage;
  errormsgs: any;
  loading: any;
  loadingData: any;
  multiDelete = { checked: false };
  ids = {};
  @Output() speedalerteditevent: EventEmitter<any> = new EventEmitter();
  @Output() notifyParentSpeed: EventEmitter<any> = new EventEmitter();

  constructor(private speedalertservice: SpeedalertService,private helper:HelperService) {
    this.info.push({ severity: 'info', summary: '', detail: myGlobals.speedAlertListNote });
  }

  ngOnInit(): void {
    this.getSpeedAlerts();

  }

  getSpeedAlerts() {
    this.loadingData = true;
    this.speedalertservice.getSpeedAlerts().subscribe(
      info => {
        this.loadingData = false;
        if (!(JSON.stringify(info) === JSON.stringify([]))) {
          this.data = info;
          this.msgsdelete = [];
        } else {
          this.errormsgs = myGlobals.noData;
        }
      },
      error => {
        this.loadingData = false;
        this.errormsgs = error;

        if (!error.status) {
          this.errormsgs = myGlobals.badGateWay;
        }
      }
    );
  }

  editSpeedalert(items) {
    this.loading = true;
    this.speedalertservice.editSpeedAlert(items.vehicleAlertId).subscribe(
      info => {
        this.speedalerteditevent.emit({ option: 'speededit', item: items, details:info});
      },
      error => {
        this.loading = false;
        this.msgsdelete.push({ severity: 'error', summary: '', detail: error.rr });
      });
  }
  // multiDelete and Delete All

  selectAllDeselect(result) {
    this.multiDelete.checked = result;
  }


 // Methods to removeAll 
  removeAll(items) {
       // comma separated values or ids     
       let ids = this.helper.removeAll(items);
       this.remove(ids);
  }

  
 /*
   Methods to delete the ids records
   @param value object : specific records details
 */
  remove(ids: any) {
    this.loading = true;
    if (ids !== "") {
      let id = "speedAlertId=" + ids;
      this.speedalertservice.deleteSpeedAlert(id).subscribe(
        info => {
          this.manageResponse(info)
        }, error => {
          this.errors(error);
        }
      );

    } else {
      this.loading = false;
      this.msgs.push({ severity: 'error', summary: '', detail: myGlobals.nomultidelete });
    }
  }

   /*
   Methods to Manage success response
   @param info object response  details
  */

  manageResponse(info) {
    this.loading = false;
    if (info['responseStatus'] === 'success') {
      this.msgs.push({ severity: 'success', summary: '', detail: info['responseStatus'] });
    } else {
      this.msgs.push({ severity: 'error', summary: '', detail: info['responseDescription'] });
    }
  }

  /*
   Methods to Manage error Response
   @param info object response  details
  */
  errors(error) {
    this.loading = false;
    this.msgs.push({ severity: 'error', summary: '', detail: error });
  }


}
