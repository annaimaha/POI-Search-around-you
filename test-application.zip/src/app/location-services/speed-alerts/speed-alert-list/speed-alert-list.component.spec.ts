// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { SpeedAlertListComponent } from './speed-alert-list.component';

// describe('SpeedAlertListComponent', () => {
//   let component: SpeedAlertListComponent;
//   let fixture: ComponentFixture<SpeedAlertListComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ SpeedAlertListComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(SpeedAlertListComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
