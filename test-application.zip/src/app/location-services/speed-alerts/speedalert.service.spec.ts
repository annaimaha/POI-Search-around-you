// import { TestBed, inject } from '@angular/core/testing';

// import { SpeedalertService } from './speedalert.service';

// describe('SpeedalertService', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       providers: [SpeedalertService]
//     });
//   });

//   it('should ...', inject([SpeedalertService], (service: SpeedalertService) => {
//     expect(service).toBeTruthy();
//   }));
// });
