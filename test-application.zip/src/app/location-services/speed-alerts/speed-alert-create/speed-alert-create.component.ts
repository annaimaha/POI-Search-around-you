import { Component, OnDestroy, Input, style, state, animate, transition, trigger, Output, EventEmitter } from '@angular/core';
import { SelectItem,Message } from 'primeng/primeng';
import { SpeedAlertDTO } from '../../../../model/SpeedAlertDTO.model';
import {SpeedalertService} from '../speedalert.service';
import {myGlobals} from '../../../../constants/globals';
import { HelperService } from "../../../../services/helper.service";
@Component({
  selector: 'SpeedNewAlerts',
  templateUrl: './speed-alert-create.component.html',
  providers: [SpeedalertService, HelperService],
  animations: [
        trigger('flyInOut', [
            state('in', style({ transform: 'translateX(0)' })),
            transition('void => *', [
                style({ transform: 'translateX(-100%)' }),//
                animate(100)
            ]),
            transition('* => void', [
                animate(50, style({ transform: 'translateX(-100%)' }))
            ])
        ])
    ]
})
export class SpeedAlertCreateComponent  {

  
    information: any;
    @Output() notifyParentSpeed: EventEmitter<any> = new EventEmitter();
    @Input() edititems;
    @Input() speedalertEditDetails;
    datetimeerror: any;
    editOptions: boolean;
    dateTimeValidate: boolean = false;
    loading: boolean = false;
    accountInfo: any;
    errormessage: any;
    growlLife: Number = myGlobals.disAppearTimeMessage;
    msgs: Message[] = [];
    weekDays: SelectItem[];
    timeArray = ["Select Time", "00:00 AM", "00:30 AM", "01:00 AM",
        "01:30 AM", "02:00 AM", "02:30 AM", "03:00 AM", "03:30 AM",
        "04:00 AM", "04:30 AM", "05:00 AM", "05:30 AM", "06:00 AM",
        "06:30 AM", "07:00 AM", "07:30 AM", "08:00 AM", "08:30 AM",
        "09:00 AM", "09:30 AM", "10:00 AM", "10:30 AM", "11:00 AM",
        "11:30 AM", "12:00 PM", "12:30 PM", "01:00 PM", "01:30 PM",
        "02:00 PM", "02:30 PM", "03:00 PM", "03:30 PM", "04:00 PM",
        "04:30 PM", "05:00 PM", "05:30 PM", "06:00 PM", "06:30 PM",
        "07:00 PM", "07:30 PM", "08:00 PM", "08:30 PM", "09:00 PM",
        "09:30 PM", "10:00 PM", "10:30 PM", "11:00 PM", "11:30 PM"];
    speedAlert: any;
    data: any;
    SaveorUpdate: any;
    constructor(private speedalertservice: SpeedalertService, public helper: HelperService) {
        this.editOptions = false;
        this.speedAlert = new SpeedAlertDTO("", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", false, false, false, false, false, false, false, "", "", "", "", false, false, false, "", "", "", "", "", "", "", "", "", "", "", null, "", "", "", "", null, null, null, false, false, false, true, false, false, false, false, false, false, 1, null, "", "", "", "", "", "", "", null, null, null, null, null, null, null, "", "", this.timeArray[0], this.timeArray[0], false, 'true', 'true', false, false, false, false, false, false, false);

    }
    ngOnInit() {

        if (this.edititems) {
            this.SaveorUpdate = "Update";
            this.editOptions = true;
            this.speedAlert = this.speedalertEditDetails;
           
            if (this.speedAlert.startDateWithTime !== null && this.speedAlert.startDateWithTime !== "" && this.speedAlert.startDateWithTime !== "undefined") {
                this.speedAlert.alertStartDate = this.helper.formatDate(new Date(this.speedAlert.startDateWithTime.split(" ")[0]));
                
            }

            if (this.speedAlert.startDateWithTime !== null  && this.speedAlert.startDateWithTime !== "" && this.speedAlert.startDateWithTime !== "undefined") {
                this.speedAlert.alertStopDate = this.helper.formatDate(new Date(this.speedAlert.stopDateWithTime.split(" ")[0]));
                
            }

            if (this.speedAlert.everyDay === true) {
                this.speedAlert.everyDay = "true";
            }

            if (this.speedAlert.everyWeek === true) {
                this.speedAlert.everyWeek = "true";
            }

            if (this.speedAlert.everyWeekDayOnly === true) {
                this.speedAlert.everyWeekDayOnly = "true";
            }


        } else {
            this.SaveorUpdate = "Save";
        }
    }

    submitSpeedalert() {

        console.log(this.speedAlert);

        this.loading = true;
        this.dateTimeValidate = true;
        this.accountInfo = JSON.parse(sessionStorage["accountInfo"]);
        this.speedAlert['vin'] = this.accountInfo['vin'];
        this.speedAlert['tcuId'] = this.accountInfo['tcuId'];
        this.speedAlert['accountId'] = this.accountInfo['accountNumber'];



        if (!this.helper.dateTimeValidatefuntion(this.speedAlert['endTime'], this.speedAlert)) {
            this.showError();
            return false;
        }


       
        if (this.editOptions) {
            this.speedAlert.startDateWithTime = this.speedAlert.alertStartDate;
            this.speedAlert.stopDateWithTime = this.speedAlert.alertStopDate;

            this.speedalertservice.updateAlert(JSON.stringify(this.speedAlert), this.edititems).subscribe(
                info => {
                    this.loading = false;
                    if (info['responseStatus'] == "success") {
                        this.notifyParentSpeed.emit({ tab: 'alert', severity: 'success', detail: myGlobals.update });
                    } else {
                        this.msgs.push({ severity: 'error', summary: '', detail: info['responseDescription'] });
                    }
                },
                error => {
                    this.loading = false;
                    this.msgs.push({ severity: 'error', summary: '', detail: error });
                }
            );
        } else {
            this.speedalertservice.createSpeedAlert(JSON.stringify(this.speedAlert), '').subscribe(
                info => {
                    this.loading = false;
                    if (info['responseStatus'] == "success") {
                        this.notifyParentSpeed.emit({ tab: 'alert', severity: 'success', detail: myGlobals.create });
                    } else {
                        this.msgs.push({ severity: 'error', summary: '', detail: info['responseDescription'] });
                    }
                },
                error => {
                    this.loading = false;
                    this.msgs.push({ severity: 'error', summary: '', detail: error });
                }
            );
        }

    }

    changeEndTimeSpeed(endTime) {
        this.datetimeerror = false;
        if (!this.helper.dateTimeValidatefuntion(endTime, this.speedAlert)) {
            this.showError();
        }
    }

    showError() {
        this.loading = false;
        this.datetimeerror = true;
    }

    cancel() {
        this.notifyParentSpeed.emit({ tab: 'alert', severity: 'info', detail: myGlobals.cancels });
    }



}
