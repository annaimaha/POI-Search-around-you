// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { SpeedAlertCreateComponent } from './speed-alert-create.component';

// describe('SpeedAlertCreateComponent', () => {
//   let component: SpeedAlertCreateComponent;
//   let fixture: ComponentFixture<SpeedAlertCreateComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ SpeedAlertCreateComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(SpeedAlertCreateComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
