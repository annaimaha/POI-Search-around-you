import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import {myGlobals} from '../../../constants/globals';

@Injectable()
export class SpeedalertService {

  private headers;
  options:any;
  constructor(private http: Http) {
    this.headers = new Headers();
    this.headers.append('Content-Type', 'application/json');
    this.headers.append('api-key', 'vzt-vtp-locationsvc');
    this.options = {headers :this.headers,withCredentials: true};
  }

  //Method to get the speed alerts

  getSpeedAlerts() {
    return this.http.get(myGlobals.getSpeedAlerts + sessionStorage["params"], this.options)
      .map(this.extractData)
      .catch(this.handleError);
  }
  //Method to create speed alert
  createSpeedAlert(postData: string, queryParam): Observable<any> {

    postData = this.modifydatas(postData);

    return this.http.post(myGlobals.createAlert + sessionStorage["params"], postData, this.options)
      .map(this.extractData)
      .catch(this.handleError);
  }

  editSpeedAlert(editId): Observable<any> {
    return this.http.post(myGlobals.editAlert + "speedVehAlertId=" + editId + sessionStorage["params"], this.options)
      .map(this.extractData)
      .catch(this.handleError);
  }

  updateAlert(postData: string, queryParam): Observable<any> {

    postData = this.modifydatas(postData);


    return this.http.post(myGlobals.updateAlert + "speedVehAlertId=" + queryParam.vehicleAlertId + "&alertName=" + queryParam.alertName + sessionStorage["params"], postData, this.options)
      .map(this.extractData)
      .catch(this.handleError);
  }

  deleteSpeedAlert(idstoDelete: any) {

    return this.http.post(myGlobals.speedAlertDelete + idstoDelete + sessionStorage["params"], this.options)
      .map(this.extractData)
      .catch(this.handleError);
  }

  //Method to get the speed alerts

  getSpeedAlertsHistory() {
    return this.http.get(myGlobals.speedHistory + sessionStorage["params"], this.options)
      .map(this.extractData)
      .catch(this.handleError);
  }

  // Method to delete geofenceHistory services

  deleteSpeedAlertHistory(alertHistroryids: any) {
    return this.http.post(myGlobals.deleteGeofenceHistory + sessionStorage["params"] + alertHistroryids, this.options)
      .map(this.extractData)
      .catch(this.handleError);
  }

  // extract Data
  modifydatas(postData) {

    if (postData['everyDay'] == "true") {
      postData['everyDay'] = true;
    }
    if (postData['everyWeek'] == "true") {
      postData['everyWeek'] = true;
    }
    if (postData['everyWeekDayOnly'] == "true") {
      postData['everyWeekDayOnly'] = true;
    }
    return postData;
  }

  private extractData(res: Response) {
    let body = res.json();
    return body.data ? body.data : (body || {});
  }
  private handleError(error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = body.error || JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} `;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    return Observable.throw(errMsg);
  }


}
