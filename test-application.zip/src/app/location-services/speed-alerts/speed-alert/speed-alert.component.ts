import {Component, OnDestroy, Input, style, state, animate, transition, trigger } from '@angular/core';
import {Message} from 'primeng/primeng';
import {SpeedalertService} from '../speedalert.service';
import {SpeedAlertListComponent} from '../speed-alert-list/speed-alert-list.component';
import {myGlobals} from '../../../../constants/globals';

@Component({
  selector: 'speedAlert',
  templateUrl: './speed-alert.component.html',
  styleUrls: ['./speed-alert.component.css'],
  providers : [SpeedAlertListComponent,SpeedalertService],
  animations: [
        trigger('flyInOut', [
            state('in', style({ transform: 'translateX(0)' })),
            transition('void => *', [
                style({ transform: 'translateX(-100%)' }),//
                animate(200)
            ]),
            transition('* => void', [
                animate(50, style({ transform: 'translateX(100%)' }))
            ])
        ]),
        trigger('swipeUpDown', [
            state('in', style({ transform: 'translateY(0)' })),
            transition('void=> *', [
                style({ transform: 'translateY(-100%)' }),
                animate(300)
            ]),
            transition('* => void', [
                animate(0, style({ transform: 'translateX(100%)' }))
            ])
        ])
    ]
})
export class SpeedAlertComponent {

    information: any;
    isAccountCollapsed: any;
    tabName: any;
    colorCode:any;
    notification: Message[] = [];
    speedalertEditid = "";
    tabnameeditorcreate:any;
    speedalertDetails:any;
    growlLife:Number = myGlobals.disAppearTimeMessage;
    constructor(private speedalertservice:SpeedalertService) {
        this.tabName = "alert";
        this.isAccountCollapsed = false;
        this.colorCode = "#3498db";
        this.tabnameeditorcreate ="Create New Alert";
    }

    commonTabs(tabs){
      this.tabnameeditorcreate ="Create New Alert";
      this.speedalertEditid    = "";
  	  this.tabName	= "";
  	  this.tabName	= tabs;
    }

    redirectToSpeed(messages){        
          this.tabName = messages.tab;
          this.notification.push({ severity: messages.severity, summary: '', detail: messages.detail });
    }

    editSpeedalert(params){
      this.speedalertEditid    = params.item;
      this.speedalertDetails   = params.details;
      this.tabnameeditorcreate ="Edit Alert";
      this.tabName	           = "newAlert";
    }

}
