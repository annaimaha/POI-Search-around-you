// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { SpeedAlertHistoryComponent } from './speed-alert-history.component';

// describe('SpeedAlertHistoryComponent', () => {
//   let component: SpeedAlertHistoryComponent;
//   let fixture: ComponentFixture<SpeedAlertHistoryComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ SpeedAlertHistoryComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(SpeedAlertHistoryComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
