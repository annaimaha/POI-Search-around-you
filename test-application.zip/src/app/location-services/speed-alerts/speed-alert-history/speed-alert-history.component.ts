import { Component } from '@angular/core';
import { Message } from 'primeng/primeng';
import {SpeedalertService} from '../speedalert.service';
import {myGlobals} from '../../../../constants/globals';
import { MapService } from '../../../../services/map.service';
import { Map } from 'leaflet';
import { HelperService } from "../../../../services/helper.service";
declare var L:any;
@Component({
  selector: 'SpeedAlertHistory',
  templateUrl: './speed-alert-history.component.html',
  providers: [SpeedalertService, MapService, HelperService]
})
export class SpeedAlertHistoryComponent {

    public data:any;
    public filterQuery = "";
    public rowsOnPage = myGlobals.rowsOnPage;
    public sortBy = "alertname";
    public sortOrder = myGlobals.sortOrder;
    msgs: Message[] = [];
    info: Message[] = [];
    selectAll:any;
    multiDelete = { checked: false };
    display: boolean = false;
    ids = {};
    loading: any;
    growlLife: Number = myGlobals.disAppearTimeMessage;
    errormsgs: any;
    map: any;
    markersLayer: any;
    markerSpeed: any;
    greenIcon = new L.Icon({ iconUrl: myGlobals.greenIcon, shadowUrl: myGlobals.shadowIcon, iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], shadowSize: [41, 41] });

    constructor(private speedalertservice: SpeedalertService, private mapService: MapService, private helper: HelperService) {
        this.info.push({ severity: 'info', summary: '', detail: 'Existing Speed Alert Violations are listed below. Select the "Location" link to view the location of the alert on a map view.' });
        this.multiDelete.checked = false;
    }

    ngOnInit(): void {
        this.map = L.map('mapSpeed').setView([40.731253, -73.996139], 13);
        // base layer
        this.map.addLayer(new L.TileLayer("https://{s}.tiles.mapbox.com/v4/mapquest.streets/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwcXVlc3QiLCJhIjoiY2Q2N2RlMmNhY2NiZTRkMzlmZjJmZDk0NWU0ZGJlNTMifQ.mPRiEubbajc6a5y9ISgydg"));
        this.markersLayer = new L.LayerGroup();
        this.map.addLayer(this.markersLayer);
        this.getspeedHistory();
    }

    getspeedHistory() {
        this.speedalertservice.getSpeedAlertsHistory().subscribe(
            obj => {
                if (!(JSON.stringify(obj) === JSON.stringify([]))) {
                    this.data = obj;
                } else {
                    this.errormsgs = myGlobals.noData;
                }
            },
            error => {
                this.errormsgs = error;
            });
    }


    showDialog(latLong) {
        let res = latLong.split(",");
        let lat = parseInt(res[0]);
        let long = parseInt(res[1]);
        this.display = true;
        if (lat !== null && long !== null) {
            this.markerSpeed = new L.Marker([lat, long], { icon: this.greenIcon }); //se property searched
            this.markersLayer.addLayer(this.markerSpeed);
            this.map.panTo(new L.LatLng(lat, long));
        }
    }

    /**
     * Methods to Select and De Select
     */
    selectAllDeselect(result:any) {
        this.multiDelete.checked = result;
    }

    // Methods to removeAll 
    removeAll(items:any) {
        // comma separated values or ids     
        let ids = this.helper.removeAll(items);
        this.remove(ids);
    }

    /*
     Methods to delete the ids records
     @param value object : specific records details
   */
    remove(ids: any) {
        this.loading = true;
        if (ids !== "") {
            let id = "alertHistoryIds=" + ids;
            this.speedalertservice.deleteSpeedAlertHistory(id).subscribe(
                info => {
                    this.manageResponse(info)
                }, error => {
                    this.errors(error);
                }
            );

        } else {
            this.loading = false;
            this.msgs.push({ severity: 'error', summary: '', detail: myGlobals.nomultidelete });
        }
    }

    /*
     Methods to Manage success response
     @param info object response  details
    */

    manageResponse(info:any) {
        this.loading = false;
        if (info['responseStatus'] === 'success') {
            this.msgs.push({ severity: 'success', summary: '', detail: info['responseStatus'] });
        } else {
            this.msgs.push({ severity: 'error', summary: '', detail: info['responseDescription'] });
        }
    }

    /*
     Methods to Manage error Response
     @param info object response  details
    */
    errors(error:any) {
        this.loading = false;
        this.msgs.push({ severity: 'error', summary: '', detail: error });
    }


}
