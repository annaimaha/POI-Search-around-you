// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { PoiHistoryComponent } from './poi-history.component';

// describe('PoiHistoryComponent', () => {
//   let component: PoiHistoryComponent;
//   let fixture: ComponentFixture<PoiHistoryComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ PoiHistoryComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(PoiHistoryComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
