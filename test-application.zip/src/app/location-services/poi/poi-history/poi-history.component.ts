import { Component, OnInit } from '@angular/core';
import { Message } from 'primeng/primeng';
import { PoiService } from '../poi.service';
import {myGlobals} from '../../../../constants/globals';
import { HelperService } from '../../../../services/helper.service';

@Component({
  selector: 'poiHistory',
  templateUrl: './poi-history.component.html',
  providers: [PoiService,HelperService]
})
export class PoiHistoryComponent implements OnInit {

  information: any;
  tabName: any;
  selectAll:any;
  public data:any;
  public filterQuery = "";
  public rowsOnPage = myGlobals.rowsOnPage;
  public sortBy = "name";
  public sortOrder = myGlobals.sortOrder;
  loading: any;
  loadingData: any;
  growlLife: number = myGlobals.disAppearTimeMessage;
  msgs: Message[] = [];
  errormsgs: any;
  multiDelete = {
    checked: false
  };
  ids = {};
  constructor(private poiService: PoiService,private helper:HelperService) { }

  ngOnInit() {
    this.getPoiHistories();
  }

  getPoiHistories() {
    this.loadingData = true;
    this.poiService.getPoiHistory().subscribe(
      info => {
        this.loadingData = false;
        if(!(JSON.stringify(info) === JSON.stringify([]))){
           this.data = info;
        }else{
          this.errormsgs = myGlobals.noData;
        }                
      },
      error => {
        this.errormsgs = error;
        this.loadingData = false;

      }
    );
  }

  

  poiTabs(vtpTabs) {
    this.tabName = "";
    this.tabName = vtpTabs;
  }

  // Method to resend Poi To vehicle

  resendVehicle(item) {
    this.loading = true;
    this.poiService.poiHistoryResend(item).subscribe(
      info => {
        this.loading = false;
        if (info['responseStatus'] === 'success') {
          this.msgs.push({ severity: 'success', summary: '', detail: info['responseDescription'] });
          this.getPoiHistories();
        } else {
          this.msgs.push({ severity: 'error', summary: '', detail: info['responseDescription'] });
        }
      },
      error => {
        this.msgs.push({ severity: 'error', summary: '', detail: error });
        this.loading = false;
      }
    );
  }

  selectAllDeselect(result:any) {
    this.multiDelete.checked = result;
  }

  cancelSentPoi(items:any) {
    this.msgs.push({ severity: 'error', summary: '', detail: "Not implemented" });
  }

 // Methods to removeAll 
  removeAll(items:any) {
       // comma separated values or ids     
       let ids = this.helper.removeAll(items);
       this.remove(ids);
  }

/*
   Methods to delete the ids records
   @param value object : specific records details
 */
  remove(ids: any) {
    this.loading = true;
    if (ids !== "") {      
      
      let id = "poiHisList=" + ids;
          
      this.poiService.deletePoiHistory(id).subscribe(
        info => {
          this.manageResponse(info)
        }, error => {
          this.errors(error);
        }
      );

    } else {
      this.loading = false;
      this.msgs.push({ severity: 'error', summary: '', detail: myGlobals.nomultidelete });
    }  }

   /*
   Methods to Manage success response
   @param info object response  details
  */

  manageResponse(info) {
    this.loading = false;
    if (info['responseStatus'] === 'success') {
      this.msgs.push({ severity: 'success', summary: '', detail: info['responseStatus'] });
    } else {
      this.msgs.push({ severity: 'error', summary: '', detail: info['responseDescription'] });
    }
  }

  /*
   Methods to Manage error Response
   @param info object response  details
  */
  errors(error) {
    this.loading = false;
    this.msgs.push({ severity: 'error', summary: '', detail: error });
  }

}
