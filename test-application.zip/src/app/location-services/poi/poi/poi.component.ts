import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'poiComponent',
  templateUrl: './poi.component.html'
})
export class PoiComponent implements OnInit {

	tabName:any;
	
    constructor() {
		this.tabName = "create";
	}

    ngOnInit() {

    }

	 poiTabs(vtpTabs){
	  this.tabName	= "";
	  this.tabName	= vtpTabs;
  }
}
