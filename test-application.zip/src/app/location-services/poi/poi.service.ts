import { Injectable } from '@angular/core';
import { Http, Response,Headers,RequestOptions,URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs';
import {myGlobals} from '../../../constants/globals';
@Injectable()
export class PoiService {

  headers:any;
  options:any;
  constructor(private http:Http) {
	   this.headers = new Headers();
      this.headers.append('Content-Type', 'application/json');
      this.headers.append('Accept', 'application/json');
      this.options = {headers :this.headers,withCredentials: true};
  }

  getPoiDefultPage(): Observable<any> {
        return this.http.get(myGlobals.showPoiDefultPage+sessionStorage["params"],this.options)
            .map(this.extractData)
            .catch(this.handleError);
  }

  getPoiHistory(): Observable<any> {
        return this.http.get(myGlobals.poiHistory+sessionStorage["params"],this.options)
            .map(this.extractData)
            .catch(this.handleError);
    }

  sendtoCar(obj :any){
    let accInfos = JSON.parse(sessionStorage["accountInfo"]);
    obj.crmActId        = accInfos['accountNumber'];
    obj.vin             = accInfos['vin'];
    obj.tcuId           = accInfos['tcuId'];
    obj.poiId           = accInfos['accountNumber'];
    obj.emailAddress    = accInfos['emailId'];
    obj.make             = accInfos['make'];

		return this.http.post(myGlobals.poiSend+sessionStorage["params"], obj, this.options)
                    .map(this.extractData)
                    .catch(this.handleError);
	}

	searchthePois(values:any){

	return this.http.post(myGlobals.poiSearch+"searchString="+values+sessionStorage["params"], this.options)
            .map(this.extractData)
            .catch(this.handleError);
	}

  poiHistoryResend(objResend:any){
    let accInfos = JSON.parse(sessionStorage["accountInfo"]);
    objResend.crmActId = accInfos['accountNumber'];
    objResend.vin      = accInfos['tcuId'];
    objResend.tcuId    = accInfos['vin'];

		return this.http.post(myGlobals.poiHistoryResend+sessionStorage["params"], objResend, this.options)
                    .map(this.extractData)
                    .catch(this.handleError);
  }

deletePoiHistory(idstoDelete :any) {
     return this.http.post(myGlobals.deletePoiHistory+idstoDelete+sessionStorage["params"], this.options)
                .map(this.extractData)
              .catch(this.handleError);
}

  private extractData(res: Response) {
        let body = res.json();
        return body.data?body.data: (body || {});
    }

 private handleError(error: Response | any) {
        // In a real world app, we might use a remote logging infrastructure
        let errMsg: string;

        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }

        errMsg = (error.status == '0') ? myGlobals.badGateWay : errMsg;
        
        return Observable.throw(errMsg);
    }

}
