import { Component, OnInit, Output, EventEmitter} from '@angular/core';
import { Http, Response, Headers, RequestOptions, URLSearchParams} from '@angular/http';
import { PoiService } from '../poi.service';
import {CreatepoiDTO} from '../../../../model/CreatepoiDTO.model';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { MapService} from '../../../../services/map.service';
import { MapResizeService} from '../../../../services/map-resize.service';
import { Subscription }   from 'rxjs/Subscription';
import {Message} from 'primeng/primeng';
import {myGlobals} from '../../../../constants/globals';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

declare var L: any;

@Component({
  selector: 'poiCreate',
  templateUrl: './poi-create.component.html',
  providers: [MapService, PoiService,MapResizeService]
})
export class PoiCreateComponent implements OnInit {
    poiForm: FormGroup;
    public submitted: boolean;
	categories = ["Select Category", "Infrastructure", "Private", "Restaurant", "Sightseeing", "Business", "Misc", "Recreation", "Shopping", "Sport"];
    searchpoi = new CreatepoiDTO('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', this.categories[0], '', '', '', '', '', '', '', '', '', '', '', '', '');
    items: any;
    private searchTermStream = new Subject<string>();
    redIcon = new L.Icon({ iconUrl: myGlobals.redIcon, shadowUrl: myGlobals.shadowIcon, iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], shadowSize: [41, 41] });
    greenIcon = new L.Icon({ iconUrl: myGlobals.greenIcon, shadowUrl: myGlobals.shadowIcon, iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], shadowSize: [41, 41] });
    carIcon = new L.Icon({ iconUrl: myGlobals.carIcon, iconSize: [48, 48], iconAnchor: [12, 41], popupAnchor: [1, -34], shadowSize: [41, 41] });
    tabName: any;
    msgs: Message[] = [];
    growlLife: Number = myGlobals.disAppearTimeMessage;
    poiSearchData: any;
    searchData: any;
    PoiSearchLatLong: any;
    hasSearchData: any;
    latitude: any;
    longitude: any
    titleText: any;
    autocompletePoi: any;
    map: any;
    markersLayer: any;
    selectedPlacemarker: any;
    subscription: Subscription;
    loading: any;
    loadingData: any;
    
    constructor(private fb: FormBuilder,private createpoiService: PoiService, private mapResize: MapResizeService,private http: Http,private mapService: MapService) {
        this.hasSearchData = false;
        this.autocompletePoi = false;
        this.createForm();                    
        this.subscription = this.mapResize.receiveCollapse().subscribe(isCollapsed => {  
            this.resizeMap();
        });
    }
    
    
    createForm() {
            this.poiForm = this.fb.group({
            searchString: ['', Validators.required ],
            name: '',
            immediateDestination:'',
            initiateCallCenterAgent: '',
            vipCategory: '',
            phone: ''      
            });
    }

	 ngOnDestroy() {
        // unsubscribe to ensure no memory leaks
        this.subscription.unsubscribe();
    }

	poiTabs(vtpTabs:any) {
        this.tabName = "";
        this.tabName = vtpTabs;
    }

    ngOnInit() {
        this.map = L.map('mappoi').setView([40.731253, -73.996139], 13);
        // base layer
        this.map.addLayer(new L.TileLayer('https://{s}.tiles.mapbox.com/v4/mapquest.streets/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwcXVlc3QiLCJhIjoiY2Q2N2RlMmNhY2NiZTRkMzlmZjJmZDk0NWU0ZGJlNTMifQ.mPRiEubbajc6a5y9ISgydg'));
        this.markersLayer = new L.LayerGroup();
        this.map.addLayer(this.markersLayer);

        this.createpoiService.getPoiDefultPage().subscribe(
            info => {

            }
        );
    }

    /*
    Method to Trigger the autocomplete in POI search
    @param term String
    */

    search(term: string) {
        term = this.searchpoi.searchString;
        this.loading = true;
        if (term !== '') {
            this.createpoiService.searchthePois(term).subscribe(
                info => {
                    this.autocompletePoi = true;
                    this.loading = false;
                    this.items = info;
                    this.poiSearchData = info;
                    this.locatemarkers();
                }, error => {
                    this.loading = false;
                    this.msgs.push({ severity: 'error', summary: '', detail: error.err });
                }
            );
        } else {
            this.loading = false;
            this.autocompletePoi = false;
        }
    }

    // Method to Send to car
    sendToCarSearchPoi(model: CreatepoiDTO, isValid: boolean) {
        this.submitted = true;
        if(isValid){
        this.searchpoi = model;        
        this.loading = true;        
        this.createpoiService.sendtoCar(this.searchpoi).subscribe(
            info => {
                this.loading = false;
                if (info['responseStatus'] === "success") {
                    this.msgs.push({ severity: 'success', summary: '', detail: info['responseDescription'] });
                } else {
                    this.msgs.push({ severity: 'error', summary: '', detail: info['responseDescription'] });
                }
            }, error => {
                this.loading = false;
                this.msgs.push({ severity: 'error', summary: '', detail: error });
            }
        );
        }
        
    }


    // Method to Remove all Markers from layer
    removeAllMapMarkers() {
        this.markersLayer.clearLayers();
    }

    resizeMap() {        
        this.map._onResize();
    }

    // Method to locate or palce the marker on Map

    locatemarkers() {
        this.removeAllMapMarkers();

        if (this.poiSearchData !== null) {
            this.PoiSearchLatLong = [];
            for (let i in this.poiSearchData) {
                if (this.poiSearchData[i] != null) {
                    let title = this.poiSearchData[i]['formattedAddress'];
                    let loc = [this.poiSearchData[i]['latitude'], this.poiSearchData[i]['longitude']];
                    let marker = new L.Marker(loc, { icon: this.greenIcon });

                    marker.bindPopup(title);

                    // Show the POI address on popup
                    marker.on('mouseover', function(e) {
                        this.openPopup();
                    });

                    // Change the color of marker when click on it
                    marker.on("click", (event: MouseEvent) => {
                        this.selectedValBind(this.poiSearchData[i]);
                        this.selectMarkerLocation(this.poiSearchData[i]);
                        marker.setIcon(this.redIcon);

                    });

                    // Reomve the popup
                    marker.on('mouseout', function(e) {
                        this.closePopup();
                    });
                    this.markersLayer.addLayer(marker);
                    this.PoiSearchLatLong.push(loc);
                    this.carLocation();
                }
            }


            this.map.fitBounds(this.PoiSearchLatLong);
        }
    }

    /*Bind the selectd POI to the search box
        @param textBind String
      */

    selectedValBind(selectedObj) {
        //this.searchpoi.searchString = this.searchpoi.searchString;
        this.searchpoi.searchString = selectedObj['formattedAddress'];
        this.searchpoi.address = selectedObj['formattedAddress'];
        this.searchpoi.city = selectedObj['city'];
        this.searchpoi.state = selectedObj['state'];
        this.searchpoi.postcode = selectedObj['postcode'];
        this.searchpoi.zipCode = selectedObj['zipCode'];
        this.searchpoi.county = selectedObj['county'];
        this.searchpoi.country = selectedObj['country'];
        this.searchpoi.longitude = selectedObj['longitude'];
        this.searchpoi.latitude = selectedObj['latitude'];
        this.searchpoi.distance = selectedObj['distance'];
        this.searchpoi.telphone = selectedObj['telphone'];
        this.searchpoi.streetNo = selectedObj['streetNo'];
        this.searchpoi.street = selectedObj['street'];
    }
    /*
    Change the Marker color when click on marker or mouse over the POI list
    @param texts selected marker
    */

    selectMarkerLocation(datas) {
        if (datas !== null) {

            // Method to update the search result  to the DTO

            this.selectedValBind(datas);

            this.autocompletePoi = false;
            this.latitude = Number(datas['latitude']);
            this.longitude = Number(datas['longitude']);
            this.titleText = datas['formattedAddress'];
            this.locatemarkers();

            this.selectedPlacemarker = new L.Marker([this.latitude, this.longitude], { icon: this.redIcon });
            this.selectedPlacemarker.bindPopup(this.titleText);

            // Show the Address when mouseover on marker
            this.selectedPlacemarker.on('mouseover', function(e) {
                this.openPopup();
            });

            // Reomve the popup
            this.selectedPlacemarker.on('mouseout', function(e) {
                this.closePopup();
            });

            // Change the marker color when marker is clicked
            this.selectedPlacemarker.on("click", (event: MouseEvent) => {
                this.selectedValBind(datas);
            });

            this.markersLayer.addLayer(this.selectedPlacemarker);
            this.map.panTo(new L.LatLng(this.latitude, this.longitude));
        }
    }
    // set the car Icon for current Location of vehicle

    carLocation() {
        let marker = new L.Marker([33.656262, -84.446333], { icon: this.carIcon });
        marker.bindPopup('Current Location');
        this.markersLayer.addLayer(marker);
    }
}
