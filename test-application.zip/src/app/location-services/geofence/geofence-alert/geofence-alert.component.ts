import {Component, OnDestroy, Input,OnInit,Output, EventEmitter } from '@angular/core';
import {Message} from 'primeng/primeng';
import {myGlobals} from '../../../../constants/globals';
import { GeofenceService } from '../geofence.service';
import { HelperService } from '../../../../services/helper.service';
@Component({
  selector: 'GeofenceAlerts',
  templateUrl: './geofence-alert.component.html',  
  providers:[GeofenceService,HelperService]
})
export class GeofenceAlertComponent implements OnInit {
	
  public data:any;  
  public filterQuery = "";
  public rowsOnPage = myGlobals.rowsOnPage;
  public sortBy = "vehicleAlertId";
  public sortOrder = myGlobals.sortOrder;
  selectAll:any;
  msgs: Message[] = [];
  infos: Message[] = [];
  loading:any;
  errormsgs:any;
  nomultidelete:any
  multiDelete = {
    checked : false
  };
  ids = {};
  growlLife:Number = myGlobals.disAppearTimeMessage;


  // Edit Geofence
  @Output() notifyToEditGeo: EventEmitter<any> = new EventEmitter();

  constructor(private geofenceService:GeofenceService,private helper:HelperService){
	 this.infos.push({ severity: 'info', summary: '', detail: 'Below are your existing Geofence Alerts. If a Geofence is Enabled the row is highlighted in Green. To view or edit the alert details of an existing alert, select the alert Name link below' });
  }

  ngOnInit(): void {
  	   this.geoFenceAlert();
  }

	geoFenceAlert(){
	this.data		=	'';
	this.geofenceService.getGefenceAlert().subscribe(
      info => {
        if(!(JSON.stringify(info) === JSON.stringify([]))){
           this.data = info;
        }else{
          this.errormsgs = myGlobals.noData;
        }
      },
      error =>{
        this.errormsgs = error;
      }
    );
	}

  editgeofence(editid:any){
    this.loading = true;
     this.geofenceService.editGeofenceAlert(editid, '').subscribe(
        info => {         
          this.notifyToEditGeo.emit({tab:'newAlert',type:'edit',id:editid,details:info});
          this.loading = false;
        }, error => {
          this.loading = false;
          this.msgs.push({ severity: 'error', summary: '', detail: error });
        }
      );
    
  }

  selectAllDeselect(result){
    this.multiDelete.checked = result;
  }

  removeAll(items) {
       let ids = this.helper.removeAll(items);
       this.remove(ids);
  }

 /*
   Methods to delete the ids records
   @param value object : specific records details
 */
  remove(ids: any) {
    //this.loading = true;
    if (ids !== "") {
      let id = "geofenceAlertId=" + ids;      
      this.geofenceService.deleteGeofenceAlert(id).subscribe(
        info => {
          this.manageResponse(info)
        }, error => {
          this.errors(error);
        }
      );
    } else {
      this.loading = false;
      this.msgs.push({ severity: 'error', summary: '', detail: myGlobals.nomultidelete });
    }
  }

  manageResponse(info){
    if(info['responseStatus']==='success'){
        this.geoFenceAlert();
        this.msgs.push({ severity: 'success', summary: '', detail: myGlobals.deleteRecord });
        this.loading = false;
    }else{
        this.msgs.push({ severity: 'error', summary: '', detail: info['responseDescription'] });
        this.loading = false;
    }

  }

    /*
   Methods to Manage error Response
   @param info object response  details
  */
  errors(error) {
    this.loading = false;
    this.msgs.push({ severity: 'error', summary: '', detail: error });
  }


}
