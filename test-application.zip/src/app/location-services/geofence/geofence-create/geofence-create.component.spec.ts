// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { GeofenceCreateComponent } from './geofence-create.component';

// describe('GeofenceCreateComponent', () => {
//   let component: GeofenceCreateComponent;
//   let fixture: ComponentFixture<GeofenceCreateComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ GeofenceCreateComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(GeofenceCreateComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
