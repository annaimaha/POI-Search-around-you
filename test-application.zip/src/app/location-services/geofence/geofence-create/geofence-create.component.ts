import { Component, OnDestroy, Input, style, state, OnInit,animate, transition, trigger, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import {myGlobals} from '../../../../constants/globals';
import { GeofenceService } from '../geofence.service';
import {MapComponent} from '../../../map/map/map.component';
import { HelperService } from '../../../../services/helper.service';
import { Message } from 'primeng/primeng';
import { GeofenceCreateDTO } from '../../../../model/GeofenceCreateDTO.model';

@Component({
  selector: 'GeofenceNewAlerts',
  templateUrl: './geofence-create.component.html',
  providers: [GeofenceService, HelperService],
  animations: [
    trigger('flyInOut', [
      state('in', style({ transform: 'translateX(0)' })),
      transition('void => *', [
        style({ transform: 'translateX(-100%)' }),//
        animate(300)
      ])
    ])
  ]
})
export class GeofenceCreateComponent implements OnInit {

  address: any;
  dateTimeValidate: any;
  datetimeerror: any;
  information: any;
  shapeType: any;
  geofenceSaved: any;
  coordinates: boolean = false;
  shapeCoordinates: any;
  currentDate: any;
  days: any;
  daysFlag: any;
  selectedDay: any;
  postData: any;
  minDate: any;
  active = true;
  shapeEnabled: any;
  opts: any;
  loading: any;
  accountInfo: any;
  editOption: boolean;
  msgs: Message[] = [];
  growlLife: Number = myGlobals.disAppearTimeMessage;
  dataload: any;
  errormessage: any;
  // EventEmitter event used to redirectTo the geofence alert page
  @Output() notifyParent: EventEmitter<any> = new EventEmitter();
  @Input() editId:any;
  @Input() gefenceEditData:any;
  @Output() gotEditedDatas = new EventEmitter();

  //sample
  geofenceEdit: any;

  timeArray = ["Select Time", "00:00AM", "00:30AM", "01:00AM",
    "01:30AM", "02:00AM", "02:30AM", "03:00AM", "03:30AM",
    "04:00AM", "04:30AM", "05:00AM", "05:30AM", "06:00AM",
    "06:30AM", "07:00AM", "07:30AM", "08:00AM", "08:30AM",
    "09:00AM", "09:30AM", "10:00AM", "10:30AM", "11:00AM",
    "11:30AM", "12:00PM", "12:30PM", "01:00PM", "01:30PM",
    "02:00PM", "02:30PM", "03:00PM", "03:30PM", "04:00PM",
    "04:30PM", "05:00PM", "05:30PM", "06:00PM", "06:30PM",
    "07:00PM", "07:30PM", "08:00PM", "08:30PM", "09:00PM",
    "09:30PM", "10:00PM", "10:30PM", "11:00PM", "11:30PM"];
  geofence = new GeofenceCreateDTO('', null, null, null, null, "", '', null, null, "", '', true, false, false, null, false, null, false, false, true, false, false, 'true', false, this.timeArray[0], this.timeArray[0], null, null, null, false, null, null, null, null, null, null, false, null, 1, null, null, 0, null, false, false, false, false, false, false, false, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, true, false, true, false, true, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, "51.5", "-0.09", "500", "100", "90", null);

  constructor(private geofenceService: GeofenceService, private router: Router, public helper: HelperService){
    this.editOption = false;

    this.shapeType = "Rectangle";
    this.opts = {
      suppressScrollX: true
    }

    this.shapeEnabled = {
      shapes: {
        rectangle: true,
        circle: true,
        polygon: false,
        polyline: false
      },
      color: this.geofence.zoneFlag,
      shape: this.shapeType,
      enableDraw: true,
      showSearch: true,
      width: "100%",
      height: '250px' 
    }


  }

  ngOnDestroy() {
    this.editId = '';
    this.gefenceEditData = '';
  }

  ngOnInit() {
    if (this.editId) {
      this.editOption = true;            
      this.geofence = this.gefenceEditData;      
      this.geofence['alertStartDate'] = this.gefenceEditData['startDateWithTime'];
      this.geofence['alertStopDate'] = this.gefenceEditData['stopDateWithTime'];

      if (this.geofence['greenZoneFlag']) {
        this.geofence.zoneFlag = true;
      } else {
        this.geofence.zoneFlag = false;
      }

      if (this.geofence.everyDay == true) {
        this.geofence.everyDay = "true";
      }
      if (this.geofence.everyWeek == true) {
        this.geofence.everyWeek = "true";
      }
      if (this.geofence.everyWeekDayOnly == true) {
        this.geofence.everyWeekDayOnly = "true";
      }
      
    } else {      
      this.editOption = false;
    }
  }

  submitCreatealert() {
    this.geofence.greenZoneFlag = this.geofence.zoneFlag;
    this.geofence.redZoneFlag = !this.geofence.zoneFlag;
    this.geofence.rectangleFlag = false;
    this.geofence.circleFlag = false;
    this.geofence.ellipseFlag = false;

    if (this.shapeCoordinates && this.shapeCoordinates.type == 'rectangle') {
      this.geofence.rectangleNeLat = this.shapeCoordinates.bounds.getNorthEast().lat;
      this.geofence.rectangleNeLongi = this.shapeCoordinates.bounds.getNorthEast().lng;
      this.geofence.rectangleNwLat = this.shapeCoordinates.bounds.getNorthWest().lat;
      this.geofence.rectangleNwLongi = this.shapeCoordinates.bounds.getNorthWest().lng;
      this.geofence.rectangleSwLat = this.shapeCoordinates.bounds.getSouthWest().lat;
      this.geofence.rectangleSwLongi = this.shapeCoordinates.bounds.getSouthWest().lng;
      this.geofence.rectangleSeLat = this.shapeCoordinates.bounds.getSouthEast().lat;
      this.geofence.rectangleSeLongi = this.shapeCoordinates.bounds.getSouthEast().lng;
      this.geofence.rectangleWidth = '10';
      this.geofence.rectangleHeight = '10';
      this.geofence.rectangleCenterLat = this.shapeCoordinates.bounds.getCenter().lat;
      this.geofence.rectangleCenterLongi = this.shapeCoordinates.bounds.getCenter().lng;
      this.geofence.rectangleRotationAngle = '0';
      this.geofence.rectangleFlag = true;
    } else if (this.shapeCoordinates && this.shapeCoordinates.type == 'circle') {
      this.geofence.circleRadius = this.shapeCoordinates.radius;
      this.geofence.circleCenterLat = this.shapeCoordinates.bounds.getCenter().lat; // 3b
      this.geofence.circleCenterLongi = this.shapeCoordinates.bounds.getCenter().lng;
      this.geofence.circleFlag = true;
      this.geofence.ellipseFlag = true;
      this.geofence.ellipseCenterLat = this.shapeCoordinates.bounds.getCenter().lat;
      this.geofence.ellipseCenterLongi = this.shapeCoordinates.bounds.getCenter().lng;
      this.geofence.ellipseFirstRadius = this.shapeCoordinates.radius;
      this.geofence.ellipseSecondRadius = this.shapeCoordinates.radius;
      this.geofence.ellipseRotationAngle = 0;
    }
    this.datetimeerror = false;
    if (!this.helper.dateTimeValidatefuntion(this.geofence['endTime'], this.geofence)) {
      this.showError();
      return false;
    }




    this.loading = true;

    if (!this.editOption) {
      this.postData = this.geofence;
      this.accountInfo = JSON.parse(sessionStorage["accountInfo"]);
      this.geofence['vin'] = this.accountInfo['vin'];
      this.geofence['tcuId'] = this.accountInfo['tcuId'];
      this.geofence['accountId'] = this.accountInfo['accountNumber'];

      this.geofenceService.createGeofence(JSON.stringify(this.geofence)).subscribe(
        info => {
          if (info['responseStatus'] === 'success') {
            this.loading = false;
            this.information = info;
            this.geofenceSaved = true;

            // trigger the event to redirectTo the geofence alert page
            this.notifyParent.emit({ tab: 'alert', type: 'save' });
          } else {
            this.loading = false;
            this.msgs.push({ severity: 'error', summary: '', detail: info['responseDescription'] });
          }

        }
      );
    } else {
      this.accountInfo = JSON.parse(sessionStorage["accountInfo"]);
      this.geofence.custId = this.accountInfo['accountNumber'];
      this.postData = this.geofence;
      this.geofenceService.updateGeofence(this.geofence).subscribe(
        info => {
          if (info['responseStatus'] === 'success') {
            this.loading = false;
            this.information = info;
            this.geofenceSaved = true;
            // trigger the event to redirectTo the geofence alert page
            this.notifyParent.emit({ tab: 'alert', type: 'update' });
          } else {
            this.loading = false;
            this.msgs.push({ severity: 'error', summary: '', detail: info['responseDescription'] });
          }

        });
    }
  }

  changeEndTimeGeo(endTime:any) {
    this.datetimeerror = false;
    if (!this.helper.dateTimeValidatefuntion(endTime, this.geofence)) {
      this.showError();
    }
  }

  showError() {
    this.loading = false;
    this.datetimeerror = true;
  }

  updateCoordinates(coordinates:any) {
    this.shapeCoordinates = '';
    this.shapeCoordinates = coordinates;
  }
  cancel() {
    this.notifyParent.emit({ tab: 'alert', type: 'close' });
  }


}
