import { Injectable } from '@angular/core';
import { Observable }     from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { Http, Response,Headers,RequestOptions } from '@angular/http';
import {myGlobals} from '../../../constants/globals';
declare var sessionStorage : any;
@Injectable()
export class GeofenceService {
  private headers:any;
  options:any;
  constructor(private http:Http){
    this.headers = new Headers();
    this.headers.append('Content-Type', 'application/json');
    this.headers.append('api-key', 'vzt-vtp-locationsvc');
    this.options = {headers :this.headers,withCredentials: true};
  }
	getGefenceAlert(): Observable<any> {
        return this.http.get(myGlobals.geofenceAlertUrl+sessionStorage["params"],this.options)
            .map(this.extractData)
            .catch(this.handleError);
    }

   createGeofence(postData: string): Observable<any> {
    let postDatas = this.remodifyData(postData);
    
        return this.http.post(myGlobals.geofenceAlertCreate,postDatas, this.options)
            .map(this.extractData)
            .catch(this.handleError);
    }

	
  editGeofenceAlert(editId: any,options:any){
      return this.http.post(myGlobals.editGeofenceAlert+"geoVehAlertId="+editId+sessionStorage["params"],  this.options)
          .map(this.extractData)
          .catch(this.handleError);
  }

  // Method to updateGeofence

  updateGeofence(postData: any): Observable<any> {
       postData = this.remodifyData(postData);
               return this.http.post(myGlobals.updateGeofenceAlert+sessionStorage["params"]+"&alertName="+postData['alertName'], postData, this.options)
             .map(this.extractData)
             .catch(this.handleError);
  }

  // Method to deleteGeofenceAlert

	deleteGeofenceAlert(idstoDelete :any) {
		return this.http.post(myGlobals.geofenceAlertDelete+idstoDelete+sessionStorage["params"], this.options)
                    .map(this.extractData)
                    .catch(this.handleError);
	}

  // Method to getGefenceHistory

  getGefenceHistory(): Observable<any> {
        return this.http.get(myGlobals.geofenceViolationHistory+sessionStorage["params"],this.options)
            .map(this.extractData)
            .catch(this.handleError);
  }

  // Method to delete geofenceHistory services

  geofencehistoryDelete(geofencehistoryid :any){      
    return this.http.post(myGlobals.deleteGeofenceHistory+sessionStorage["params"]+geofencehistoryid, this.options)
                 .map(this.extractData)
                 .catch(this.handleError);
  }

  remodifyData(postData:any){
      if (postData['everyDay'] === "true") {
      postData['everyDay'] = true;
    }

    if (postData['everyWeek'] === "true") {
      postData['everyWeek'] = true;
    }

    if (postData['everyWeekDayOnly'] === "true") {
      postData['everyWeekDayOnly'] = true;
    }

    return postData;
  }
  private extractData(res: Response) {
      let body = res.json();
      return body.data?body.data: (body || {});
  }
  private handleError(error: Response | any) {
      // In a real world app, we might use a remote logging infrastructure
      let errMsg: string;
      if (error instanceof Response) {
          const body = error.json() || '';
          const err = body.error || JSON.stringify(body);
          errMsg = `${error.status} - ${error.statusText || ''} `;
      } else {
          errMsg = error.message ? error.message : error.toString();
      }
      
      errMsg = (error.status == '0') ? myGlobals.badGateWay : errMsg;

      return Observable.throw(errMsg);
  }

}
