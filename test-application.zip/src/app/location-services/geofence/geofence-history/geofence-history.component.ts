import { Component ,OnInit} from '@angular/core';
import { Message, DialogModule } from 'primeng/primeng';
import {myGlobals} from '../../../../constants/globals';
import { GeofenceService } from '../geofence.service';
import { HelperService } from '../../../../services/helper.service';
import { MapViewComponent } from '../../../map/map-view/map-view.component';
import { MapService } from '../../../../services/map.service';
declare var L:any;
@Component({
  selector: 'GeofenceHistory',
  templateUrl: './geofence-history.component.html',
  providers: [GeofenceService,HelperService,MapService]
})
export class GeofenceHistoryComponent implements OnInit {
  information: any;
  msgs: Message[] = [];
  info: Message[] = [];
  public data:any;
  public filterQuery = "";
  public rowsOnPage = myGlobals.rowsOnPage;
  public sortBy = "alertName";
  public sortOrder = myGlobals.sortOrder;
  selectAll:any;
  display: boolean = false;
  errormsgs: any;
  loading: any;
  map: any;
  markersLayer: any;
  markerLocatevehicle: any;
  growlLife: Number = myGlobals.disAppearTimeMessage;
  multiDelete = {
    checked: false
  };
  ids = {};
  
  greenIcon = new L.Icon({ iconUrl: myGlobals.greenIcon, shadowUrl: myGlobals.shadowIcon, iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], shadowSize: [41, 41] });
  
  constructor(private geofenceService: GeofenceService,private helper:HelperService ,private mapService :MapService) {
    this.info.push({ severity: 'info', summary: '', detail: 'Below are your existing violations.To view the location of the alert on a map view,select the location link shown below.' });

  }

  ngOnInit(): void {
    this.map = L.map('mapdisplay').setView([40.731253, -73.996139], 13);
    // base layer
    this.map.addLayer(new L.TileLayer("https://{s}.tiles.mapbox.com/v4/mapquest.streets/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwcXVlc3QiLCJhIjoiY2Q2N2RlMmNhY2NiZTRkMzlmZjJmZDk0NWU0ZGJlNTMifQ.mPRiEubbajc6a5y9ISgydg"));
    this.markersLayer = new L.LayerGroup();
    this.map.addLayer(this.markersLayer);
    this.geofenceHistory();
  }

  geofenceHistory() {
    //geofenceViolationHistory    
    this.geofenceService.getGefenceHistory().subscribe(
      objs => {
        if (!(JSON.stringify(objs) === JSON.stringify([]))) {
          this.data = objs;
        } else {
          this.errormsgs = myGlobals.noData;
        }
      },
      error => {
        this.errormsgs = error;
      });
  }


  showDialog(latLong) {
    this.display = true;
    let res = latLong.split(",");
    let lat = parseInt(res[0]);
    let long = parseInt(res[1]);

    if (lat !== null && long !== null) {
      this.markerLocatevehicle = new L.Marker([lat, long], { icon: this.greenIcon }); //se property searched
      this.markersLayer.addLayer(this.markerLocatevehicle);
      this.map.panTo(new L.LatLng(lat, long));
    }
  }

  // multiDelete and Delete All

  selectAllDeselect(result) {
    this.multiDelete.checked = result;
  }

  // Methods to removeAll 
  removeAll(items) {
       // comma separated values or ids     
       let ids = this.helper.removeAll(items);
       this.remove(ids);
  }

  /*
   Methods to delete the ids records
   @param value object : specific records details
 */
  remove(ids: any) {
    this.loading = true;
    if (ids !== "") {
      let id = "geofenceHistoryIds=" + ids;
      
      this.geofenceService.geofencehistoryDelete(id).subscribe(
        info => {
          this.manageResponse(info)
        }, error => {
          this.errors(error);
        }
      );

    } else {
      this.loading = false;
      this.msgs.push({ severity: 'error', summary: '', detail: myGlobals.nomultidelete });
    }
  }

  /*
   Methods to Manage success response
   @param info object response  details
  */

  manageResponse(info) {
    this.loading = false;
    if (info['responseStatus'] === 'success') {
      this.msgs.push({ severity: 'success', summary: '', detail: info['responseStatus'] });
    } else {
      this.msgs.push({ severity: 'error', summary: '', detail: info['responseDescription'] });
    }
  }

  /*
   Methods to Manage error Response
   @param info object response  details
  */
  errors(error) {
    this.loading = false;
    this.msgs.push({ severity: 'error', summary: '', detail: error });
  }


}
