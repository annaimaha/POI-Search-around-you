// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { GeofenceHistoryComponent } from './geofence-history.component';

// describe('GeofenceHistoryComponent', () => {
//   let component: GeofenceHistoryComponent;
//   let fixture: ComponentFixture<GeofenceHistoryComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ GeofenceHistoryComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(GeofenceHistoryComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
