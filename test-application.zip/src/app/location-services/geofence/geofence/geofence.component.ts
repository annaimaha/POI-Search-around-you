import {Component, OnDestroy, Input, style, OnInit,state, animate, transition, trigger } from '@angular/core';
import {Message} from 'primeng/primeng';
import { GeofenceCreateComponent } from '../geofence-create/geofence-create.component';
import {myGlobals} from '../../../../constants/globals';
import { GeofenceService } from '../geofence.service';
@Component({
  selector: 'geofence',
  templateUrl: './geofence.component.html',
  styleUrls: ['./geofence.component.css'],
  animations: [
        trigger('flyInOut', [
            state('in', style({ transform: 'translateX(0)' })),
            transition('void => *', [
                style({ transform: 'translateX(-100%)' }),//
                animate(200)
            ]),
            transition('* => void', [
                animate(50, style({ transform: 'translateX(100%)' }))
            ])
        ]),
        trigger('swipeUpDown', [
            state('in', style({ transform: 'translateY(0)' })),
            transition('void=> *', [
                style({ transform: 'translateY(-100%)' }),
                animate(300)
            ]),
            transition('* => void', [
                animate(0, style({ transform: 'translateX(100%)' }))
            ])
        ])
    ]
})
export class GeofenceComponent implements OnInit {

   geofence: any;
    isAccountCollapsed: any;
    tabName: any;
    success: Message[] = [];
    geofenceidEdit: any;
    geofenceDetails:any;
    editorcreatealert: any;
    growlLife: Number = myGlobals.disAppearTimeMessage;
    constructor() {
        this.tabName = "alert";
        this.editorcreatealert = "Create New Alert";
        this.isAccountCollapsed = false;
    }
    ngOnInit() {
    }

    ngOnDestroy() {
    }

    geofenceTabs(geofence:any) {
        this.editorcreatealert = "Create New Alert";
        this.tabName = "";
        this.tabName = geofence;
        this.geofenceidEdit ='';
    }

    redirectTo(Components:any) {
        this.tabName = Components.tab;
        if (Components.type === 'save') {
            this.success.push({ severity: 'success', summary: '', detail: 'Geofence alert has been added successfully' });
        }
    }

    triggerGeoEdit(params:any) {
        this.tabName = params.tab;
        this.editorcreatealert = "Edit Geofence Alert";
        this.geofenceidEdit = params.id;
        this.geofenceDetails = params.details;
    }

}
