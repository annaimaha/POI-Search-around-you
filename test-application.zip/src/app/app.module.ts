import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { HttpModule, Http, JsonpModule } from '@angular/http';
import { TranslateModule, TranslateStaticLoader, TranslateLoader } from 'ng2-translate';
import { PerfectScrollbarModule } from 'angular2-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'angular2-perfect-scrollbar';
import { PanelMenuModule, InputTextModule, ButtonModule, RadioButtonModule, AccordionModule, CheckboxModule, SliderModule, InputSwitchModule, TooltipModule, InputTextareaModule, DialogModule, CalendarModule, SelectButtonModule, SplitButtonModule, GrowlModule, InputMaskModule, MessagesModule, DropdownModule, SpinnerModule } from 'primeng/primeng';
import { DataTableModule } from "angular2-datatable";
import {InlineEditorModule} from 'ng2-inline-editor';
/****Component Imports ***/
import { AppComponent } from './app.component';
import { AccountInfoComponent } from './account-info/account-info.component';
import { AssetInfoComponent } from './asset-info/asset-info.component';
import { TelephoneInfoComponent } from './telephone-info/telephone-info.component';
import { VehicleInfoComponent } from './vehicle-info/vehicle-info.component';
import { LandingComponent } from './landing/landing.component';
import { LoginComponent } from './login/login.component';

//Nav 

import { LoadingGifDataComponent } from './loading-gif-data/loading-gif-data.component';


import { routing } from './app.routes';
import { VehicleHealthReportComponent } from './vhr/vehicle-health-report/vehicle-health-report.component';
import { ViewVhrComponent } from './vhr/view-vhr/view-vhr.component';
import { VhrRequstOrConfigComponent } from './vhr/vhr-requst-or-config/vhr-requst-or-config.component';
import { VhrHistoryComponent } from './vhr/vhr-history/vhr-history.component';
import { TripStatisticsComponent } from './trip-statistics/trip-statistics/trip-statistics.component';
import { LastTripReportComponent } from './trip-statistics/last-trip-report/last-trip-report.component';
import { UserResetReportComponent } from './trip-statistics/user-reset-report/user-reset-report.component';
import { InformationCallComponent } from './calls/icall/information-call/information-call.component';
import { IcallListViewComponent } from './calls/icall/icall-list-view/icall-list-view.component';
import { ICallDetailsViewComponent } from './calls/icall/i-call-details-view/i-call-details-view.component';
import { EmergencyCallComponent } from './calls/ecall/emergency-call/emergency-call.component';
import { EcallListViewComponent } from './calls/ecall/ecall-list-view/ecall-list-view.component';
import { EcallDetailsViewComponent } from './calls/ecall/ecall-details-view/ecall-details-view.component';
import { RoadAssistanceCallComponent } from './calls/rcall/road-assistance-call/road-assistance-call.component';
import { RcallListViewComponent } from './calls/rcall/rcall-list-view/rcall-list-view.component';
import { RcallDetailsViewComponent } from './calls/rcall/rcall-details-view/rcall-details-view.component';
import { PoiComponent } from './location-services/poi/poi/poi.component';
import { PoiCreateComponent } from './location-services/poi/poi-create/poi-create.component';
import { PoiHistoryComponent } from './location-services/poi/poi-history/poi-history.component';
import { GeofenceComponent } from './location-services/geofence/geofence/geofence.component';
import { GeofenceAlertComponent } from './location-services/geofence/geofence-alert/geofence-alert.component';
import { GeofenceHistoryComponent } from './location-services/geofence/geofence-history/geofence-history.component';
import { GeofenceCreateComponent } from './location-services/geofence/geofence-create/geofence-create.component';
import { MapComponent } from './map/map/map.component';
import { MapViewComponent } from './map/map-view/map-view.component';
import { NotificationComponent } from './notification/notification.component';
import { ScheduleAlertComponent } from './schedule-alert/schedule-alert.component';
import { SpeedAlertComponent } from './location-services/speed-alerts/speed-alert/speed-alert.component';
import { SpeedAlertListComponent } from './location-services/speed-alerts/speed-alert-list/speed-alert-list.component';
import { SpeedAlertHistoryComponent } from './location-services/speed-alerts/speed-alert-history/speed-alert-history.component';
import { SpeedAlertCreateComponent } from './location-services/speed-alerts/speed-alert-create/speed-alert-create.component';
import { SvtComponent } from './location-services/svt/svt/svt.component';
import { SvtTrackingComponent } from './location-services/svt/svt-tracking/svt-tracking.component';
import { SvtHistoryComponent } from './location-services/svt/svt-history/svt-history.component';
import { VehicleDisablingComponent } from './location-services/vehicle-disabling/vehicle-disabling/vehicle-disabling.component';
import { VehicleDisablingHistoryComponent } from './location-services/vehicle-disabling/vehicle-disabling-history/vehicle-disabling-history.component';
import { DisablingAndHistoryComponent } from './location-services/vehicle-disabling/disabling-and-history/disabling-and-history.component';
import { VehicleStatusComponent } from './remote-access/vehicle-status/vehicle-status.component';
import { DoorlockunlockComponent } from './remote-access/rdlu/doorlockunlock/doorlockunlock.component';
import { DoorlockunlockHistoryComponent } from './remote-access/rdlu/doorlockunlock-history/doorlockunlock-history.component';
import { DoorstatusComponent } from './remote-access/rdlu/doorstatus/doorstatus.component';
import { HonkingandflashingComponent } from './remote-access/honk-flash/honkingandflashing/honkingandflashing.component';
import { HonkflashhistoryComponent } from './remote-access/honk-flash/honkflashhistory/honkflashhistory.component';
import { BatteryChargingComponent } from './electric-vehicle/battery-charging/battery-charging/battery-charging.component';
import { BatterySettingsComponent } from './electric-vehicle/battery-charging/battery-settings/battery-settings.component';
import { BatteryStartstopchargingComponent } from './electric-vehicle/battery-charging/battery-startstopcharging/battery-startstopcharging.component';
import { addingkmPipe,precentagePipe,ampsPipe,hoursminutesPipe } from './pipes/batterysettings.pipe';
import { OnoroffPipe,IsDeletedNeedPipe } from './pipes/remotedeparture.pipe';
import { RemoteClimatizationComponent } from './electric-vehicle/remote-climatization/remote-climatization/remote-climatization.component';
import { RemoteClimatizationSettingsComponent } from './electric-vehicle/remote-climatization/remote-climatization-settings/remote-climatization-settings.component';
import { RemoteClimatizationStartstopComponent } from './electric-vehicle/remote-climatization/remote-climatization-startstop/remote-climatization-startstop.component';
import { RemoteDepatureTimeComponent } from './electric-vehicle/remote-departure-time/remote-depature-time/remote-depature-time.component';
import { DepatureTimerComponent } from './electric-vehicle/remote-departure-time/depature-timer/depature-timer.component';
import { NavComponent } from './nav/nav.component';
import { PhonenumberDirective } from './directives/phonenumber.directive';
import { ValidnameDirective } from './directives/validname.directive';
import { NotFoundComponent } from './not-found/not-found.component';
import { OnlynumberDirective } from './directives/onlynumber.directive';
import { FooterComponent } from './footer/footer.component';
import { PoisearchPipe } from './pipes/poisearch.pipe';
import { MapResizeService} from '../services/map-resize.service';
import { LoadingComponent } from './loading/loading.component';
import { AccountCombinationComponent } from './account-combination/account-combination.component';





export function createTranslateLoader(http: Http) {
    return new TranslateStaticLoader(http, 'assets/i18n', '.json');
}


const PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
    suppressScrollX: true
};

export const primeNgModules = [
    PanelMenuModule, InputTextModule, ButtonModule, RadioButtonModule, DropdownModule, SpinnerModule,
    CheckboxModule, InputSwitchModule, TooltipModule, InputTextareaModule, DialogModule,
    CalendarModule, SelectButtonModule, SplitButtonModule, GrowlModule, MessagesModule, InputMaskModule, SliderModule
]

@NgModule({
  declarations: [
    AppComponent,
    AccountInfoComponent,
    AssetInfoComponent,    
    TelephoneInfoComponent,
    VehicleInfoComponent,
    LandingComponent,
    LoginComponent,    
    LoadingGifDataComponent,
    VehicleHealthReportComponent,
    ViewVhrComponent,
    VhrRequstOrConfigComponent,
    VhrHistoryComponent,
    TripStatisticsComponent,
    LastTripReportComponent,
    UserResetReportComponent,
    InformationCallComponent,
    IcallListViewComponent,
    ICallDetailsViewComponent,
    EmergencyCallComponent,
    EcallListViewComponent,
    EcallDetailsViewComponent,
    RoadAssistanceCallComponent,
    RcallListViewComponent,
    RcallDetailsViewComponent,
    PoiComponent,
    PoiCreateComponent,
    PoiHistoryComponent,
    GeofenceComponent,
    GeofenceAlertComponent,
    GeofenceHistoryComponent,
    GeofenceCreateComponent,
    MapComponent,
    MapViewComponent,
    NotificationComponent,
    ScheduleAlertComponent,
    SpeedAlertComponent,
    SpeedAlertListComponent,
    SpeedAlertHistoryComponent,
    SpeedAlertCreateComponent,
    SvtComponent,
    SvtTrackingComponent,
    SvtHistoryComponent,
    VehicleDisablingComponent,
    VehicleDisablingHistoryComponent,
    DisablingAndHistoryComponent,
    VehicleStatusComponent,
    DoorlockunlockComponent,
    DoorlockunlockHistoryComponent,
    DoorstatusComponent,
    HonkingandflashingComponent,
    HonkflashhistoryComponent,
    BatteryChargingComponent,
    BatterySettingsComponent,
    BatteryStartstopchargingComponent,
    addingkmPipe,precentagePipe,ampsPipe,hoursminutesPipe,
    OnoroffPipe,
    IsDeletedNeedPipe,
    RemoteClimatizationComponent,
    RemoteClimatizationSettingsComponent,
    RemoteClimatizationStartstopComponent,
    RemoteDepatureTimeComponent,
    DepatureTimerComponent,
    NavComponent,
    PhonenumberDirective,
    ValidnameDirective,
    NotFoundComponent,
    OnlynumberDirective,
    FooterComponent,
    PoisearchPipe,
    LoadingComponent,
    AccountCombinationComponent
  ],
  imports: [
    BrowserModule,
    InlineEditorModule,
	BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,	
	DataTableModule,    
	routing,TranslateModule.forRoot({
        provide: TranslateLoader,
        useFactory: (createTranslateLoader),
        deps: [Http]
    }),
	...primeNgModules,
	PerfectScrollbarModule.forRoot(PERFECT_SCROLLBAR_CONFIG)
  ],
  exports: [TranslateModule, HttpModule],
  providers: [MapResizeService],
  bootstrap: [AppComponent]
})
export class AppModule { }

