import { Component, OnInit } from '@angular/core';
import { AccountService } from '../account-info/account.service';
declare var sessionStorage: any;
@Component({
  selector: 'app-account-combination',
  templateUrl: './account-combination.component.html',
  styleUrls: ['./account-combination.component.css'],
  providers: [AccountService]
})
export class AccountCombinationComponent implements OnInit {
information: any;
  informationLoaded: any;
  accountService: any;
  accountInterval: any;
  constructor(private accService: AccountService) {

  }
  ngOnInit() {
    var self = this;
    this.accountInterval = setInterval(function () {
      if (sessionStorage["accountInfo"]) {        
        self.information = JSON.parse(sessionStorage["accountInfo"]);
        self.informationLoaded = true;
        clearInterval(self.accountInterval);
      }
    }, 100)
  }
}
