import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountCombinationComponent } from './account-combination.component';

import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateService, TranslationChangeEvent } from '@ngx-translate/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {TooltipModule} from 'primeng/primeng';
import {Http, HttpModule,  ResponseOptions, XHRBackend} from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { Observable } from 'rxjs/Observable';
import { MockBackend } from '@angular/http/testing';
import { Component, OnInit,OnDestroy, Input, style, state, animate, transition, trigger, EventEmitter, Output } from '@angular/core';
 import {AccountService} from '../account-info/account.service';

import { CommonModule } from '@angular/common';

@Component({
    selector: 'perfect-scrollbar',
    template: ''
})
export class FakePerfectScrollbarComponent {
    @Input() runInsideAngular;
}

@Component({
    selector: 'assetInfo',
    template: ''
})
export class FakeAssetInfoComponent {
    @Input() assetInfo;
}


@Component({
    selector: 'telephoneInfo',
    template: ''
})
export class FakeTelephoneInfoComponent {
    @Input() telephoneInfo;
}

@Component({
    selector: 'accountInfo',
    template: ''
})
export class FakeAccountInfoComponent {
    @Input() accountInfo;
}

describe('AccountCombinationComponent', () => {
    //  let mockIntervalService: MockIntervalService;
  function findElement(fixture: ComponentFixture<AccountCombinationComponent>, selector: string): any {
    return fixture.debugElement.query(By.css(selector)).nativeElement;
  }

    let comp: AccountCombinationComponent;
  let fixture: ComponentFixture<AccountCombinationComponent>;
  let de: DebugElement;
  let el: HTMLElement;
var timerCallback;

  beforeEach(async(() => {
    //   mockIntervalService = new MockIntervalService();
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), FormsModule, TooltipModule, HttpModule, BrowserModule],
      declarations: [ AccountCombinationComponent, FakePerfectScrollbarComponent,
      FakeAssetInfoComponent, FakeTelephoneInfoComponent, FakeAccountInfoComponent],
      providers: [TranslateService,AccountService,
              { provide: XHRBackend, useClass: MockBackend }],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountCombinationComponent);
    comp = fixture.componentInstance;
    sessionStorage.setItem('accountInfo','{ "accountId":"12345", "vid":"43534"}');
    comp.ngOnInit();
  });

    beforeEach(function() {
    timerCallback = jasmine.createSpy("timerCallback");
    jasmine.clock().install();
  });

  afterEach(function() {
    jasmine.clock().uninstall();
  });

    it('true is true', () => {
    expect(true).toEqual(true);
  });

  it('can instantiate it', () => {
    expect(comp).not.toBeNull();
  });


 });