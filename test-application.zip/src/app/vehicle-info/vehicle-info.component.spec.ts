import { ComponentFixture, inject, TestBed, async, fakeAsync, tick } from '@angular/core/testing';

import { VehicleInfoComponent } from './vehicle-info.component';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateService, TranslationChangeEvent } from '@ngx-translate/core';


describe('VehicleInfoComponent', () => {

  function findElement(fixture: ComponentFixture<VehicleInfoComponent>, selector: string): any {
    return fixture.debugElement.query(By.css(selector)).nativeElement;
  }

  let comp: VehicleInfoComponent;
  let fixture: ComponentFixture<VehicleInfoComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      declarations: [ VehicleInfoComponent ],
      providers: [TranslateService],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VehicleInfoComponent);
    comp = fixture.componentInstance;
  });

    it('true is true', () => {
    expect(true).toEqual(true);
  });

  it('can instantiate it', () => {
    expect(comp).not.toBeNull();
  });

  it('Vehicle Info title should be empty initially until manually call `detectChanges', () => {
    de = fixture.debugElement.query(By.css('.vehicleInfo-title'));
    el = de.nativeElement;

    expect(el.textContent).toBe('');
  });

  it('Vehicle Info title after initialization', () => {

    de = fixture.debugElement.query(By.css('.vehicleInfo-title'));
    el = de.nativeElement;

    fixture.detectChanges();
    expect(el.textContent).toContain('VEHICLEINFO.ACC_VEHICLE');
  });

  // it('should emit on collapse button clicked', fakeAsync((): void => {
  //   comp.isAccCollapse = true;
  //   comp.showIcon = true;
  //   fixture.detectChanges();
  //   spyOn(comp.collapseAcc, 'emit');
  //   let button = findElement(fixture, '.collpase')

  //   button.dispatchEvent(new Event('click'));
  //   fixture.detectChanges();
  //   tick();
  //   expect(comp.collapseAcc.emit).toHaveBeenCalledWith(comp.isAccCollapse);
  // }));


});
