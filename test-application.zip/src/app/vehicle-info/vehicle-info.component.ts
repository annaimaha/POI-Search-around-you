import { Component, OnInit, Input, EventEmitter, Output} from '@angular/core';

@Component({
  selector: 'vehicleInfo',
  templateUrl: './vehicle-info.component.html',
  styleUrls: ['./vehicle-info.component.css']
})
export class VehicleInfoComponent implements OnInit {
	@Input() vehicleInfo:any;
    disabled: boolean = true;
    @Input() showIcon:any;
    @Input() isAccCollapse:any;

    @Output() collapseAcc = new EventEmitter();
    constructor() {
        this.vehicleInfo = {};
     }

    ngOnInit() {
        
    }
    // collapse() {
    //     this.isAccCollapse = !this.isAccCollapse;
    //     this.collapseAcc.emit(this.isAccCollapse)
    // }
}
