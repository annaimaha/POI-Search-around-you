import { TestBed, inject } from '@angular/core/testing';

import { HelperService } from './helper.service';

describe('HelperService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HelperService]
    });
  });
  let objeCDto = {
    Date: "",
    SpeedAlertType: "",
    accountId: "103011633",
    action: "",
    alertHistoryId: "",
    alertName: "test",
    alertStart: false,
    alertStartDate: "2017-05-26",
    alertStartDate1: '',
    alertStop: false,
    alertStopDate: "2017-05-26",
    alertStopDate1: '',
    altitude: "",
    bespokeEnd: "",
    bespokeFlag: false,
    bespokeStart: "",
    channelId: "",
    custId: "",
    customFlag: false,
    dailyEnd: "",
    dailyFlag: true,
    dailyStart: "",
    dateDisplay: "",
    dayOfWeek: '',
    deletedFlag: false,
    delivery: "",
    duration: '',
    emailFlag: true,
    emailID: "test1@verizon.com",
    enabledFlag: false,
    endOfTripFlag: false,
    endTime: "08:30 AM",
    everyDay: "true",
    everyWeek: "true",
    everyWeekDayOnly: false,
    frequency: "",
    fri: false,
    heading: "",
    immediatlyFlag: false,
    latitude: "",
    location: "",
    longitude: "",
    maxSpeed: "",
    minutesFromMidnight: '',
    mon: false,
    monthlyDate: '',
    monthlyFlag: false,
    notification: "",
    notifications: "",
    periodic: "",
    phoneNumber: "1234567890",
    popupFlag: false,
    precesionTruness: "",
    precisionInMeters: "",
    recurrenceStart: false,
    recurrenceStop: false,
    recurringDays: 1,
    recurringWeeks: '',
    sat: false,
    setSpeed: "",
    smsFlag: true,
    speed: "",
    speedAlertError: false,
    speedAlertStatus: "",
    speedAlertTriggerDelay: "",
    speedId: "",
    startDate2: '',
    startDateWithTime: "",
    startTime: "05:00 AM",
    stopDate2: '',
    stopDateWithTime: "",
    sun: false,
    tcuId: '',
    tcuid: "",
    textFlag: "",
    thur: false,
    time: "",
    timePeriodStart: false,
    timePeriodStop: false,
    transactionId: "",
    triggerSpeed: "12",
    tue: false,
    type: "",
    vehicleAlertId: "",
    vin: "BVWL07AJ2FM263381",
    violationType: "",
    web: false,
    wed: false,
    weekInterval: '',
    weeklyDate: '',
    weeklyEnd: "",
    weeklyFlag: false,
    weeklyStart: ""
  }

  it('should ...', inject([HelperService], (service: HelperService) => {
    expect(service).toBeTruthy();
  }));

  it('should ...', inject([HelperService], (service: HelperService) => {
    let time = '08:00 PM';
    let timeReturn = service.convertTimeFrom12To24(time);
    expect(timeReturn).toBe('20.00');
  }));

  it('should dateTimeValidate to be true', inject([HelperService], (service: HelperService) => {
    let endTime = '09:00 AM';
    let dateValidation = service.dateTimeValidatefuntion(endTime,objeCDto);
    expect(dateValidation).toBe(true);
  }));

  it('should dateTimeValidate to be false', inject([HelperService], (service: HelperService) => {
    let endTime = '04:00 AM';
    let dateValidation = service.dateTimeValidatefuntion(endTime,objeCDto);
    expect(dateValidation).toBe(false);    
  }));
  

  it('should removeAll return string', inject([HelperService], (service: HelperService) => {
    let itemsToDelete = [123123,934853];
    let removeAllReturn = service.removeAll(itemsToDelete);
    //console.log(removeAllReturn);    
  }));

   it('should formatDate return specified format', inject([HelperService], (service: HelperService) => {
    let date = '2017/04/20';
    let formatDateReturn = service.formatDate(date);
    expect(formatDateReturn).toBe('2017-04-20');    
  }));

});
