import { EcallService } from '../../app/calls/ecall/ecall.service';
import { Http, Response,Headers,RequestOptions,URLSearchParams} from '@angular/http';

import { Injectable } from '@angular/core';
import { Observable }     from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';


export class FakeEcallService {
    private headers: any; 
        constructor(){
     //   this.headers = new Headers();
    }

    getEcall():Observable<any> {
        return Observable.of([]);
    }

    getEcallDetails():Observable<any> {
        return Observable.of([]);
    }

    inBandLocationEcall(){

    }

    closeServiceRequestEcall(){

    }
}