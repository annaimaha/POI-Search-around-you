import { IcallService } from '../../app/calls/icall/icall.service';
import { Http, Response,Headers,RequestOptions,URLSearchParams} from '@angular/http';

import { Injectable } from '@angular/core';
import { Observable }     from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';


export class FakeIcallService {
    private headers: any; 
        constructor(){
     //   this.headers = new Headers();
    }

    getIcall():Observable<any> {
        return Observable.of([]);
    }

    getIcallDetails():Observable<any> {
        return Observable.of([]);
    }

    inBandLocationIcall(){

    }

    closeServiceRequestIcall(){

    }
}