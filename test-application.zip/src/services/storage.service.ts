import { Injectable } from '@angular/core';
declare var sessionStorage : any;
@Injectable()
export class StorageService {

  private static ACC_NUM: string = 'acc_num';
    private static ACC_INFO: string = 'acc_info';
    private static PIN: string = 'pin';
    constructor() {

    }

    /**
     * Check if user token in storage
     * Note: this is to support landing page component directive as global function,
     *       room for improvements
     * @returns {boolean}
     */
    public static isTokenPresent(){
        //return !!localStorage.getItem(StorageService.USER_KEY);
    }

    /**
     * Retrieve user credential from storage
     * @returns {Credential}
     */
    public getCredential() {

    }
    public setAccNum(accNum,pin){
      sessionStorage.setItem(StorageService.ACC_NUM,accNum);
      sessionStorage.setItem(StorageService.PIN,pin);
    }
    public setAccInfo(accInfo){
      sessionStorage.setItem(StorageService.ACC_INFO,accInfo);
    }
    public getAccNum(){
      sessionStorage.getItem(StorageService.ACC_NUM);
    }
    public getAccInfo(){
      sessionStorage.getItem(StorageService.ACC_INFO);
    }
    /**
     * Remove all user related objects from storage
     */
    public clearStorage() {
      //  this.logger.info(`StorageService=> Clearing local storage.`);
      //  localStorage.removeItem(StorageService.FROM_RECORD);
    }
}
