// import { TestBed, inject } from '@angular/core/testing';

// import { MapResizeService } from './map-resize.service';

// describe('MapResizeService', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       providers: [MapResizeService]
//     });
//   });

//   it('should be created', inject([MapResizeService], (service: MapResizeService) => {
//     expect(service).toBeTruthy();
//   }));
// });
