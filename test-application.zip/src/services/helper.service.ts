import { Injectable } from '@angular/core';

@Injectable()
export class HelperService {

  constructor() { }

    convertTimeFrom12To24(time:any) {
        var timeStr = time.replace(/ +/g, "");
        var colon = timeStr.indexOf(':');
        var hours = timeStr.substr(0, colon),
            minutes = timeStr.substr(colon+1, 2),
            meridian = timeStr.substr(colon + 3, 3).toUpperCase();

        var hoursInt = parseInt(hours, 10),
            offset = meridian == 'PM' ? 12 : 0;

        if (hoursInt === 12) {
            hoursInt = offset;
        } else {
            hoursInt += offset;
        }
        
        return hoursInt + "." + minutes;
    }

    dateTimeValidatefuntion(endTime:any, geofence:any) {
        if ((geofence['startTime'] !== "" && geofence['startTime'] !== "undefined") && (geofence['alertStartDate'] !== "undefined" && geofence['alertStopDate'] !== "undefined") && (geofence['alertStartDate'] === geofence['alertStopDate']) && (geofence['alertStartDate'] !== null && geofence['alertStopDate'] !== null)) {
            let start = parseFloat(this.convertTimeFrom12To24(geofence['startTime']));
            let end = parseFloat(this.convertTimeFrom12To24(endTime));
            if ((start === end) || !(start < end)) {
                return false;
            } else {
                return true;
            }
        }
        return true;
    }
    
    /**
     * Methods to change the format of date 
     * 
     * Out put  2017-04-20
     * */ 
    formatDate(date:any) {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2) month = '0' + month;
        if (day.length < 2) day = '0' + day;

        return [year, month, day].join('-');
    }

    /**
     * Methods  to removeAll
     */
    removeAll(items:any) {        
        let ids = '';
        for (let k in items) {
            if (items[k] && k !== "selectAll") {
                ids += k + ",";
            }
        }
        return ids = ids.replace(/,\s*$/, "");    
    }


     // getAllcheckedHistory(data:any, rowsOnPage:any, keyIds:any) {
    //     let ids : any[];
    //     if (data !== null && data !== "undefind") {
    //         let count = (rowsOnPage < data.length) ? rowsOnPage : data.length;
    //         for (let i = 0; i < count; i++) {
    //             ids[i] = data[i][keyIds];
    //         }
    //     }
    //     return ids;
    // }

}
