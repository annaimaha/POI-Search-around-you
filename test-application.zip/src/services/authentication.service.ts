import { Injectable,Output, EventEmitter } from '@angular/core';
import { Http, Response,Headers,RequestOptions,URLSearchParams} from '@angular/http';
import { Observable } from 'rxjs';
import { CanActivate, Router } from '@angular/router';
import {myGlobals} from '../constants/globals';
declare var sessionStorage : any;

@Injectable()
export class AuthenticationService {
    
  headers:any;
  options:any
  constructor(private http:Http,private router:Router) {
	   this.headers = new Headers();
      this.headers.append('Content-Type', 'application/json');
      this.headers.append('Accept', 'application/json');
      this.options = {headers :this.headers,withCredentials: true};         
  }


  authenticate(postParam:any){
    return this.http.post(myGlobals.login,postParam, this.options)
        .map(this.extractData)
        .catch(this.handleError);
  }

  canActivate() {
    if (sessionStorage.getItem('id_token')) { return true; }
    //this.router.navigate(['/login']);
    return true;
  }


  requestToLogout(){
    this.clearSession();
    return this.http.post(myGlobals.logout, this.options)
        .map(this.extractData)
        .catch(this.handleError);
  }

  clearSession(){
   sessionStorage.removeItem('id_token');
   sessionStorage.removeItem('accountInfo');
   sessionStorage.removeItem('params');   
  }

  private extractData(res: Response) {
        let body = res.json();
        return body.data?body.data: (body || {});
  }

  private handleError(error: Response | any) {
        // In a real world app, we might use a remote logging infrastructure
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        
        errMsg = (error.status == '0') ? myGlobals.badGateWay : errMsg;

        return Observable.throw(errMsg);
    }
}
