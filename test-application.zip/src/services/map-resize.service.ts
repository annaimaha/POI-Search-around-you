import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class MapResizeService {
    private subject = new Subject<any>();

    sendCollapse(iscollapse: string) {
        this.subject.next({ boolean: iscollapse });        
    }

    clearMessage() {
        this.subject.next();
    }

    receiveCollapse(): Observable<any> {
        return this.subject.asObservable();
    }
}