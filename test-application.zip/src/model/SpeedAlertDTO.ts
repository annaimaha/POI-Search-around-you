import {AlertNotificationDTO} from './AlertNotificationDTO.model';

export class SpeedAlertDTO {

  constructor(
	     public dateDisplay:string,
       public alertName:string,
       public maxSpeed:string,
       public vin:string,
       public speedId:string,
       public custId:string,
       public tcuId:string,
       public accountId:string,
       public transactionId:string,
       public vehicleAlertId:string,
       public alertHistoryId:string,
       public type:string,
       public action:string,
       public violationType:string,
       public channelId:string,
       public notifications:string,
       public delivery:string,

       public enabledFlag: boolean,
       public popupFlag: boolean,
       public deletedFlag: boolean,
       public immediatlyFlag: boolean,
       public endOfTripFlag: boolean,
       public customFlag: boolean,

       public speedAlertError: boolean,

       public SpeedAlertType :any,
       public textFlag: string,
       public notification: string,
       public speedAlertStatus: string,

       public emailFlag: boolean,
       public smsFlag: boolean,
       public web: boolean,
       public emailID: string,
       public phoneNumber: string,


       // This variable is mapped to course DB column
       public heading: string,
       // Following variables are for displaying Lat Longs in google pop-up in violation History
       public latitude: string,
       public longitude: string,
       public altitude: string,
       public precisionInMeters: string,
       public precesionTruness: string,
       public location: string,
       public speed: string,
       public setSpeed: string,
       public triggerSpeed: number,
       public speedAlertTriggerDelay: string,

       public frequency: string,
       public Date: string,
       public time: string,

       public duration:number,
       public weekInterval:number,
       public minutesFromMidnight:number,

       public alertStart: boolean,
       public alertStop: boolean,
       public bespokeFlag: boolean,
       public dailyFlag: boolean,
       public weeklyFlag: boolean,
       public monthlyFlag: boolean,
       public recurrenceStart: boolean,
       public recurrenceStop: boolean,
       public timePeriodStart: boolean,
       public timePeriodStop: boolean,

       public recurringDays:any,
       public recurringWeeks:any,

       public periodic: string,

       public bespokeStart: string,
       public bespokeEnd: string,
       public dailyStart: string,
       public dailyEnd: string,
       public weeklyStart: string,
       public weeklyEnd: string,


       public dayOfWeek :number,
       public weeklyDate :Date,
       public monthlyDate: Date ,
       public alertStartDate1: Date ,
       public alertStopDate1: Date ,
       public startDate2: Date ,
       public stopDate2: Date ,
       public startDateWithTime: string,
       public stopDateWithTime: string,
       public startTime: string,
       public endTime: string,

       public everyWeekDayOnly: boolean,
       public everyDay: boolean,
       public everyWeek: boolean,
       public mon: boolean,
       public tue: boolean,
       public wed: boolean,
       public thur: boolean,
       public fri: boolean,
       public sat: boolean,
       public sun: boolean

 ) {  }

}
