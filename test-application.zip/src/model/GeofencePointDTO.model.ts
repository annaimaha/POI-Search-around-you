export class GeofencePointDTO {

    ellipseCenterLat: any;
    ellipseCenterLongi: any;
    geofenceLatitude: any;
    geofenceLongitude: any;
    geofencePointId: any;
    orderNo: any;
    rectangleCenterLat: any;
    rectangleCenterLongi: any;
    rectangleNeLat: any;
    rectangleNeLongi: any;
    rectangleSwLat: any;
    rectangleSwLongi: string

}
