export class UserDTO {
	firstName: any;
	lastName: any;
	city:any;
	address1: any;
	address2: any;
	state: any;
	zip: any;
	email:any;
	phoneNumber: any;
	pin: any;
	vin: any;
	emergency_firstName: any;
	emergency_lastName: any;
	emergency_phone: any;
	accountId: any;
	accountCRMId: any;
	transaction: any;
	customerId: any;
	tcuId: any;
	userTimeZoneString: any;
	primaryNumber: any;
	userId: any;
}