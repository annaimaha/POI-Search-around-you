export class ClimatizationsettingsDTO {
constructor(
public cntrlTemp: number,
public clmtDurExtPwr: number,
public clmtDurBtryPwr: number,
public winHeat: string,
public extPwrSpply: string,
public trgtTemp: string,
public fwlpTimeExtPwr: number,
public fwlpTimeBtry: number,
public optExtPwrSpply: number,
public basSetWinHeat: number,
public climatisation: number,
public outDoorTemp: number,
public inCabinTemp: number,
public outDoorTempState: number,
public inCabinTempState: number,
public climState: number,
public winHeatState: number,
public winHeatStateFront: boolean,
public winHeatStateRear: boolean,
public email: string,
public phoneNumber: number,
public notificationFlag: boolean,
public phoneNumberFlag: boolean,
public emailFlag: boolean,
public popupFlag: boolean,
public exceptionMsg: number,
public climateTimestamp: number,
public triggerSource: number

  ) {  }
}




/*
Copyright 2016 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/
