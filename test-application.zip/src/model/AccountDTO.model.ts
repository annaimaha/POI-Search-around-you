import {UserDTO} from './UserDTO.model';

export class AccountDTO{
  accountNumber: any;
  make: any;
  model: any;
  vin: any;
  year: any;
  engine: any;
  transmission: any;
  fuelType: any;
  exteriorColor: any;
  assetNumber: any;
  imei: any;
  imsi: any;
  msisdn: any;
  deviceId: any;
  tcuid: any;
  wirelessCarrier: any;
  mdnDisplay: any;
  userDTO: UserDTO;
  status: any;
  deviceType: any;
  otarDate: any;
  remoteStartCapable: any;
  headUnitType: any;
}