export class Multiselect {

  constructor(
    public id: string
  ) {  }

}
