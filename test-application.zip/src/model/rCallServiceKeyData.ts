export class RCallServiceKeyDataDTO {
  constructor(
		public serviceKeyTimeStamp:string,
		public serviceKeyState:string,
		public serviceKeyData:string
		
	  ) {  }
}
