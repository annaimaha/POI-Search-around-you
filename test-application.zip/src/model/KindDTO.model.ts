export class KindDTO {
	code:any;
	name:any;
}