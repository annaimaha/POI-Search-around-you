export class AlertNotificationDTO {

    alertNotificationId: any;
    email: any;
    phNumber: any;
}