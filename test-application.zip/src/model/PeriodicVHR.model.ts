export class PeriodicVHRDTO {

  constructor(
  public smsFlag:boolean,
  public phoneNumber:number,
  public emailFlag:boolean,
  public emailId:string,  
  public timeBasedVhrFlag:boolean,
  public distanceBasedVhrFlag:boolean,
  public startMileage:string,
  public distanceMaintenanceDistance:string,
  public maintenanceDistanceBasedVhrFlag:boolean,
  public dayOfMonthGenerateReport:any,
  public numberOfMonthsTimeVhr:any
  ) {  }

}
