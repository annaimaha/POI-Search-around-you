export class TripStatisticsDTO {	
	vehicleStatisticId:any;
	auxConsumerCnsmptn:any;
	averageSpeed:any;
	avgElctrcEngnCnsmptn:any;
	avgFuelConsumption:any;
	avgRecuperation:any;
	dateTime:any;
	distance:any;
	endMileage:any;
	startMileage:any;
	transactionId:any;
	travelTime:any;
	overallMileage:any;
	validFlag:any;
	accountInformation:any;
	vehicleResetType:any;
}