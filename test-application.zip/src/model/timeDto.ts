
export class TimeDto {

  constructor(
  public activityLogtime:any
      
  ) {  }

}
