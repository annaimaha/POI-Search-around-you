export class GeoDTO {
	type:any;
	value:any;
}