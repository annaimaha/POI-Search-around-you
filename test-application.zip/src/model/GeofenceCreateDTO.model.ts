import {AlertNotificationDTO} from './AlertNotificationDTO.model';
import {GeofencePointDTO} from './GeofencePointDTO.model';

export class GeofenceCreateDTO {

  constructor(
    public alertStatus: any,
		public alertName: any,
		public fenceId: any,
		public radius: any,
		public popupFlag: any,
		public tcuid: any,
		public vin: any,
		public custId: any,
		public transactionId: any,
		public accountId: any,
		public vehicleAlertId: any,
		public enabledFlag: any,

		public deleteFlag: any,
		public smsFlag: any,
		public phoneNumber: any, // 4b
		public emailFlag: any, // 4c
		public emailID: any,
		public web: any,
		public customFlag: any,
		public dailyFlag: any, // 5d
		public weeklyFlag: any, // 5g

		public everyWeekDayOnly: any,
		public everyDay: any,
		public everyWeek: any,

		public startTime: any,
		public endTime: any,
		public alertHistoryId: any,
		public startDateWithTime: any,
		public stopDateWithTime: any,


		public bespokeFlag: any, // 5a
		public bespokeStart: any, // 5b
		public bespokeEnd: any, // 5c
		public dailyStart: any, // 5e
		public dailyEnd: any, // 5f
		public weeklyStart: any, // 5h
		public weeklyEnd: any, // 5i

		public alertStart: any,
		public alertStop: any,
		public recurringDays: any,
		public recurringWeeks: any,
		public location: any,
		public duration: any,
		public periodic: any,

		public mon: any,
		public tue: any,
		public wed: any,
		public thur: any,
		public fri: any,
		public sat: any,
		public sun: any,

		public alertStartDate: any,
		public alertStopDate: any,
		public alertNotifications: any,
		public geofencePoints: any,
		public dateDisplay: any,
		public Date: any,
		public triggerType: any,
		public heading: any,
		public precisionInMeters: any,
		public zoomLevel: any, // 3d
		public altitude: any,
		public precesionTruness: any,
		public latitude: any,
		public longitude: any,
		public latLong: any,

		public zoneFlag: any,
		public greenZoneFlag: any, // 2a
		public redZoneFlag: any, // 2b

		public ellipseFlag: any,
		public rectangleFlag: any,
		public circleFlag: any,

		public circleRadius: any, // 3a
		public circleCenterLat: any, // 3b
		public circleCenterLongi: any, // 3c

		public rectangleNeLat: any,
		public rectangleNeLongi: any,
		public rectangleNwLat: any,
		public rectangleNwLongi: any,
		public rectangleSwLat: any,
		public rectangleSwLongi: any,
		public rectangleSeLat: any,
		public rectangleSeLongi: any,
		public rectangleWidth: any,
		public rectangleHeight: any,
		public rectangleCenterLat: any,
		public rectangleCenterLongi: any,
		public rectangleRotationAngle: any,

		public ellipseCenterLat: any,
		public ellipseCenterLongi: any,
		public ellipseFirstRadius: any,
		public ellipseSecondRadius: any,
		public ellipseRotationAngle: any,
 ) {  }

}
