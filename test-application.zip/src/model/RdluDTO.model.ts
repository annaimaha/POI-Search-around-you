export class RdluDTO {
  constructor(
   public statusText:any,
   public centralLock:any,
   public frontLeftDoorStatus:any,
   public frontRightDoorStatus:any,
   public rearLeftDoorStatus:any,
   public rearRightDoorStatus:any,
   public rearFlap:any,
   public frontLeftWindowStatus:any,
   public frontRightWindowStatus:any,
   public rearLeftWindowStatus:any,
   public rearRightWindowStatus:any,
   public convertibleTop:any,
   public engineHood:any,
   public sunRoof:any,
   public transactionId:any
)
{  }
}
