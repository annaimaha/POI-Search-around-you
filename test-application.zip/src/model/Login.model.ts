export class LoginDTO {

  constructor(
  public accountNumber:number,
  public pin:any,
  public oem:any,
  public vin:any
  ) {  }

}
