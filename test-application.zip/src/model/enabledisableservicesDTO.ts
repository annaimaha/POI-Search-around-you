export class enabledisableservicesDTO {
  constructor(
	public srNumber:string,
	public accountNumber:string,
	public dateTime:Date,
	public dateTimeString:string,
	public manualEmerCall:boolean,
	public autoCrashNotfCall:boolean,
	public roadSideAssisCall:boolean,
	public infoCall:boolean,
	public vehHealthRep:boolean,
	public speedAlert:boolean,
	public stolVehTrack:boolean,
	public geofencing:boolean,
	public vehDisabling:boolean,
	public doorUnlock:boolean,
	public honkFlash:boolean,
	public vehStatus:boolean,
	public tripStat:boolean,
	public poiImport:boolean,
	public battChargMngmt:boolean,
	public preTripMngmt:boolean,
	public departureTimeMngmt:boolean,
	public transaction:string,
	public serviceResponse:string,
	public tcuid:string,
	public vin:string
	  ) {  }
}
