export class Remotedempprofile {
  constructor(
    public minbatteryleve: string,
    public profileName: string,
    public temperature: boolean,
    public windowHeating: boolean,
    public batteryCharging: boolean,
    public maxBatteryLevelPct :any,
    public maxCurrent :any,
    public nightRate :boolean,
    public startTimeHours:string,
    public endTimeHours:string,
    public startTimeAmPm:string,
    public endTimeAmPm:string,
    public startTime:string,
    public endTime:string
  ) {  }
}






/*
Copyright 2016 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/
