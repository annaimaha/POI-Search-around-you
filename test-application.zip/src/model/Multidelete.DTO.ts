export class Multidelte {

  constructor(
       private checked:any
  ) {  }

}
