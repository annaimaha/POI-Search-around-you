export class useractivelogDTO {
  constructor(
	public commandFrom:string,
	public commandTo:string,
	public commandName:string,
	public createTime:string,
	public endTime:string,
	public messageTypeName:string,
	public message:string,
	public createTimeDisplay:string,
	public createUTCDisplay:string
	  ) {  }
}
