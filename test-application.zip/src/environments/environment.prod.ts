export const environment = {
  production: true,
  envName: 'prod',
  url: 'https://vtpr-test.vtitel.net'
};
