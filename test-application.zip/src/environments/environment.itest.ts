export const environment = {
  production: true,
  envName: 'itest',
  url: 'https://vtpr-test.vtitel.net'
};
