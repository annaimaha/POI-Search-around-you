
import { environment } from '../environments/environment';

export class myGlobals {
	
	public static environmentName = environment.envName;

	public static host = environment.url;
	
	//Session TimeOut
	public static timoutWarningMilliseconds    = 900000;  //120000;     // 2 minute

	public static actualtimeoutMilliseconds    = 900000; //150000;     // 2.30 minute
	public static disAppearTimeMessage         = 3000;
	public static recallApis                   = 15000;
	public static randomNumdigts               = 1000001;
	public static pageSizes                    = 5;
	
	//Data Table
	public static rowsOnPage                    = 5;
	public static sortOrder                     = "desc"; //asc|desc

	//login
	public static login	 	                   = myGlobals.host+"/vtp/svc/login?api-key=vzt-vtp-securitysvc&";
	// Logout
	public static logout	 	               = myGlobals.host+"/vtp/svc/logout?api-key=vzt-vtp-securitysvc&";
	

	//Account Info
	public static getBasicAccVehInfo	 	     = myGlobals.host+"/vtp/svc/getBasicAccVehInfo?api-key=vzt-vtp-accvehinfosvc&";
	public static accContactInfo	 	         = myGlobals.host+"/vtp/svc/getAcctContactInfo?api-key=vzt-vtp-accvehinfosvc&";
	public static updateAcctContactInfo      	 = myGlobals.host+"/vtp/svc/updateAcctContactInfo?api-key=vzt-vtp-accvehinfosvc&";

	//Enable disable services 

	public static enableDisableServices        = myGlobals.host+"/vtp/svc/enableDisableServices?api-key=vzt-vtp-accvehinfosvc&";
	public static enableDisableServicesRequest = myGlobals.host+"/vtp/svc/enableDisableServicesRequest?api-key=vzt-vtp-accvehinfosvc&";

	// Activity Logs
	public static log                          = myGlobals.host+"/vtp/svc/log?api-key=vzt-vtp-callinfosvc&";
	public static dayWiseLog                   = myGlobals.host+"/vtp/svc/dayWiseLog?api-key=vzt-vtp-callinfosvc&";


	// Trip Statistics
	public static lastTripReport             	 = myGlobals.host+"/vtp/svc/lastTripReport?api-key=vzt-vtp-accvehinfosvc&";
	public static userResetReport            	 = myGlobals.host+"/vtp/svc/userResetReport?api-key=vzt-vtp-accvehinfosvc&";

	//VHR
	public static viewhr           	          = myGlobals.host+"/vtp/svc/vehicleHealthReport?api-key=vzt-vtp-accvehinfosvc&";
	public static requestImediateVHR           = myGlobals.host+"/vtp/svc/requestIntermediateVHR?api-key=vzt-vtp-accvehinfosvc&";
	public static periodicVHR                  = myGlobals.host+"/vtp/svc/postConfigurePeriodicVHR?api-key=vzt-vtp-accvehinfosvc&";
	public static viewHistoryVHR               = myGlobals.host+"/vtp/svc/viewHistoryVHR?api-key=vzt-vtp-accvehinfosvc&";
	public static vhrHistory                   = myGlobals.host+"/vtp/svc/vhrHistory?api-key=vzt-vtp-accvehinfosvc&";
	public static deleteVhrHistory             = myGlobals.host+"/vtp/svc/deleteVhrHistory?api-key=vzt-vtp-accvehinfosvc&";

	// E call
	public static emergencyCallList          	 = myGlobals.host+"/vtp/svc/emergencyCallList?api-key=vzt-vtp-callinfosvc&";
	public static emergencyCallDetail        	 = myGlobals.host+"/vtp/svc/emergencyCallDetail?api-key=vzt-vtp-callinfosvc&";
	public static closeServiceRequestEcall		 = myGlobals.host+"/vtp/svc/closeServiceRequestEcall?api-key=vzt-vtp-callinfosvc&";
	public static inBandLocationEcall			 = myGlobals.host+"/vtp/svc/inBandLocationEcall?api-key=vzt-vtp-callinfosvc&";

	//calls I call
	public static informationCallList          = myGlobals.host+"/vtp/svc/informationCallList?api-key=vzt-vtp-callinfosvc&";
	public static informationCallDetail        = myGlobals.host+"/vtp/svc/informationCallDetail?api-key=vzt-vtp-callinfosvc&";
	public static closeServiceRequestIcall     = myGlobals.host+"/vtp/svc/closeServiceRequestIcall?api-key=vzt-vtp-callinfosvc&";
	public static inBandLocationIcall     		 = myGlobals.host+"/vtp/svc/inBandLocationIcall?api-key=vzt-vtp-callinfosvc&";

	// R call
	public static roadSideAssistanceList       = myGlobals.host+"/vtp/svc/roadSideAssistanceList?api-key=vzt-vtp-callinfosvc&";
	public static roadSideAssistance        	 = myGlobals.host+"/vtp/svc/roadSideAssistanceCallDetail?api-key=vzt-vtp-callinfosvc&";
	public static closeServiceRequestRcall		 = myGlobals.host+"/vtp/svc/closeServiceRequestRcall?api-key=vzt-vtp-callinfosvc&";
	public static inBandLocationRcall			 = myGlobals.host+"/vtp/svc/inBandLocationRcall?api-key=vzt-vtp-callinfosvc&";

	// Geofence Alert	
	public static geofenceAlertUrl           	 = myGlobals.host+"/vtp/svc/showGeofenceAlerts?api-key=vzt-vtp-locationsvc&";
	public static editGeofenceAlert            = myGlobals.host+"/vtp/svc/editGeofenceAlert?api-key=vzt-vtp-locationsvc&";
	public static geofenceViolationHistory 	 = myGlobals.host+"/vtp/svc/geofenceViolationHistory?api-key=vzt-vtp-locationsvc&";
	public static geofenceAlertCreate        	 = myGlobals.host+"/vtp/svc/addGeofenceAlert?api-key=vzt-vtp-locationsvc&";
	public static updateGeofenceAlert          = myGlobals.host+"/vtp/svc/updateGeofenceAlert?api-key=vzt-vtp-locationsvc&";
	public static geofenceAlertDelete        	 = myGlobals.host+"/vtp/svc/deleteGeofenceAlerts?api-key=vzt-vtp-locationsvc&";
	public static deleteGeofenceHistory        = myGlobals.host+"/vtp/svc/deleteGeofenceViolationHistory?api-key=vzt-vtp-locationsvc&";

	//speed Alert
	public static getSpeedAlerts               = myGlobals.host+"/vtp/svc/getSpeedAlerts?api-key=vzt-vtp-locationsvc&";
	public static createAlert            	   = myGlobals.host+"/vtp/svc/createAlert?api-key=vzt-vtp-locationsvc&";
	public static speedHistory            	   = myGlobals.host+"/vtp/svc/speedHistory?api-key=vzt-vtp-locationsvc&";
	public static speedAlertDelete             = myGlobals.host+"/vtp/svc/deleteSpeedAlerts?api-key=vzt-vtp-locationsvc&";
	public static editAlert                    = myGlobals.host+"/vtp/svc/editAlert?api-key=vzt-vtp-locationsvc&";
	public static updateAlert                  = myGlobals.host+"/vtp/svc/updateAlert?api-key=vzt-vtp-locationsvc&";
	public static deleteSpeedAlertHistory      = myGlobals.host+"/vtp/svc/deleteSpeedAlertHistory?api-key=vzt-vtp-locationsvc&";

	// POI
	public static showPoiDefultPage            = myGlobals.host+"/vtp/svc/pointOfInterest?api-key=vzt-vtp-locationsvc&";
	public static poiSearch                    = myGlobals.host+"/vtp/svc/pointOfInterestPost?api-key=vzt-vtp-locationsvc&";
	public static poiSend                  	   = myGlobals.host+"/vtp/svc/pointOfInterestPostSend?api-key=vzt-vtp-locationsvc&";
	public static poiHistory			       = myGlobals.host+"/vtp/svc/pointOfInterestHistory?api-key=vzt-vtp-locationsvc&";
	public static poiHistoryResend             = myGlobals.host+"/vtp/svc/poiHistoryResend?api-key=vzt-vtp-locationsvc&";
	public static deletePoiHistory             = myGlobals.host+"/vtp/svc/deletePointOfInterestHistory?api-key=vzt-vtp-locationsvc&";

	//vehicleDisabling
	public static vehicleDisabling             = myGlobals.host+"/vtp/svc/vehicleDisablingInfo?api-key=vzt-vtp-locationsvc&";
	public static vehicleDisablingHistory      = myGlobals.host+"/vtp/svc/vehicleDisablingHistory?api-key=vzt-vtp-accvehinfosvc&";
	public static vDInfoByTransId              = myGlobals.host+"/vtp/svc/vehicleDisablingInfoByTransId?api-key=vzt-vtp-accvehinfosvc&";
	public static vehicleDisablingRequest      = myGlobals.host+"/vtp/svc/vehicleDisablingRequest?api-key=vzt-vtp-accvehinfosvc&";

	//SVT
	public static stolenVehicleTracking        = myGlobals.host+"/vtp/svc/stolenVehicleTracking?api-key=vzt-vtp-locationsvc&";
	public static locateVehicle                = myGlobals.host+"/vtp/svc/locateVehicle?api-key=vzt-vtp-locationsvc&";
	public static locateVehicleFromDb          = myGlobals.host+"/vtp/svc/locateVehicleFromDb?api-key=vzt-vtp-locationsvc&";
	public static vehicleTrackingMWCall        = myGlobals.host+"/vtp/svc/vehicleTrackingMWCall?api-key=vzt-vtp-locationsvc&";
	public static startVehicleTracking         = myGlobals.host+"/vtp/svc/startVehicleTracking?api-key=vzt-vtp-locationsvc&";
	public static stopVehicleTracking          = myGlobals.host+"/vtp/svc/stopVehicleTracking?api-key=vzt-vtp-locationsvc&";
	public static svtHistory                   = myGlobals.host+"/vtp/svc/stolenVehicleTrackingHistory?api-key=vzt-vtp-locationsvc&";
	public static getMapInfoByTransactionId    = myGlobals.host+"/vtp/svc/getMapInfoByTransactionId?api-key=vzt-vtp-locationsvc&";

	// Remote Access
	public static vehicleStatus                = myGlobals.host+"/vtp/svc/vehicleStatus?api-key=vzt-vtp-remoteaccesssvc&";
	public static vehicleStatusPost            = myGlobals.host+"/vtp/svc/vehicleStatusPost?api-key=vzt-vtp-remoteaccesssvc&";

	public static rdluHistory                	 = myGlobals.host+"/vtp/svc/doorLockUnlockHistory?api-key=vzt-vtp-remoteaccesssvc&";
	public static doorUnlockRequest            = myGlobals.host+"/vtp/svc/doorLockUnlockRequest?api-key=vzt-vtp-remoteaccesssvc&";
	public static rdluDoorUnlockStatus         = myGlobals.host+"/vtp/svc/doorAndWindowStatusRequest?api-key=vzt-vtp-remoteaccesssvc&";
	public static rdluDoorWindowStatusDb       = myGlobals.host+"/vtp/svc/doorAndWindowStatusFromDb?api-key=vzt-vtp-remoteaccesssvc&";

	public static honkingAndflashHistory       = myGlobals.host+"/vtp/svc/honkingAndFlashingHistroy?api-key=vzt-vtp-remoteaccesssvc&";
	public static honkingAndFlashingRequest    = myGlobals.host+"/vtp/svc/honkingAndFlashingRequest?api-key=vzt-vtp-remoteaccesssvc&";
	public static honkFlashDb                  = myGlobals.host+"/vtp/svc/honkingAndFlashingStatusFromDb?api-key=vzt-vtp-remoteaccesssvc&";
	public static cancelHondandFlash           = myGlobals.host+"/vtp/svc/cancelHonkingAndFlashingRequest?api-key=vzt-vtp-remoteaccesssvc&";

	//Battery Charging
	public static chargeSettings               = myGlobals.host+"/vtp/svc/chargeSettings?api-key=vzt-vtp-accvehinfosvc&";
	public static chargeSettingsDetail         = myGlobals.host+"/vtp/svc/chargeSettingsDetail?api-key=vzt-vtp-accvehinfosvc&";
	public static saveChargeSettings           = myGlobals.host+"/vtp/svc/saveChargeSettings?api-key=vzt-vtp-accvehinfosvc&";

	//Stop Start Charging
	public static getBatteryState              = myGlobals.host+"/vtp/svc/getBatteryState?api-key=vzt-vtp-accvehinfosvc&";
	public static unlockChargingPlug           = myGlobals.host+"/vtp/svc/unlockChargingPlug?api-key=vzt-vtp-accvehinfosvc&";
	public static startStopBatteryCharge       = myGlobals.host+"/vtp/svc/startStopBatteryCharge?api-key=vzt-vtp-accvehinfosvc&";


	//Climatization
	public static remoteClimateSettings          = myGlobals.host+"/vtp/svc/remoteClimateSettings?api-key=vzt-vtp-accvehinfosvc&";
	public static saveRemoteClimateSettings      = myGlobals.host+"/vtp/svc/saveRemoteClimateSettings?api-key=vzt-vtp-accvehinfosvc&";
	public static remoteClimateActivate          = myGlobals.host+"/vtp/svc/remoteClimateActivate?api-key=vzt-vtp-accvehinfosvc&";
	public static startStopClimateActivate       = myGlobals.host+"/vtp/svc/startStopClimateActivate?api-key=vzt-vtp-accvehinfosvc&";
	public static startStopClimatewindowheating  = myGlobals.host+"/vtp/svc/startStopWindowHeating?api-key=vzt-vtp-accvehinfosvc&";

	//RemoteDepetureService
	public static remoteDepartureTime              = myGlobals.host+"/vtp/svc/remoteDepartureTime?api-key=vzt-vtp-accvehinfosvc&";
	public static updateRemoteDepartureTimer       = myGlobals.host+"/vtp/svc/updateRemoteDepartureTimer?api-key=vzt-vtp-accvehinfosvc&";
	public static timeValidation                   = myGlobals.host+"/vtp/svc/timeValidation?api-key=vzt-vtp-accvehinfosvc&";

	public static createRemoteDepartureProfile     = myGlobals.host+"/vtp/svc/createRemoteDepartureProfile?api-key=vzt-vtp-accvehinfosvc&";
	public static editRemoteDepartureProfile       = myGlobals.host+"/vtp/svc/editRemoteDepartureProfile?api-key=vzt-vtp-accvehinfosvc&";
	public static updateRemoteDepartureProfile     = myGlobals.host+"/vtp/svc/updateRemoteDepartureProfile?api-key=vzt-vtp-accvehinfosvc&";
	public static deleteDepartureProfile           = myGlobals.host+"/vtp/svc/deleteRemoteDepartureProfile?api-key=vzt-vtp-accvehinfosvc&";
	public static saveMinBatteryLevel              = myGlobals.host+"/vtp/svc/saveMinBatteryLevel?api-key=vzt-vtp-accvehinfosvc&";


	//Note

	public static speedAlertListNote           = 'Existing Speed Alert(s) are listed below. If a Speed Alert is "Enabled" the row is highlighed in green. Select "Alert Name" to view/edit the details of an existing alert.';
	// Messages // Login
	public static noData                       = "No Records Found.";
	public static nomultidelete                = "Please Select atleast one record to delete";
	public static requestSent                  = "Request has been sent successfully.";

	
	public static logoutmsg                    = "You have successfully loged out.";
	public static accountNotMach               = "Account Does't exist, Please check Account Number and Pin";
	public static badGateWay                   = 'Bad Gateway-An invalid response was received from the upstream server';
	public static saveBatteryChargingmsg       = "Battery settings are saved successfully.";
	public static deleteRecord             	= "Record(s) has been deleted successfully.";
	public static cancels             	        = "You have canceled the creation/update.";
	public static update             	        = "Record has been updated successfully.";
	public static create             	        = "New Record has been created successfully.";
	public static saveclimatization            = "Battery settings are saved successfully.";
	public static vswatingMsg                  = "Request submitted, this may take upto 10 minutes to refresh the data. Please click on the Refresh button to refresh the data";
	public static Inprogress                   = "In Progress";

	public static greenIcon                    = "assets/images/marker-icon-green.png";
	public static redIcon                      = "assets/images/marker-icon-red.png";
	public static carIcon                      = "assets/images/marker-icon-car.png";
	public static shadowIcon                   = "assets/images/marker-shadow.png";
	public static routerlanding                = "/landing";
	public static routervehiclehealthreport    = "/vehiclehealthreport";
	public static routerTripStatistics         = "/tripStatistics";
	public static routerEmergencyCall          = "/emergencyCall";
	public static routerInformationCall        = "/informationCall";
	public static routerAssistanceCall         = "/assistanceCall";
	public static routerPoi                    = "/poi";
	public static routerGeofence               = "/geofence";
	public static routerSpeedAlert             = "/speedAlert";
	public static routerSvt                    = "/svt";
	public static routerVehicledisabling       = "/vehicledisabling";
	public static routerVehiclestatus          = "/vehiclestatus";
	public static routerDoorlockunlock         = "/doorlockunlock";
	public static routerHonkFlash              = "/honkFlash";
	public static routerBatterycharging        = "/batterycharging";
	public static routerClimatization          = "/climatization";
	public static routerDepaturetime           = "/depaturetime";		
}
	
	
